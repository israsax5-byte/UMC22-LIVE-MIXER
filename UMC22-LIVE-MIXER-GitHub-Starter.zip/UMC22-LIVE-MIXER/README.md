# UMC22 LIVE MIXER — prueba de audio 0.2.0

Esta compilación añade un primer circuito de audio PCM16 mediante `AudioRecord` + `AudioTrack`. Intenta captura estéreo y, si no está admitida, captura mono y duplica la señal a la salida estéreo. Prueba 48 kHz y 44.1 kHz y solicita la ruta USB cuando Android expone la UMC22 como dispositivo de entrada/salida.

## Todavía no es una mezcladora terminada
- No incluye ecualizador, compresor, gate, reverb ni delay.
- El control disponible solo ajusta el nivel de salida.
- La selección preferida USB no garantiza que Android haya conectado físicamente ambas rutas. Confirma la escucha y no te fíes solo del mensaje de estado.
- Esta fuente no se ha compilado en un entorno Android SDK ni se ha probado físicamente con una UMC22 y una Galaxy Tab A9.

## Prueba segura
1. Conecta la UMC22 por USB OTG, el micrófono XLR y los audífonos.
2. Mantén +48 V apagado para un micrófono dinámico convencional.
3. Baja el volumen de audífonos antes de iniciar.
4. Apaga Direct Monitor para comprobar solo el retorno de la app.
5. No conectes altavoces ni uses esta prueba en un evento.
6. Si no se oye la voz o hay ruido, detén el audio y comparte una captura.

El workflow del repositorio extrae `UMC22-LIVE-MIXER-GitHub-Starter.zip`; por eso el ZIP actualizado conserva exactamente ese nombre.
