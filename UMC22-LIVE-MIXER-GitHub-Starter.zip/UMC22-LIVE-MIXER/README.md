# UMC22 LIVE MIXER v1.3.0 PRO

Consola de mezcla y procesamiento de audio en tiempo real para Android con Oboe (C++17) optimizada para interfaces USB OTG como Behringer UMC22.

## Novedades de esta versión

### 1. Interfaz de consola táctil (Hardware Rack UI)
- Diseño oscuro profesional de alto contraste adaptado a teléfonos (vertical) y tablets/horizontal (CH1 y CH2 lado a lado).
- Faders verticales táctiles con doble toque para volver al nivel base (`75%` en CH1, `65%` en CH2).
- Perillas rotatorias (`RotaryKnobView`) para EQ de 3 bandas (doble toque para reset a `0 dB`), Compresor, Reverb y Delay.
- Vúmetros segmentados de 24 pasos con indicador `CLIP` sostenido (1 s), pico sostenido por canal (`Peak Hold`) y medidor real de reducción de ganancia (`GR`) en el compresor.
- Selector de modo de entrada por canal (`ESTÉREO`, `MONO L`, `MONO R`) para centrar fácilmente micrófonos o instrumentos conectados a una sola entrada física.
- Botón **MUTE ALL** de emergencia en la barra superior y **Bloqueo en Vivo** (`Stage Lock`) contra toques accidentales.
- Pantalla encendida automática (`FLAG_KEEP_SCREEN_ON`) mientras el motor de audio está activo.

### 2. Motor de audio nativo optimizado (`native-audio.cpp`)
- Coeficientes de EQ y envolventes del compresor cacheados por bloque de audio (sin llamadas costosas por muestra).
- Suavizado (*smoothing*) de ganancias y tiempo de delay para evitar *clicks* o *zipper noise* al mover controles en directo.
- Filtro *High-Pass* (HPF 90 Hz) activable por canal para limpiar retumbos de escenario.
- Limitador suave de seguridad (*soft limiter*) en la salida.
- Detección automática de desconexión USB / error de stream Oboe (`onErrorAfterClose`) con notificación limpia a la interfaz.

### 3. Gestión avanzada de presets
- Preset **Flat / Bypass** para dejar el canal sin coloración en un toque.
- Presets rápidos de EQ (`Voz`, `Guitarra acústica`, `Guitarra eléctrica`, `Bajo`).
- **Tap Tempo** integrado en el módulo de Delay.
- Copia rápida de ajustes entre canales (`CH1 → CH2` y `CH2 → CH1`).
- Guardar, cargar, eliminar, **exportar (JSON al portapapeles)** e **importar (pegar JSON)** presets personalizados.
