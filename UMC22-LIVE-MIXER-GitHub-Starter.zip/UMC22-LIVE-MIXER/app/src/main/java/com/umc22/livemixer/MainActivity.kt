package com.umc22.livemixer

import android.app.Activity
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView = TextView(this).apply {
            this.text = value; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10)
        }
        root.addView(text("UMC22 LIVE MIXER", 26f))
        root.addView(text("Panel de prueba · Android 16", 14f, 0xFF9FB3C8.toInt()))
        status = text("Estado USB: comprobando dispositivos…", 16f, 0xFF65D6AD.toInt())
        root.addView(status)
        val usb = getSystemService(USB_SERVICE) as UsbManager
        val devices = usb.deviceList.values
        status.text = if (devices.isEmpty()) "Estado USB: no se detecta una interfaz. Conecta la UMC22 mediante un adaptador OTG." else
            "Dispositivos USB detectados: ${devices.size}\n" + devices.joinToString("\n") { "${it.productName ?: "USB"} (VID ${it.vendorId}, PID ${it.productId})" }
        root.addView(text("Canal 1 · Micrófono", 19f))
        addSlider(root, "Nivel de micrófono", 75)
        addSlider(root, "Graves", 50)
        addSlider(root, "Medios", 50)
        addSlider(root, "Agudos", 50)
        addSlider(root, "Reverb (control visual)", 15)
        addSlider(root, "Delay (control visual)", 0)
        root.addView(text("Aviso: esta compilación es una maqueta de interfaz. Todavía no procesa ni envía audio a la UMC22.", 13f, 0xFFFFD18A.toInt()))
        setContentView(root)
    }
    private fun addSlider(root: LinearLayout, label: String, initial: Int) {
        val title = TextView(this).apply { text = "$label: $initial%"; textSize = 15f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 8, 0, 0) }
        val bar = SeekBar(this).apply { max = 100; progress = initial }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { title.text = "$label: $progress%" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(bar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
