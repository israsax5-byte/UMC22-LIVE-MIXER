package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

class MainActivity : Activity() {

    private object Palette {
        val bgBase = 0xFF0A0D12.toInt()
        val bgHeader = 0xFF0E131B.toInt()
        val bgCard = 0xFF121822.toInt()
        val bgCardAlt = 0xFF17202E.toInt()
        val bgTrack = 0xFF0B0F15.toInt()
        val borderSubtle = 0xFF233044.toInt()
        val textPrimary = 0xFFF1F5F9.toInt()
        val textSecondary = 0xFF94A3B8.toInt()
        val textMuted = 0xFF64748B.toInt()
        val accentCyan = 0xFF22D3EE.toInt()
        val accentGreen = 0xFF22C55E.toInt()
        val accentAmber = 0xFFF59E0B.toInt()
        val accentRed = 0xFFEF4444.toInt()
        val accentViolet = 0xFFA855F7.toInt()
    }

    private lateinit var usbDot: View
    private lateinit var statusLabel: TextView
    private lateinit var startButton: Button
    private lateinit var masterMuteButton: Button
    private lateinit var lockButton: Button
    private lateinit var lockOverlay: FrameLayout

    private lateinit var outputMeterView: SegmentedMeterView
    private lateinit var outputMeterLabel: TextView
    private lateinit var outputClipBadge: TextView
    private var outputClipHoldUntilMs = 0L

    private val inputMeterViews = arrayOfNulls<SegmentedMeterView>(2)
    private val inputMeterLabels = arrayOfNulls<TextView>(2)
    private val gainFaders = arrayOfNulls<VerticalFaderView>(2)
    private val gainValueLabels = arrayOfNulls<TextView>(2)
    private val muteButtons = arrayOfNulls<Button>(2)
    private val soloButtons = arrayOfNulls<Button>(2)
    private val routeButtons = arrayOfNulls<Button>(2)
    private val activePresetChips = arrayOfNulls<TextView>(2)

    private val fxTabButtons = Array(2) { arrayOfNulls<Button>(4) }
    private val fxSectionContainers = Array(2) { arrayOfNulls<LinearLayout>(4) }
    private val selectedFxTab = IntArray(2) { 0 }

    private val meterHandler = Handler(Looper.getMainLooper())
    private var engineStarted = false
    private var liveLocked = false
    private var masterMuted = false
    private var suppressAudioCallbacks = false

    private val meterUpdate = object : Runnable {
        override fun run() {
            if (engineStarted) {
                updateMeters()
                meterHandler.postDelayed(this, 80L)
            }
        }
    }

    private var gain1 = 0.75f
    private var gain2 = 0.65f
    private var mute1 = false
    private var mute2 = false
    private var solo1 = false
    private var solo2 = false

    // 0 = ESTÉREO, 1 = MONO L, 2 = MONO R
    private val inputRouteMode = intArrayOf(0, 0)
    private val hpfEnabled = booleanArrayOf(false, false)
    private val hpfButtons = arrayOfNulls<Button>(2)

    private val eqLow = floatArrayOf(0f, 0f)
    private val eqMid = floatArrayOf(0f, 0f)
    private val eqHigh = floatArrayOf(0f, 0f)
    private val eqKnobs = Array(2) { arrayOfNulls<RotaryKnobView>(3) }
    private val eqLabels = Array(2) { arrayOfNulls<TextView>(3) }

    private val compressorEnabled = booleanArrayOf(false, false)
    private val compressorThreshold = floatArrayOf(-18f, -18f)
    private val compressorRatio = floatArrayOf(3f, 3f)
    private val compressorAttack = floatArrayOf(10f, 10f)
    private val compressorRelease = floatArrayOf(100f, 100f)
    private val compressorMakeup = floatArrayOf(0f, 0f)
    private val compressorKnobs = Array(2) { arrayOfNulls<RotaryKnobView>(5) }
    private val compressorLabels = Array(2) { arrayOfNulls<TextView>(5) }
    private val compressorButtons = arrayOfNulls<Button>(2)
    private val compressorGrBars = arrayOfNulls<GainReductionBarView>(2)
    private val compressorGrLabels = arrayOfNulls<TextView>(2)

    private val reverbEnabled = booleanArrayOf(false, false)
    private val reverbMix = floatArrayOf(0.25f, 0.25f)
    private val reverbDecay = floatArrayOf(0.65f, 0.65f)
    private val reverbKnobs = Array(2) { arrayOfNulls<RotaryKnobView>(2) }
    private val reverbLabels = Array(2) { arrayOfNulls<TextView>(2) }
    private val reverbButtons = arrayOfNulls<Button>(2)

    private val delayEnabled = booleanArrayOf(false, false)
    private val delayTime = floatArrayOf(300f, 300f)
    private val delayFeedback = floatArrayOf(35f, 35f)
    private val delayMix = floatArrayOf(25f, 25f)
    private val delayKnobs = Array(2) { arrayOfNulls<RotaryKnobView>(3) }
    private val delayLabels = Array(2) { arrayOfNulls<TextView>(3) }
    private val delayButtons = arrayOfNulls<Button>(2)
    private val lastTapTempoMs = longArrayOf(0L, 0L)

    companion object {
        init {
            System.loadLibrary("umc22_audio")
        }
    }

    private external fun nativeStart(): Boolean
    private external fun nativeStop()
    private external fun nativeGetMeters(): FloatArray
    private external fun nativeConsumeDisconnected(): Boolean
    private external fun nativeSetGains(g1: Float, g2: Float)
    private external fun nativeSetInputRoute(channel: Int, mode: Int)
    private external fun nativeSetHpf(channel: Int, enabled: Boolean)
    private external fun nativeSetMutes(m1: Boolean, m2: Boolean)
    private external fun nativeSetMasterMute(muted: Boolean)
    private external fun nativeSetSolos(s1: Boolean, s2: Boolean)
    private external fun nativeSetEq(channel: Int, low: Float, mid: Float, high: Float)
    private external fun nativeSetCompressor(
        channel: Int,
        enabled: Boolean,
        threshold: Float,
        ratio: Float,
        attackMs: Float,
        releaseMs: Float,
        makeupDb: Float
    )
    private external fun nativeSetReverb(channel: Int, enabled: Boolean, mix: Float, decay: Float)
    private external fun nativeSetDelay(
        channel: Int,
        enabled: Boolean,
        timeMs: Float,
        feedback: Float,
        mix: Float
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Palette.bgBase)
            fitsSystemWindows = true
        }

        val mainColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        mainColumn.addView(buildTopConsoleHeader())

        val bodyScroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val bodyContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(24))
        }

        val isLandscapeOrTablet = resources.configuration.smallestScreenWidthDp >= 600 ||
            resources.configuration.screenWidthDp >= 640

        if (isLandscapeOrTablet) {
            val dualRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            val ch1Card = buildChannelConsoleCard(
                title = "CH1 · ENTRADA 1",
                subtitle = "NIVEL POST-PREAMP · MIC / LINE 1",
                initialPct = (gain1 * 100f).roundToInt(),
                defaultPct = 75,
                channel = 1,
                accentColor = Palette.accentCyan
            ).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(6)
                }
            }
            val ch2Card = buildChannelConsoleCard(
                title = "CH2 · ENTRADA 2",
                subtitle = "NIVEL POST-PREAMP · INST / LINE 2",
                initialPct = (gain2 * 100f).roundToInt(),
                defaultPct = 65,
                channel = 2,
                accentColor = Palette.accentViolet
            ).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(6)
                }
            }
            dualRow.addView(ch1Card)
            dualRow.addView(ch2Card)
            bodyContent.addView(dualRow)
        } else {
            bodyContent.addView(
                buildChannelConsoleCard(
                    title = "CH1 · ENTRADA 1",
                    subtitle = "NIVEL POST-PREAMP · MIC / LINE 1",
                    initialPct = (gain1 * 100f).roundToInt(),
                    defaultPct = 75,
                    channel = 1,
                    accentColor = Palette.accentCyan
                ).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dp(12)
                    }
                }
            )
            bodyContent.addView(
                buildChannelConsoleCard(
                    title = "CH2 · ENTRADA 2",
                    subtitle = "NIVEL POST-PREAMP · INST / LINE 2",
                    initialPct = (gain2 * 100f).roundToInt(),
                    defaultPct = 65,
                    channel = 2,
                    accentColor = Palette.accentViolet
                ).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dp(12)
                    }
                }
            )
        }

        bodyContent.addView(buildStageNotesCard())
        bodyScroll.addView(bodyContent)
        mainColumn.addView(bodyScroll)
        rootContainer.addView(mainColumn)

        lockOverlay = buildStageLockOverlay()
        rootContainer.addView(lockOverlay)

        setContentView(rootContainer)
        updateUsbStatus()
    }

    private fun buildTopConsoleHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.bgHeader)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        titleCol.addView(TextView(this).apply {
            text = "UMC22 LIVE MIXER"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textPrimary)
            letterSpacing = 0.04f
        })

        titleCol.addView(TextView(this).apply {
            text = "v1.3.0 PRO · CONSOLA EN VIVO"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(Palette.textSecondary)
        })

        masterMuteButton = Button(this).apply {
            text = "MUTE ALL"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(10), dp(6), dp(10), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dp(6)
            }
            applyMasterMuteStyle(this, false)
            setOnClickListener {
                masterMuted = !masterMuted
                applyMasterMuteStyle(this, masterMuted)
                if (engineStarted) {
                    nativeSetMasterMute(masterMuted)
                }
            }
        }

        lockButton = Button(this).apply {
            text = "BLOQUEAR"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            background = pillDrawable(Palette.bgCardAlt, Palette.borderSubtle, dp(8).toFloat())
            setPadding(dp(10), dp(6), dp(10), dp(6))
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { setLiveLocked(true) }
        }

        titleRow.addView(titleCol)
        titleRow.addView(masterMuteButton)
        titleRow.addView(lockButton)
        header.addView(titleRow)

        val usbPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(8).toFloat())
            setPadding(dp(10), dp(7), dp(10), dp(7))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
            setOnClickListener { updateUsbStatus() }
        }

        usbDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply {
                marginEnd = dp(8)
            }
            background = circleDrawable(Palette.accentAmber)
        }

        statusLabel = TextView(this).apply {
            text = "Comprobando USB…"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Palette.textSecondary)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        usbPill.addView(usbDot)
        usbPill.addView(statusLabel)
        header.addView(usbPill)

        val masterBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(10).toFloat())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }

        startButton = Button(this).apply {
            text = "INICIAR MONITOREO"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = pillDrawable(Palette.accentGreen, Palette.accentGreen, dp(8).toFloat())
            setPadding(dp(14), dp(10), dp(14), dp(10))
            minHeight = 0
            minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            setOnClickListener {
                if (engineStarted) {
                    stopEngine()
                } else if (
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startEngine()
                } else {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
                }
            }
        }

        outputClipBadge = TextView(this).apply {
            text = "CLIP OK"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.accentGreen)
            gravity = Gravity.CENTER
            background = pillDrawable(0x1822C55E, Palette.accentGreen, dp(8).toFloat())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }

        actionRow.addView(startButton)
        actionRow.addView(outputClipBadge)
        masterBox.addView(actionRow)

        val meterHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(4)
            }
        }

        meterHeader.addView(TextView(this).apply {
            text = "SALIDA MASTER"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        outputMeterLabel = TextView(this).apply {
            text = "OUT: -∞ dBFS"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }

        meterHeader.addView(outputMeterLabel)
        masterBox.addView(meterHeader)

        outputMeterView = SegmentedMeterView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(14)
            )
        }
        masterBox.addView(outputMeterView)
        header.addView(masterBox)

        return header
    }

    private fun applyMasterMuteStyle(btn: Button, muted: Boolean) {
        btn.text = if (muted) "MUTED" else "MUTE ALL"
        if (muted) {
            btn.setTextColor(Color.WHITE)
            btn.background = pillDrawable(Palette.accentRed, Palette.accentRed, dp(8).toFloat())
        } else {
            btn.setTextColor(Palette.accentRed)
            btn.background = pillDrawable(0x18EF4444, Palette.accentRed, dp(8).toFloat())
        }
    }

    private fun buildChannelConsoleCard(
        title: String,
        subtitle: String,
        initialPct: Int,
        defaultPct: Int,
        channel: Int,
        accentColor: Int
    ): LinearLayout {
        val idx = channel - 1
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(12).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10)
            }
        }

        val nameBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        nameBox.addView(TextView(this).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentColor)
        })
        nameBox.addView(TextView(this).apply {
            text = subtitle
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTextColor(Palette.textMuted)
        })

        val presetChip = TextView(this).apply {
            text = "PRESETS ▾"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textPrimary)
            background = pillDrawable(Palette.bgCardAlt, accentColor, dp(8).toFloat())
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setOnClickListener { showPresets(channel) }
        }
        activePresetChips[idx] = presetChip

        topBar.addView(nameBox)
        topBar.addView(presetChip)
        card.addView(topBar)

        val stripRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pillDrawable(Palette.bgCardAlt, Palette.borderSubtle, dp(10).toFloat())
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10)
            }
        }

        val faderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(54), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(10)
            }
        }

        val fader = VerticalFaderView(this, accentColor).apply {
            setValue(initialPct / 100f)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(156))
            setOnValueChangeListener { norm ->
                val pct = (norm * 100f).roundToInt().coerceIn(0, 100)
                gainValueLabels[idx]?.text = "$pct%"
                if (channel == 1) gain1 = pct / 100f else gain2 = pct / 100f
                if (!suppressAudioCallbacks && engineStarted) {
                    nativeSetGains(gain1, gain2)
                }
            }
            setOnDoubleTapListener {
                val resetNorm = defaultPct / 100f
                setValue(resetNorm)
                gainValueLabels[idx]?.text = "$defaultPct%"
                if (channel == 1) gain1 = resetNorm else gain2 = resetNorm
                if (!suppressAudioCallbacks && engineStarted) {
                    nativeSetGains(gain1, gain2)
                }
            }
        }
        gainFaders[idx] = fader

        val pctLabel = TextView(this).apply {
            text = "$initialPct%"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }
        gainValueLabels[idx] = pctLabel

        faderCol.addView(fader)
        faderCol.addView(pctLabel)

        val rightCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val inMeterHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(4)
            }
        }

        inMeterHeader.addView(TextView(this).apply {
            text = "ENTRADA"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        val inLabel = TextView(this).apply {
            text = "-∞ dBFS"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        inputMeterLabels[idx] = inLabel
        inMeterHeader.addView(inLabel)
        rightCol.addView(inMeterHeader)

        val inMeter = SegmentedMeterView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(14)
            ).apply {
                bottomMargin = dp(10)
            }
        }
        inputMeterViews[idx] = inMeter
        rightCol.addView(inMeter)

        // Fila de enrutamiento Mono/Estéreo + HPF 90Hz
        val utilRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }

        val routeBtn = Button(this).apply {
            text = routeModeLabel(inputRouteMode[idx])
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textPrimary)
            background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(7).toFloat())
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(6), dp(7), dp(6), dp(7))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(4)
            }
            setOnClickListener {
                inputRouteMode[idx] = (inputRouteMode[idx] + 1) % 3
                text = routeModeLabel(inputRouteMode[idx])
                if (engineStarted) {
                    nativeSetInputRoute(idx, inputRouteMode[idx])
                }
            }
        }
        routeButtons[idx] = routeBtn

        val hpfBtn = Button(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(6), dp(7), dp(6), dp(7))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(4)
            }
            applyHpfStyle(this, hpfEnabled[idx], accentColor)
            setOnClickListener {
                hpfEnabled[idx] = !hpfEnabled[idx]
                applyHpfStyle(this, hpfEnabled[idx], accentColor)
                if (engineStarted) {
                    nativeSetHpf(idx, hpfEnabled[idx])
                }
            }
        }
        hpfButtons[idx] = hpfBtn

        utilRow.addView(routeBtn)
        utilRow.addView(hpfBtn)
        rightCol.addView(utilRow)

        val msRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val muteBtn = Button(this).apply {
            text = "MUTE"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(9), dp(8), dp(9))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(4)
            }
            applyMuteStyle(this, if (channel == 1) mute1 else mute2)
            setOnClickListener {
                if (channel == 1) {
                    mute1 = !mute1
                    applyMuteStyle(this, mute1)
                } else {
                    mute2 = !mute2
                    applyMuteStyle(this, mute2)
                }
                if (engineStarted) nativeSetMutes(mute1, mute2)
            }
        }
        muteButtons[idx] = muteBtn

        val soloBtn = Button(this).apply {
            text = "SOLO"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(9), dp(8), dp(9))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(4)
            }
            applySoloStyle(this, if (channel == 1) solo1 else solo2)
            setOnClickListener {
                if (channel == 1) {
                    solo1 = !solo1
                    applySoloStyle(this, solo1)
                } else {
                    solo2 = !solo2
                    applySoloStyle(this, solo2)
                }
                if (engineStarted) nativeSetSolos(solo1, solo2)
            }
        }
        soloButtons[idx] = soloBtn

        msRow.addView(muteBtn)
        msRow.addView(soloBtn)
        rightCol.addView(msRow)

        stripRow.addView(faderCol)
        stripRow.addView(rightCol)
        card.addView(stripRow)

        val tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }

        val tabTitles = arrayOf("EQ", "COMP", "REVERB", "DELAY")
        for (t in 0..3) {
            val btn = Button(this).apply {
                text = tabTitles[t]
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTypeface(typeface, Typeface.BOLD)
                minHeight = 0
                minimumHeight = 0
                setPadding(dp(4), dp(8), dp(4), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (t > 0) marginStart = dp(4)
                }
                setOnClickListener { selectFxTab(idx, t, accentColor) }
            }
            fxTabButtons[idx][t] = btn
            tabBar.addView(btn)
        }
        card.addView(tabBar)

        val fxHost = FrameLayout(this).apply {
            background = pillDrawable(Palette.bgCardAlt, Palette.borderSubtle, dp(10).toFloat())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }

        val eqBox = buildEqModule(channel, accentColor)
        val compBox = buildCompressorModule(channel, accentColor)
        val revBox = buildReverbModule(channel, accentColor)
        val delBox = buildDelayModule(channel, accentColor)

        fxSectionContainers[idx][0] = eqBox
        fxSectionContainers[idx][1] = compBox
        fxSectionContainers[idx][2] = revBox
        fxSectionContainers[idx][3] = delBox

        fxHost.addView(eqBox)
        fxHost.addView(compBox)
        fxHost.addView(revBox)
        fxHost.addView(delBox)

        selectFxTab(idx, 0, accentColor)
        card.addView(fxHost)

        return card
    }

    private fun routeModeLabel(mode: Int): String = when (mode) {
        1 -> "IN: MONO L"
        2 -> "IN: MONO R"
        else -> "IN: ESTÉREO"
    }

    private fun applyHpfStyle(btn: Button, enabled: Boolean, accentColor: Int) {
        btn.text = if (enabled) "HPF 90Hz ON" else "HPF 90Hz"
        if (enabled) {
            btn.setTextColor(Palette.bgBase)
            btn.background = pillDrawable(accentColor, accentColor, dp(7).toFloat())
        } else {
            btn.setTextColor(Palette.textSecondary)
            btn.background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(7).toFloat())
        }
    }

    private fun selectFxTab(channelIndex: Int, tabIndex: Int, accentColor: Int) {
        selectedFxTab[channelIndex] = tabIndex
        for (i in 0..3) {
            val active = i == tabIndex
            fxTabButtons[channelIndex][i]?.apply {
                setTextColor(if (active) Palette.bgBase else Palette.textSecondary)
                background = if (active) {
                    pillDrawable(accentColor, accentColor, dp(7).toFloat())
                } else {
                    pillDrawable(Palette.bgCardAlt, Palette.borderSubtle, dp(7).toFloat())
                }
            }
            fxSectionContainers[channelIndex][i]?.visibility =
                if (active) View.VISIBLE else View.GONE
        }
    }

    private fun applyMuteStyle(btn: Button, active: Boolean) {
        btn.text = if (active) "MUTE ON" else "MUTE"
        if (active) {
            btn.setTextColor(Color.WHITE)
            btn.background = pillDrawable(Palette.accentRed, Palette.accentRed, dp(8).toFloat())
        } else {
            btn.setTextColor(Palette.textSecondary)
            btn.background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(8).toFloat())
        }
    }

    private fun applySoloStyle(btn: Button, active: Boolean) {
        btn.text = if (active) "SOLO ON" else "SOLO"
        if (active) {
            btn.setTextColor(Palette.bgBase)
            btn.background = pillDrawable(Palette.accentAmber, Palette.accentAmber, dp(8).toFloat())
        } else {
            btn.setTextColor(Palette.textSecondary)
            btn.background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(8).toFloat())
        }
    }

    private fun buildEqModule(channel: Int, accentColor: Int): LinearLayout {
        val idx = channel - 1
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }
        headerRow.addView(TextView(this).apply {
            text = "ECUALIZADOR 3 BANDAS"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentColor)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        headerRow.addView(TextView(this).apply {
            text = "Doble toque: 0 dB"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTextColor(Palette.textMuted)
        })
        box.addView(headerRow)

        val knobsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val bands = arrayOf("LOW", "MID", "HIGH")
        for (b in 0..2) {
            val currentDb = when (b) {
                0 -> eqLow[idx]
                1 -> eqMid[idx]
                else -> eqHigh[idx]
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val knob = RotaryKnobView(this, accentColor, bipolar = true).apply {
                setNormalizedValue(((currentDb + 12f) / 24f).coerceIn(0f, 1f))
                layoutParams = LinearLayout.LayoutParams(dp(62), dp(62))
                setOnValueChangeListener { norm ->
                    val db = ((norm * 24f) - 12f).roundToInt().toFloat().coerceIn(-12f, 12f)
                    when (b) {
                        0 -> eqLow[idx] = db
                        1 -> eqMid[idx] = db
                        else -> eqHigh[idx] = db
                    }
                    eqLabels[idx][b]?.text = "${db.toInt()} dB"
                    if (!suppressAudioCallbacks && engineStarted) {
                        nativeSetEq(idx, eqLow[idx], eqMid[idx], eqHigh[idx])
                    }
                }
                setOnDoubleTapListener {
                    setNormalizedValue(0.5f)
                    when (b) {
                        0 -> eqLow[idx] = 0f
                        1 -> eqMid[idx] = 0f
                        else -> eqHigh[idx] = 0f
                    }
                    eqLabels[idx][b]?.text = "0 dB"
                    if (!suppressAudioCallbacks && engineStarted) {
                        nativeSetEq(idx, eqLow[idx], eqMid[idx], eqHigh[idx])
                    }
                }
            }
            eqKnobs[idx][b] = knob

            val bandName = TextView(this).apply {
                text = bands[b]
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Palette.textSecondary)
                setPadding(0, dp(3), 0, 0)
            }
            val valLabel = TextView(this).apply {
                text = "${currentDb.toInt()} dB"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                typeface = Typeface.MONOSPACE
                setTextColor(Palette.textPrimary)
            }
            eqLabels[idx][b] = valLabel

            col.addView(knob)
            col.addView(bandName)
            col.addView(valLabel)
            knobsRow.addView(col)
        }

        box.addView(knobsRow)
        return box
    }

    private fun buildCompressorModule(channel: Int, accentColor: Int): LinearLayout {
        val idx = channel - 1
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(6)
            }
        }
        topRow.addView(TextView(this).apply {
            text = "COMPRESOR DINÁMICO"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentColor)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        val toggle = Button(this).apply {
            minHeight = 0
            minimumHeight = 0
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            applyModuleToggleStyle(this, compressorEnabled[idx], accentColor)
            setOnClickListener {
                compressorEnabled[idx] = !compressorEnabled[idx]
                applyModuleToggleStyle(this, compressorEnabled[idx], accentColor)
                if (!compressorEnabled[idx]) {
                    compressorGrBars[idx]?.setReductionDb(0f)
                    compressorGrLabels[idx]?.text = "GR: 0.0 dB"
                }
                if (!suppressAudioCallbacks) sendCompressorSettings(idx)
            }
        }
        compressorButtons[idx] = toggle
        topRow.addView(toggle)
        box.addView(topRow)

        val grHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(3)
            }
        }
        grHeader.addView(TextView(this).apply {
            text = "REDUCCIÓN DE GANANCIA"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setTextColor(Palette.textMuted)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val grLbl = TextView(this).apply {
            text = "GR: 0.0 dB"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.accentAmber)
        }
        compressorGrLabels[idx] = grLbl
        grHeader.addView(grLbl)
        box.addView(grHeader)

        val grBar = GainReductionBarView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(8)
            ).apply {
                bottomMargin = dp(10)
            }
        }
        compressorGrBars[idx] = grBar
        box.addView(grBar)

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        row1.addView(createParamKnobCell(idx, 0, "THRESH", -60f, 0f, compressorThreshold[idx], " dB", accentColor))
        row1.addView(createParamKnobCell(idx, 1, "RATIO", 1f, 20f, compressorRatio[idx], ":1", accentColor))
        row1.addView(createParamKnobCell(idx, 2, "ATTACK", 1f, 100f, compressorAttack[idx], " ms", accentColor))

        row2.addView(createParamKnobCell(idx, 3, "RELEASE", 10f, 500f, compressorRelease[idx], " ms", accentColor))
        row2.addView(createParamKnobCell(idx, 4, "MAKEUP", 0f, 24f, compressorMakeup[idx], " dB", accentColor))

        box.addView(row1)
        box.addView(row2)
        return box
    }

    private fun createParamKnobCell(
        channelIndex: Int,
        paramType: Int,
        title: String,
        minVal: Float,
        maxVal: Float,
        initialVal: Float,
        suffix: String,
        accentColor: Int
    ): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val normInit = ((initialVal - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
        val knob = RotaryKnobView(this, accentColor, bipolar = false).apply {
            setNormalizedValue(normInit)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            setOnValueChangeListener { norm ->
                val raw = minVal + (maxVal - minVal) * norm
                val formatted = formatCompressorParamValue(raw, paramType)
                when (paramType) {
                    0 -> compressorThreshold[channelIndex] = raw.roundToInt().toFloat()
                    1 -> compressorRatio[channelIndex] = (raw * 10f).roundToInt() / 10f
                    2 -> compressorAttack[channelIndex] = raw.roundToInt().toFloat()
                    3 -> compressorRelease[channelIndex] = raw.roundToInt().toFloat()
                    4 -> compressorMakeup[channelIndex] = raw.roundToInt().toFloat()
                }
                compressorLabels[channelIndex][paramType]?.text = "$formatted$suffix"
                if (!suppressAudioCallbacks) sendCompressorSettings(channelIndex)
            }
        }
        compressorKnobs[channelIndex][paramType] = knob

        val nameView = TextView(this).apply {
            text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            setPadding(0, dp(2), 0, 0)
        }
        val valView = TextView(this).apply {
            text = "${formatCompressorParamValue(initialVal, paramType)}$suffix"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        compressorLabels[channelIndex][paramType] = valView

        col.addView(knob)
        col.addView(nameView)
        col.addView(valView)
        return col
    }

    private fun formatCompressorParamValue(value: Float, type: Int): String {
        return if (type == 1) String.format(Locale.US, "%.1f", value)
        else value.roundToInt().toString()
    }

    private fun sendCompressorSettings(index: Int) {
        if (!engineStarted) return
        nativeSetCompressor(
            index,
            compressorEnabled[index],
            compressorThreshold[index],
            compressorRatio[index],
            compressorAttack[index],
            compressorRelease[index],
            compressorMakeup[index]
        )
    }

    private fun buildReverbModule(channel: Int, accentColor: Int): LinearLayout {
        val idx = channel - 1
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10)
            }
        }
        topRow.addView(TextView(this).apply {
            text = "REVERB DE SALA"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentColor)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        val toggle = Button(this).apply {
            minHeight = 0
            minimumHeight = 0
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            applyModuleToggleStyle(this, reverbEnabled[idx], accentColor)
            setOnClickListener {
                reverbEnabled[idx] = !reverbEnabled[idx]
                applyModuleToggleStyle(this, reverbEnabled[idx], accentColor)
                if (!suppressAudioCallbacks) sendReverbSettings(idx)
            }
        }
        reverbButtons[idx] = toggle
        topRow.addView(toggle)
        box.addView(topRow)

        val knobsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val mixCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val mixInitPct = (reverbMix[idx] * 100f).roundToInt().coerceIn(0, 100)
        val mixKnob = RotaryKnobView(this, accentColor, bipolar = false).apply {
            setNormalizedValue(mixInitPct / 100f)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
            setOnValueChangeListener { norm ->
                val pct = (norm * 100f).roundToInt().coerceIn(0, 100)
                reverbMix[idx] = pct / 100f
                reverbLabels[idx][0]?.text = "$pct%"
                if (!suppressAudioCallbacks) sendReverbSettings(idx)
            }
        }
        reverbKnobs[idx][0] = mixKnob
        val mixLbl = TextView(this).apply {
            text = "$mixInitPct%"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        reverbLabels[idx][0] = mixLbl
        mixCol.addView(mixKnob)
        mixCol.addView(TextView(this).apply {
            text = "MIX"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            setPadding(0, dp(3), 0, 0)
        })
        mixCol.addView(mixLbl)

        val decCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val decInitPct = (reverbDecay[idx] * 100f).roundToInt().coerceIn(20, 92)
        val decKnob = RotaryKnobView(this, accentColor, bipolar = false).apply {
            setNormalizedValue(((decInitPct - 20f) / 72f).coerceIn(0f, 1f))
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
            setOnValueChangeListener { norm ->
                val pct = (20f + norm * 72f).roundToInt().coerceIn(20, 92)
                reverbDecay[idx] = pct / 100f
                reverbLabels[idx][1]?.text = "$pct%"
                if (!suppressAudioCallbacks) sendReverbSettings(idx)
            }
        }
        reverbKnobs[idx][1] = decKnob
        val decLbl = TextView(this).apply {
            text = "$decInitPct%"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        reverbLabels[idx][1] = decLbl
        decCol.addView(decKnob)
        decCol.addView(TextView(this).apply {
            text = "DECAY"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            setPadding(0, dp(3), 0, 0)
        })
        decCol.addView(decLbl)

        knobsRow.addView(mixCol)
        knobsRow.addView(decCol)
        box.addView(knobsRow)
        return box
    }

    private fun sendReverbSettings(index: Int) {
        if (!engineStarted) return
        nativeSetReverb(index, reverbEnabled[index], reverbMix[index], reverbDecay[index])
    }

    private fun buildDelayModule(channel: Int, accentColor: Int): LinearLayout {
        val idx = channel - 1
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10)
            }
        }
        topRow.addView(TextView(this).apply {
            text = "DELAY / ECO"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(accentColor)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        val tapBtn = Button(this).apply {
            text = "TAP"
            minHeight = 0
            minimumHeight = 0
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textPrimary)
            background = pillDrawable(Palette.bgCard, accentColor, dp(6).toFloat())
            setPadding(dp(10), dp(5), dp(10), dp(5))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dp(6)
            }
            setOnClickListener {
                val now = SystemClock.elapsedRealtime()
                val prev = lastTapTempoMs[idx]
                lastTapTempoMs[idx] = now
                if (prev > 0L) {
                    val delta = (now - prev).coerceIn(50L, 800L)
                    delayTime[idx] = delta.toFloat()
                    delayKnobs[idx][0]?.setNormalizedValue(((delta - 50f) / 750f).coerceIn(0f, 1f))
                    delayLabels[idx][0]?.text = "$delta ms"
                    if (!suppressAudioCallbacks) sendDelaySettings(idx)
                }
            }
        }

        val toggle = Button(this).apply {
            minHeight = 0
            minimumHeight = 0
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            applyModuleToggleStyle(this, delayEnabled[idx], accentColor)
            setOnClickListener {
                delayEnabled[idx] = !delayEnabled[idx]
                applyModuleToggleStyle(this, delayEnabled[idx], accentColor)
                if (!suppressAudioCallbacks) sendDelaySettings(idx)
            }
        }
        delayButtons[idx] = toggle
        topRow.addView(tapBtn)
        topRow.addView(toggle)
        box.addView(topRow)

        val knobsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val timeCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val timeInit = delayTime[idx].roundToInt().coerceIn(50, 800)
        val timeKnob = RotaryKnobView(this, accentColor, bipolar = false).apply {
            setNormalizedValue(((timeInit - 50f) / 750f).coerceIn(0f, 1f))
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
            setOnValueChangeListener { norm ->
                val ms = (50f + norm * 750f).roundToInt().coerceIn(50, 800)
                delayTime[idx] = ms.toFloat()
                delayLabels[idx][0]?.text = "$ms ms"
                if (!suppressAudioCallbacks) sendDelaySettings(idx)
            }
        }
        delayKnobs[idx][0] = timeKnob
        val timeLbl = TextView(this).apply {
            text = "$timeInit ms"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        delayLabels[idx][0] = timeLbl
        timeCol.addView(timeKnob)
        timeCol.addView(TextView(this).apply {
            text = "TIME"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            setPadding(0, dp(3), 0, 0)
        })
        timeCol.addView(timeLbl)

        val fbCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val fbInit = delayFeedback[idx].roundToInt().coerceIn(0, 85)
        val fbKnob = RotaryKnobView(this, accentColor, bipolar = false).apply {
            setNormalizedValue((fbInit / 85f).coerceIn(0f, 1f))
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
            setOnValueChangeListener { norm ->
                val pct = (norm * 85f).roundToInt().coerceIn(0, 85)
                delayFeedback[idx] = pct.toFloat()
                delayLabels[idx][1]?.text = "$pct%"
                if (!suppressAudioCallbacks) sendDelaySettings(idx)
            }
        }
        delayKnobs[idx][1] = fbKnob
        val fbLbl = TextView(this).apply {
            text = "$fbInit%"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        delayLabels[idx][1] = fbLbl
        fbCol.addView(fbKnob)
        fbCol.addView(TextView(this).apply {
            text = "FEEDBACK"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            setPadding(0, dp(3), 0, 0)
        })
        fbCol.addView(fbLbl)

        val mixCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val mixInit = delayMix[idx].roundToInt().coerceIn(0, 100)
        val mixKnob = RotaryKnobView(this, accentColor, bipolar = false).apply {
            setNormalizedValue((mixInit / 100f).coerceIn(0f, 1f))
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
            setOnValueChangeListener { norm ->
                val pct = (norm * 100f).roundToInt().coerceIn(0, 100)
                delayMix[idx] = pct.toFloat()
                delayLabels[idx][2]?.text = "$pct%"
                if (!suppressAudioCallbacks) sendDelaySettings(idx)
            }
        }
        delayKnobs[idx][2] = mixKnob
        val mixLbl = TextView(this).apply {
            text = "$mixInit%"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.textPrimary)
        }
        delayLabels[idx][2] = mixLbl
        mixCol.addView(mixKnob)
        mixCol.addView(TextView(this).apply {
            text = "MIX"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.textSecondary)
            setPadding(0, dp(3), 0, 0)
        })
        mixCol.addView(mixLbl)

        knobsRow.addView(timeCol)
        knobsRow.addView(fbCol)
        knobsRow.addView(mixCol)
        box.addView(knobsRow)
        return box
    }

    private fun sendDelaySettings(index: Int) {
        if (!engineStarted) return
        nativeSetDelay(
            index,
            delayEnabled[index],
            delayTime[index],
            delayFeedback[index] / 100f,
            delayMix[index] / 100f
        )
    }

    private fun applyModuleToggleStyle(btn: Button, enabled: Boolean, accentColor: Int) {
        btn.text = if (enabled) "ACTIVO" else "OFF"
        if (enabled) {
            btn.setTextColor(Palette.bgBase)
            btn.background = pillDrawable(accentColor, accentColor, dp(6).toFloat())
        } else {
            btn.setTextColor(Palette.textSecondary)
            btn.background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(6).toFloat())
        }
    }

    private fun buildStageNotesCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = pillDrawable(Palette.bgCard, Palette.borderSubtle, dp(10).toFloat())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(TextView(this@MainActivity).apply {
                text = "REFERENCIA RÁPIDA EN VIVO"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Palette.accentCyan)
                setPadding(0, 0, 0, dp(4))
            })
            addView(TextView(this@MainActivity).apply {
                text = "• La ganancia analógica (+48V / GAIN) se regula en la UMC22; los faders ajustan el nivel digital post-preamp.
" +
                    "• Usa IN: MONO L / MONO R si conectas un micrófono o guitarra a una sola entrada física.
" +
                    "• Doble toque en faders vuelve al nivel base y en EQ vuelve a 0 dB. HPF 90Hz limpia retumbos de escenario.
" +
                    "• Usa MUTE ALL en emergencia y BLOQUEAR para proteger la consola durante la presentación."
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTextColor(Palette.textSecondary)
                setLineSpacing(dp(2).toFloat(), 1f)
            })
        }
    }

    private fun buildStageLockOverlay(): FrameLayout {
        val overlay = FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(0xD9070A0F.toInt())
            isClickable = true
            isFocusable = true
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = pillDrawable(Palette.bgCard, Palette.accentAmber, dp(14).toFloat())
            setPadding(dp(24), dp(24), dp(24), dp(24))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        }

        card.addView(TextView(this).apply {
            text = "MODO EN VIVO BLOQUEADO"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.accentAmber)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(6))
        })

        card.addView(TextView(this).apply {
            text = "Controles protegidos contra toques accidentales.\nEl audio y los vúmetros siguen activos."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Palette.textSecondary)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
        })

        card.addView(Button(this).apply {
            text = "DESBLOQUEAR CONSOLA"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Palette.bgBase)
            background = pillDrawable(Palette.accentAmber, Palette.accentAmber, dp(8).toFloat())
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setOnClickListener { setLiveLocked(false) }
        })

        overlay.addView(card)
        return overlay
    }

    private fun setLiveLocked(locked: Boolean) {
        liveLocked = locked
        lockOverlay.visibility = if (locked) View.VISIBLE else View.GONE
        lockButton.text = if (locked) "BLOQUEADO" else "BLOQUEAR"
        lockButton.setTextColor(if (locked) Palette.accentAmber else Palette.textSecondary)
    }

    private fun updateMeters() {
        if (!engineStarted) return

        val disconnected = try {
            nativeConsumeDisconnected()
        } catch (_: Exception) {
            false
        }
        if (disconnected) {
            stopEngine()
            updateUsbStatus()
            usbDot.background = circleDrawable(Palette.accentRed)
            statusLabel.text = "Audio interrumpido · Reconecta la UMC22 por OTG"
            statusLabel.setTextColor(Palette.accentRed)
            return
        }

        val values = try {
            nativeGetMeters()
        } catch (_: Exception) {
            return
        }
        if (values.size < 6) return

        for (channel in 0..1) {
            val peak = values[channel].coerceIn(0f, 1f)
            val db = peakToDb(peak)
            val clipping = values[3 + channel] > 0.5f
            inputMeterLabels[channel]?.apply {
                text = if (clipping) "CLIP! ${formatDb(db)} dBFS"
                else "${formatDb(db)} dBFS"
                setTextColor(if (clipping) Palette.accentRed else Palette.textPrimary)
            }
            inputMeterViews[channel]?.setLevel(peak, clipping)
        }

        val outputPeak = values[2].coerceIn(0f, 1f)
        val outputDb = peakToDb(outputPeak)
        val outputClipping = values[5] > 0.5f
        if (outputClipping) {
            outputClipHoldUntilMs = SystemClock.elapsedRealtime() + 1000L
        }
        val clipIsHeld = SystemClock.elapsedRealtime() < outputClipHoldUntilMs
        if (clipIsHeld) {
            outputClipBadge.text = "⚠ CLIP"
            outputClipBadge.setTextColor(Palette.accentRed)
            outputClipBadge.background = pillDrawable(0x28EF4444, Palette.accentRed, dp(8).toFloat())
        } else {
            outputClipBadge.text = "CLIP OK"
            outputClipBadge.setTextColor(Palette.accentGreen)
            outputClipBadge.background = pillDrawable(0x1822C55E, Palette.accentGreen, dp(8).toFloat())
        }

        outputMeterLabel.text = if (outputClipping) {
            "CLIP! ${formatDb(outputDb)} dBFS"
        } else {
            "OUT: ${formatDb(outputDb)} dBFS"
        }
        outputMeterLabel.setTextColor(if (outputClipping) Palette.accentRed else Palette.textPrimary)
        outputMeterView.setLevel(outputPeak, outputClipping)

        if (values.size >= 8) {
            for (ch in 0..1) {
                val gr = if (compressorEnabled[ch]) values[6 + ch].coerceIn(0f, 24f) else 0f
                compressorGrBars[ch]?.setReductionDb(gr)
                compressorGrLabels[ch]?.text = String.format(Locale.US, "GR: -%.1f dB", gr)
            }
        }
    }

    private fun peakToDb(peak: Float): Float {
        return if (peak <= 0.000001f) -60f
        else (20f * log10(peak)).coerceIn(-60f, 0f)
    }

    private fun formatDb(db: Float): String =
        if (db <= -59.9f) "-∞" else String.format(Locale.US, "%.1f", db)

    private fun updateUsbStatus() {
        val usb = getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = usb.deviceList.values

        if (devices.isEmpty()) {
            usbDot.background = circleDrawable(Palette.accentAmber)
            statusLabel.text = "USB: sin dispositivo · Conecta la UMC22 por OTG"
            statusLabel.setTextColor(Palette.accentAmber)
        } else {
            usbDot.background = circleDrawable(Palette.accentGreen)
            statusLabel.text = "USB (${devices.size}): " + devices.joinToString(" | ") {
                "${it.productName ?: "USB"} (VID ${it.vendorId}:PID ${it.productId})"
            }
            statusLabel.setTextColor(Palette.accentGreen)
        }
    }

    private fun startEngine() {
        if (engineStarted) return

        val started = nativeStart()
        engineStarted = started

        if (started) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            usbDot.background = circleDrawable(Palette.accentGreen)
            statusLabel.text = "Motor activo · Inicia a volumen bajo y revisa picos"
            statusLabel.setTextColor(Palette.accentGreen)
            startButton.text = "DETENER MONITOREO"
            startButton.background = pillDrawable(Palette.accentRed, Palette.accentRed, dp(8).toFloat())

            nativeSetGains(gain1, gain2)
            nativeSetMutes(mute1, mute2)
            nativeSetMasterMute(masterMuted)
            nativeSetSolos(solo1, solo2)

            for (channel in 0..1) {
                nativeSetInputRoute(channel, inputRouteMode[channel])
                nativeSetHpf(channel, hpfEnabled[channel])
                nativeSetEq(channel, eqLow[channel], eqMid[channel], eqHigh[channel])
                sendCompressorSettings(channel)
                sendReverbSettings(channel)
                sendDelaySettings(channel)
            }
            meterHandler.removeCallbacks(meterUpdate)
            meterHandler.post(meterUpdate)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            usbDot.background = circleDrawable(Palette.accentRed)
            statusLabel.text = "No se pudo abrir audio · Revisa conexión OTG y permisos"
            statusLabel.setTextColor(Palette.accentRed)
            startButton.text = "REINTENTAR"
            startButton.background = pillDrawable(Palette.accentAmber, Palette.accentAmber, dp(8).toFloat())
        }
    }

    private fun stopEngine() {
        meterHandler.removeCallbacks(meterUpdate)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (engineStarted) {
            nativeStop()
            engineStarted = false
        }

        if (::statusLabel.isInitialized) {
            statusLabel.text = "Motor detenido"
            statusLabel.setTextColor(Palette.textSecondary)
            usbDot.background = circleDrawable(Palette.textMuted)
        }

        if (::startButton.isInitialized) {
            startButton.text = "INICIAR MONITOREO"
            startButton.background = pillDrawable(Palette.accentGreen, Palette.accentGreen, dp(8).toFloat())
        }

        if (::outputMeterView.isInitialized) outputMeterView.setLevel(0f, false)
        inputMeterViews[0]?.setLevel(0f, false)
        inputMeterViews[1]?.setLevel(0f, false)
        compressorGrBars[0]?.setReductionDb(0f)
        compressorGrBars[1]?.setReductionDb(0f)
        compressorGrLabels[0]?.text = "GR: 0.0 dB"
        compressorGrLabels[1]?.text = "GR: 0.0 dB"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startEngine()
            } else {
                statusLabel.text = "Permiso de micrófono denegado."
                statusLabel.setTextColor(Palette.accentRed)
            }
        }
    }

    private fun showPresets(channel: Int) {
        val otherChannel = if (channel == 1) 2 else 1
        val options = arrayOf(
            "Flat / Bypass (señal limpia)",
            "Voz (-2 / +2 / +2 dB)",
            "Guitarra acústica (-1 / +1 / +2 dB)",
            "Guitarra eléctrica (+1 / +2 / 0 dB)",
            "Bajo (+4 / +1 / -2 dB)",
            "Copiar ajustes de CH$channel → CH$otherChannel",
            "Guardar ajustes actuales…",
            "Cargar preset guardado…",
            "Eliminar preset guardado…",
            "Exportar presets (copiar JSON)",
            "Importar presets (pegar JSON)…"
        )

        AlertDialog.Builder(this)
            .setTitle("Presets · CH$channel")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> resetChannelFlat(channel)
                    1 -> applyEqPreset(channel, "Voz", floatArrayOf(-2f, 2f, 2f))
                    2 -> applyEqPreset(channel, "Acústica", floatArrayOf(-1f, 1f, 2f))
                    3 -> applyEqPreset(channel, "Eléctrica", floatArrayOf(1f, 2f, 0f))
                    4 -> applyEqPreset(channel, "Bajo", floatArrayOf(4f, 1f, -2f))
                    5 -> copyChannelTo(channel, otherChannel)
                    6 -> promptSaveCustomPreset(channel)
                    7 -> chooseCustomPreset(channel, delete = false)
                    8 -> chooseCustomPreset(channel, delete = true)
                    9 -> exportPresetsToClipboard(channel)
                    10 -> promptImportPresetsFromJson(channel)
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun resetChannelFlat(channel: Int) {
        val i = channel - 1
        suppressAudioCallbacks = true
        try {
            hpfEnabled[i] = false
            val accent = if (i == 0) Palette.accentCyan else Palette.accentViolet
            hpfButtons[i]?.let { applyHpfStyle(it, false, accent) }

            eqLow[i] = 0f
            eqMid[i] = 0f
            eqHigh[i] = 0f
            for (band in 0..2) {
                eqKnobs[i][band]?.setNormalizedValue(0.5f)
                eqLabels[i][band]?.text = "0 dB"
            }

            compressorEnabled[i] = false
            compressorButtons[i]?.let { applyModuleToggleStyle(it, false, accent) }
            compressorGrBars[i]?.setReductionDb(0f)
            compressorGrLabels[i]?.text = "GR: 0.0 dB"

            reverbEnabled[i] = false
            reverbButtons[i]?.let { applyModuleToggleStyle(it, false, accent) }

            delayEnabled[i] = false
            delayButtons[i]?.let { applyModuleToggleStyle(it, false, accent) }

            activePresetChips[i]?.text = "Flat ▾"
        } finally {
            suppressAudioCallbacks = false
        }

        if (engineStarted) {
            nativeSetHpf(i, false)
            nativeSetEq(i, 0f, 0f, 0f)
            sendCompressorSettings(i)
            sendReverbSettings(i)
            sendDelaySettings(i)
        }
        Toast.makeText(this, "CH$channel en modo Flat / Bypass.", Toast.LENGTH_SHORT).show()
    }

    private fun copyChannelTo(sourceChannel: Int, targetChannel: Int) {
        val snapshot = captureChannelSettings(sourceChannel)
        applyCustomPreset(targetChannel, snapshot)
        val sourceLabel = activePresetChips[sourceChannel - 1]?.text?.toString()
            ?.removeSuffix(" ▾") ?: "Copia CH$sourceChannel"
        activePresetChips[targetChannel - 1]?.text = "$sourceLabel ▾"
        Toast.makeText(
            this,
            "Ajustes de CH$sourceChannel copiados a CH$targetChannel.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun exportPresetsToClipboard(channel: Int) {
        val presets = customPresets(channel)
        if (presets.length() == 0) {
            Toast.makeText(this, "No hay presets guardados en CH$channel para exportar.", Toast.LENGTH_SHORT).show()
            return
        }
        val payload = JSONObject().apply {
            put("app", "UMC22_LIVE_MIXER")
            put("version", "1.3.0")
            put("channel", channel)
            put("presets", presets)
        }.toString(2)

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("UMC22 Presets CH$channel", payload))
        Toast.makeText(
            this,
            "${presets.length()} preset(s) de CH$channel copiados al portapapeles.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun promptImportPresetsFromJson(channel: Int) {
        val input = EditText(this).apply {
            hint = "Pega aquí el JSON exportado…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            maxLines = 8
        }

        AlertDialog.Builder(this)
            .setTitle("Importar presets · CH$channel")
            .setMessage("Los presets importados se agregarán a los que ya tienes en CH$channel.")
            .setView(input)
            .setPositiveButton("IMPORTAR") { _, _ ->
                val raw = input.text.toString().trim()
                if (raw.isBlank()) {
                    Toast.makeText(this, "El campo está vacío.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                try {
                    val root = JSONObject(raw)
                    val incoming = if (root.has("presets")) root.getJSONObject("presets") else root
                    val current = customPresets(channel)
                    var importedCount = 0
                    val keys = incoming.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val item = incoming.optJSONObject(key)
                        if (item != null) {
                            current.put(key, item)
                            importedCount++
                        }
                    }
                    if (importedCount > 0) {
                        saveCustomPresets(channel, current)
                        Toast.makeText(
                            this,
                            "$importedCount preset(s) importado(s) en CH$channel.",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(this, "No se encontraron presets válidos en el JSON.", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Exception) {
                    Toast.makeText(this, "Formato JSON inválido.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun customPresets(channel: Int): JSONObject {
        val key = "custom_presets_ch$channel"
        val raw = getSharedPreferences("umc22_presets", MODE_PRIVATE).getString(key, "{}")
        return try {
            JSONObject(raw ?: "{}")
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun saveCustomPresets(channel: Int, presets: JSONObject) {
        getSharedPreferences("umc22_presets", MODE_PRIVATE)
            .edit()
            .putString("custom_presets_ch$channel", presets.toString())
            .apply()
    }

    private fun promptSaveCustomPreset(channel: Int) {
        val nameInput = EditText(this).apply {
            hint = "Ej. Voz principal en vivo"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Guardar preset · CH$channel")
            .setMessage("Se guardarán nivel, ruta, HPF, EQ, compresor, reverb y delay actuales.")
            .setView(nameInput)
            .setPositiveButton("GUARDAR") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isBlank()) {
                    Toast.makeText(this, "Escribe un nombre para el preset.", Toast.LENGTH_SHORT).show()
                } else {
                    val presets = customPresets(channel)
                    presets.put(name, captureChannelSettings(channel))
                    saveCustomPresets(channel, presets)
                    activePresetChips[channel - 1]?.text = "$name ▾"
                    Toast.makeText(this, "Preset "$name" guardado en CH$channel.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun captureChannelSettings(channel: Int): JSONObject {
        val i = channel - 1
        return JSONObject().apply {
            put("gain", if (i == 0) gain1 else gain2)
            put("inputRoute", inputRouteMode[i])
            put("hpfEnabled", hpfEnabled[i])
            put("eqLow", eqLow[i])
            put("eqMid", eqMid[i])
            put("eqHigh", eqHigh[i])
            put("compressorEnabled", compressorEnabled[i])
            put("compressorThreshold", compressorThreshold[i])
            put("compressorRatio", compressorRatio[i])
            put("compressorAttack", compressorAttack[i])
            put("compressorRelease", compressorRelease[i])
            put("compressorMakeup", compressorMakeup[i])
            put("reverbEnabled", reverbEnabled[i])
            put("reverbMix", reverbMix[i])
            put("reverbDecay", reverbDecay[i])
            put("delayEnabled", delayEnabled[i])
            put("delayTime", delayTime[i])
            put("delayFeedback", delayFeedback[i])
            put("delayMix", delayMix[i])
        }
    }

    private fun chooseCustomPreset(channel: Int, delete: Boolean) {
        val presets = customPresets(channel)
        val names = mutableListOf<String>()
        val iterator = presets.keys()
        while (iterator.hasNext()) names.add(iterator.next())
        if (names.isEmpty()) {
            Toast.makeText(this, "No hay presets guardados en CH$channel.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(if (delete) "Eliminar preset · CH$channel" else "Cargar preset · CH$channel")
            .setItems(names.toTypedArray()) { _, which ->
                val name = names[which]
                if (delete) {
                    AlertDialog.Builder(this)
                        .setMessage("¿Eliminar "$name"?")
                        .setPositiveButton("ELIMINAR") { _, _ ->
                            presets.remove(name)
                            saveCustomPresets(channel, presets)
                            Toast.makeText(this, "Preset eliminado.", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("CANCELAR", null)
                        .show()
                } else {
                    val data = presets.optJSONObject(name)
                    if (data != null) {
                        applyCustomPreset(channel, data)
                        activePresetChips[channel - 1]?.text = "$name ▾"
                        Toast.makeText(this, "Preset "$name" cargado en CH$channel.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun applyCustomPreset(channel: Int, data: JSONObject) {
        val i = channel - 1
        suppressAudioCallbacks = true
        try {
            if (i == 0) {
                gain1 = data.optDouble("gain", gain1.toDouble()).toFloat().coerceIn(0f, 1f)
            } else {
                gain2 = data.optDouble("gain", gain2.toDouble()).toFloat().coerceIn(0f, 1f)
            }
            val currentGain = if (i == 0) gain1 else gain2
            gainFaders[i]?.setValue(currentGain)
            gainValueLabels[i]?.text = "${(currentGain * 100f).roundToInt()}%"

            inputRouteMode[i] = data.optInt("inputRoute", inputRouteMode[i]).coerceIn(0, 2)
            routeButtons[i]?.text = routeModeLabel(inputRouteMode[i])

            hpfEnabled[i] = data.optBoolean("hpfEnabled", false)
            val accent = if (i == 0) Palette.accentCyan else Palette.accentViolet
            hpfButtons[i]?.let { applyHpfStyle(it, hpfEnabled[i], accent) }

            eqLow[i] = data.optDouble("eqLow", 0.0).toFloat().coerceIn(-12f, 12f)
            eqMid[i] = data.optDouble("eqMid", 0.0).toFloat().coerceIn(-12f, 12f)
            eqHigh[i] = data.optDouble("eqHigh", 0.0).toFloat().coerceIn(-12f, 12f)

            compressorEnabled[i] = data.optBoolean("compressorEnabled", false)
            compressorThreshold[i] = data.optDouble("compressorThreshold", -18.0).toFloat().coerceIn(-60f, 0f)
            compressorRatio[i] = data.optDouble("compressorRatio", 3.0).toFloat().coerceIn(1f, 20f)
            compressorAttack[i] = data.optDouble("compressorAttack", 10.0).toFloat().coerceIn(1f, 100f)
            compressorRelease[i] = data.optDouble("compressorRelease", 100.0).toFloat().coerceIn(10f, 500f)
            compressorMakeup[i] = data.optDouble("compressorMakeup", 0.0).toFloat().coerceIn(0f, 24f)

            reverbEnabled[i] = data.optBoolean("reverbEnabled", false)
            reverbMix[i] = data.optDouble("reverbMix", 0.25).toFloat().coerceIn(0f, 1f)
            reverbDecay[i] = data.optDouble("reverbDecay", 0.65).toFloat().coerceIn(0.20f, 0.92f)

            delayEnabled[i] = data.optBoolean("delayEnabled", false)
            delayTime[i] = data.optDouble("delayTime", 300.0).toFloat().coerceIn(50f, 800f)
            delayFeedback[i] = data.optDouble("delayFeedback", 35.0).toFloat().coerceIn(0f, 85f)
            delayMix[i] = data.optDouble("delayMix", 25.0).toFloat().coerceIn(0f, 100f)

            eqKnobs[i][0]?.setNormalizedValue((eqLow[i] + 12f) / 24f)
            eqKnobs[i][1]?.setNormalizedValue((eqMid[i] + 12f) / 24f)
            eqKnobs[i][2]?.setNormalizedValue((eqHigh[i] + 12f) / 24f)
            eqLabels[i][0]?.text = "${eqLow[i].toInt()} dB"
            eqLabels[i][1]?.text = "${eqMid[i].toInt()} dB"
            eqLabels[i][2]?.text = "${eqHigh[i].toInt()} dB"

            compressorKnobs[i][0]?.setNormalizedValue((compressorThreshold[i] + 60f) / 60f)
            compressorKnobs[i][1]?.setNormalizedValue((compressorRatio[i] - 1f) / 19f)
            compressorKnobs[i][2]?.setNormalizedValue((compressorAttack[i] - 1f) / 99f)
            compressorKnobs[i][3]?.setNormalizedValue((compressorRelease[i] - 10f) / 490f)
            compressorKnobs[i][4]?.setNormalizedValue(compressorMakeup[i] / 24f)

            compressorLabels[i][0]?.text = "${compressorThreshold[i].roundToInt()} dB"
            compressorLabels[i][1]?.text = "${formatCompressorParamValue(compressorRatio[i], 1)}:1"
            compressorLabels[i][2]?.text = "${compressorAttack[i].roundToInt()} ms"
            compressorLabels[i][3]?.text = "${compressorRelease[i].roundToInt()} ms"
            compressorLabels[i][4]?.text = "${compressorMakeup[i].roundToInt()} dB"

            compressorButtons[i]?.let { applyModuleToggleStyle(it, compressorEnabled[i], accent) }
            if (!compressorEnabled[i]) {
                compressorGrBars[i]?.setReductionDb(0f)
                compressorGrLabels[i]?.text = "GR: 0.0 dB"
            }

            val revMixPct = (reverbMix[i] * 100f).roundToInt()
            val revDecPct = (reverbDecay[i] * 100f).roundToInt()
            reverbKnobs[i][0]?.setNormalizedValue(revMixPct / 100f)
            reverbKnobs[i][1]?.setNormalizedValue(((revDecPct - 20f) / 72f).coerceIn(0f, 1f))
            reverbLabels[i][0]?.text = "$revMixPct%"
            reverbLabels[i][1]?.text = "$revDecPct%"
            reverbButtons[i]?.let { applyModuleToggleStyle(it, reverbEnabled[i], accent) }

            val delTime = delayTime[i].roundToInt()
            val delFb = delayFeedback[i].roundToInt()
            val delMix = delayMix[i].roundToInt()
            delayKnobs[i][0]?.setNormalizedValue(((delTime - 50f) / 750f).coerceIn(0f, 1f))
            delayKnobs[i][1]?.setNormalizedValue((delFb / 85f).coerceIn(0f, 1f))
            delayKnobs[i][2]?.setNormalizedValue((delMix / 100f).coerceIn(0f, 1f))
            delayLabels[i][0]?.text = "$delTime ms"
            delayLabels[i][1]?.text = "$delFb%"
            delayLabels[i][2]?.text = "$delMix%"
            delayButtons[i]?.let { applyModuleToggleStyle(it, delayEnabled[i], accent) }
        } finally {
            suppressAudioCallbacks = false
        }

        if (engineStarted) {
            nativeSetGains(gain1, gain2)
            nativeSetInputRoute(i, inputRouteMode[i])
            nativeSetHpf(i, hpfEnabled[i])
            nativeSetEq(i, eqLow[i], eqMid[i], eqHigh[i])
            sendCompressorSettings(i)
            sendReverbSettings(i)
            sendDelaySettings(i)
        }
    }

    private fun applyEqPreset(channel: Int, label: String, values: FloatArray) {
        val index = channel - 1
        suppressAudioCallbacks = true
        try {
            eqLow[index] = values[0]
            eqMid[index] = values[1]
            eqHigh[index] = values[2]

            for (band in 0..2) {
                eqKnobs[index][band]?.setNormalizedValue(((values[band] + 12f) / 24f).coerceIn(0f, 1f))
                eqLabels[index][band]?.text = "${values[band].toInt()} dB"
            }
            activePresetChips[index]?.text = "$label ▾"
        } finally {
            suppressAudioCallbacks = false
        }

        if (engineStarted) {
            nativeSetEq(index, eqLow[index], eqMid[index], eqHigh[index])
        }
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun pillDrawable(fillColor: Int, strokeColor: Int, radiusPx: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fillColor)
            setStroke(dp(1), strokeColor)
            cornerRadius = radiusPx
        }
    }

    private fun circleDrawable(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    // -------------------------------------------------------------------------
    // Controles visuales nativos (Canvas)
    // -------------------------------------------------------------------------

    private class SegmentedMeterView(context: Context) : View(context) {
        private var level = 0f
        private var peakHold = 0f
        private var peakHoldUntilMs = 0L
        private var clipping = false
        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Palette.bgTrack
        }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Palette.borderSubtle
        }
        private val rect = RectF()

        fun setLevel(peak: Float, isClipping: Boolean) {
            val clamped = peak.coerceIn(0f, 1f)
            val now = SystemClock.elapsedRealtime()
            level = clamped
            clipping = isClipping
            if (clamped >= peakHold || now > peakHoldUntilMs) {
                peakHold = clamped
                peakHoldUntilMs = now + 900L
            } else {
                peakHold = (peakHold * 0.96f).coerceAtLeast(clamped)
            }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            rect.set(0f, 0f, w, h)
            canvas.drawRoundRect(rect, h / 2f, h / 2f, bgPaint)

            val segments = 24
            val gap = 3f
            val totalGap = gap * (segments - 1)
            val segW = ((w - 8f - totalGap) / segments).coerceAtLeast(3f)
            val activeSegments = (level * segments).roundToInt().coerceIn(0, segments)
            val holdIndex = (peakHold * segments).roundToInt().coerceIn(0, segments) - 1

            for (i in 0 until segments) {
                val isLit = i < activeSegments
                val isHoldMarker = (i == holdIndex && peakHold > 0.02f)
                if (!isLit && !isHoldMarker) continue

                val frac = i / segments.toFloat()
                barPaint.color = when {
                    clipping && i >= segments - 2 -> Palette.accentRed
                    frac >= 0.85f -> Palette.accentRed
                    frac >= 0.65f -> Palette.accentAmber
                    else -> Palette.accentGreen
                }
                val left = 4f + i * (segW + gap)
                rect.set(left, 3f, left + segW, h - 3f)
                canvas.drawRoundRect(rect, 2f, 2f, barPaint)
            }

            rect.set(1f, 1f, w - 1f, h - 1f)
            canvas.drawRoundRect(rect, h / 2f, h / 2f, borderPaint)
        }
    }

    private class GainReductionBarView(context: Context) : View(context) {
        private var reductionDb = 0f
        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Palette.bgTrack
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Palette.accentAmber
        }
        private val rect = RectF()

        fun setReductionDb(db: Float) {
            reductionDb = db.coerceIn(0f, 24f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            rect.set(0f, 0f, w, h)
            canvas.drawRoundRect(rect, h / 2f, h / 2f, trackPaint)
            val ratio = (reductionDb / 24f).coerceIn(0f, 1f)
            if (ratio > 0f) {
                rect.set(0f, 0f, w * ratio, h)
                canvas.drawRoundRect(rect, h / 2f, h / 2f, fillPaint)
            }
        }
    }

    private class VerticalFaderView(
        context: Context,
        private val accentColor: Int
    ) : View(context) {
        private var value = 0.75f
        private var lastTapMs = 0L
        private var listener: ((Float) -> Unit)? = null
        private var doubleTapListener: (() -> Unit)? = null

        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Palette.bgTrack
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
        }
        private val capPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Palette.textPrimary
        }
        private val capBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = accentColor
        }
        private val rect = RectF()

        fun setValue(v: Float) {
            value = v.coerceIn(0f, 1f)
            invalidate()
        }

        fun setOnValueChangeListener(cb: (Float) -> Unit) {
            listener = cb
        }

        fun setOnDoubleTapListener(cb: () -> Unit) {
            doubleTapListener = cb
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val now = SystemClock.elapsedRealtime()
                    if (doubleTapListener != null && now - lastTapMs < 320L) {
                        lastTapMs = 0L
                        doubleTapListener?.invoke()
                        return true
                    }
                    lastTapMs = now
                    parent?.requestDisallowInterceptTouchEvent(true)
                    updateFromY(event.y)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    updateFromY(event.y)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        private fun updateFromY(y: Float) {
            val pad = 16f
            val usableH = (height - pad * 2f).coerceAtLeast(1f)
            val clampedY = y.coerceIn(pad, height - pad)
            val next = 1f - ((clampedY - pad) / usableH)
            value = next.coerceIn(0f, 1f)
            invalidate()
            listener?.invoke(value)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            val pad = 16f
            val trackW = 12f
            val cx = w / 2f
            val usableH = (h - pad * 2f).coerceAtLeast(1f)

            rect.set(cx - trackW / 2f, pad, cx + trackW / 2f, h - pad)
            canvas.drawRoundRect(rect, trackW / 2f, trackW / 2f, trackPaint)

            val thumbY = (h - pad) - value * usableH
            rect.set(cx - trackW / 2f, thumbY, cx + trackW / 2f, h - pad)
            canvas.drawRoundRect(rect, trackW / 2f, trackW / 2f, fillPaint)

            val capW = (w - 8f).coerceAtLeast(24f)
            val capH = 18f
            rect.set(cx - capW / 2f, thumbY - capH / 2f, cx + capW / 2f, thumbY + capH / 2f)
            canvas.drawRoundRect(rect, 5f, 5f, capPaint)
            canvas.drawRoundRect(rect, 5f, 5f, capBorderPaint)
        }
    }

    private class RotaryKnobView(
        context: Context,
        private val accentColor: Int,
        private val bipolar: Boolean
    ) : View(context) {
        private var normValue = if (bipolar) 0.5f else 0f
        private var lastY = 0f
        private var lastTapMs = 0L
        private var changeListener: ((Float) -> Unit)? = null
        private var doubleTapListener: (() -> Unit)? = null

        private val arcTrackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
            color = Palette.borderSubtle
        }
        private val arcValuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
            color = accentColor
        }
        private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val indicatorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 4f
            strokeCap = Paint.Cap.ROUND
            color = Palette.textPrimary
        }
        private val arcRect = RectF()

        fun setNormalizedValue(v: Float) {
            normValue = v.coerceIn(0f, 1f)
            invalidate()
        }

        fun setOnValueChangeListener(cb: (Float) -> Unit) {
            changeListener = cb
        }

        fun setOnDoubleTapListener(cb: () -> Unit) {
            doubleTapListener = cb
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val now = SystemClock.elapsedRealtime()
                    if (doubleTapListener != null && now - lastTapMs < 320L) {
                        lastTapMs = 0L
                        doubleTapListener?.invoke()
                        return true
                    }
                    lastTapMs = now
                    lastY = event.y
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = lastY - event.y
                    lastY = event.y
                    val sensitivity = (height.coerceAtLeast(80)) * 1.15f
                    normValue = (normValue + dy / sensitivity).coerceIn(0f, 1f)
                    invalidate()
                    changeListener?.invoke(normValue)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            val cx = w / 2f
            val cy = h / 2f
            val radius = min(w, h) / 2f - 6f

            arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)
            val startAngle = 135f
            val sweepTotal = 270f
            canvas.drawArc(arcRect, startAngle, sweepTotal, false, arcTrackPaint)

            if (bipolar) {
                val centerAngle = 270f
                val deltaSweep = (normValue - 0.5f) * 2f * (sweepTotal / 2f)
                canvas.drawArc(arcRect, centerAngle, deltaSweep, false, arcValuePaint)
            } else {
                canvas.drawArc(arcRect, startAngle, sweepTotal * normValue, false, arcValuePaint)
            }

            val bodyRadius = radius * 0.72f
            bodyPaint.shader = LinearGradient(
                cx, cy - bodyRadius, cx, cy + bodyRadius,
                0xFF263347.toInt(), 0xFF121822.toInt(),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, bodyRadius, bodyPaint)

            val angleDeg = startAngle + sweepTotal * normValue
            val angleRad = angleDeg * PI.toFloat() / 180f
            val innerR = bodyRadius * 0.35f
            val outerR = bodyRadius * 0.85f
            canvas.drawLine(
                cx + innerR * cos(angleRad),
                cy + innerR * sin(angleRad),
                cx + outerR * cos(angleRad),
                cy + outerR * sin(angleRad),
                indicatorPaint
            )
        }
    }
}
