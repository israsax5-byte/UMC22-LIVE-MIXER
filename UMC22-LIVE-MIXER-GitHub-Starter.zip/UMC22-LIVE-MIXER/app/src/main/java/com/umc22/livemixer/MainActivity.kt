
package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.text.InputType
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var outputMeterLabel: TextView
    private lateinit var outputMeterBar: ProgressBar
    private lateinit var outputClipIndicator: TextView
    private var outputClipHoldUntilMs = 0L

    private val inputMeterLabels = arrayOfNulls<TextView>(2)
    private val inputMeterBars = arrayOfNulls<ProgressBar>(2)
    private val gainFaders = arrayOfNulls<SeekBar>(2)
    private val meterHandler = Handler(Looper.getMainLooper())
    private var engineStarted = false

    private val meterUpdate = object : Runnable {
        override fun run() {
            if (engineStarted) {
                updateMeters()
                meterHandler.postDelayed(this, 100L)
            }
        }
    }

    private var gain1 = 0.75f
    private var gain2 = 0.65f

    private var mute1 = false
    private var mute2 = false

    private var solo1 = false
    private var solo2 = false

    private val eqLow = floatArrayOf(0f, 0f)
    private val eqMid = floatArrayOf(0f, 0f)
    private val eqHigh = floatArrayOf(0f, 0f)

    private val eqSliders = Array(2) { arrayOfNulls<SeekBar>(3) }
    private val eqLabels = Array(2) { arrayOfNulls<TextView>(3) }

    private val compressorEnabled = booleanArrayOf(false, false)
    private val compressorThreshold = floatArrayOf(-18f, -18f)
    private val compressorRatio = floatArrayOf(3f, 3f)
    private val compressorAttack = floatArrayOf(10f, 10f)
    private val compressorRelease = floatArrayOf(100f, 100f)
    private val compressorMakeup = floatArrayOf(0f, 0f)
    private val compressorSliders = Array(2) { arrayOfNulls<SeekBar>(5) }
    private val compressorLabels = Array(2) { arrayOfNulls<TextView>(5) }
    private val compressorButtons = arrayOfNulls<Button>(2)

    private val reverbEnabled = booleanArrayOf(false, false)
    private val reverbMix = floatArrayOf(0.25f, 0.25f)
    private val reverbDecay = floatArrayOf(0.65f, 0.65f)
    private val reverbSliders = Array(2) { arrayOfNulls<SeekBar>(2) }
    private val reverbLabels = Array(2) { arrayOfNulls<TextView>(2) }
    private val reverbButtons = arrayOfNulls<Button>(2)

    private val delayEnabled = booleanArrayOf(false, false)
    private val delayTime = floatArrayOf(300f, 300f)
    private val delayFeedback = floatArrayOf(35f, 35f)
    private val delayMix = floatArrayOf(25f, 25f)
    private val delaySliders = Array(2) { arrayOfNulls<SeekBar>(3) }
    private val delayLabels = Array(2) { arrayOfNulls<TextView>(3) }
    private val delayButtons = arrayOfNulls<Button>(2)

    companion object {
        init {
            System.loadLibrary("umc22_audio")
        }
    }

    private external fun nativeStart(): Boolean
    private external fun nativeStop()
    private external fun nativeGetMeters(): FloatArray
    private external fun nativeSetGains(g1: Float, g2: Float)
    private external fun nativeSetMutes(m1: Boolean, m2: Boolean)
    private external fun nativeSetSolos(s1: Boolean, s2: Boolean)

    private external fun nativeSetEq(
        channel: Int,
        low: Float,
        mid: Float,
        high: Float
    )
    private external fun nativeSetCompressor(
        channel: Int,
        enabled: Boolean,
        threshold: Float,
        ratio: Float,
        attackMs: Float,
        releaseMs: Float,
        makeupDb: Float
    )
    private external fun nativeSetReverb(
        channel: Int,
        enabled: Boolean,
        mix: Float,
        decay: Float
    )
    private external fun nativeSetDelay(
        channel: Int,
        enabled: Boolean,
        timeMs: Float,
        feedback: Float,
        mix: Float
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }

        fun heading(
            value: String,
            size: Float,
            color: Int = 0xFFFFFFFF.toInt()
        ): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 10, 0, 10)
            }
        }

        content.addView(heading("UMC22 LIVE MIXER", 25f))
        content.addView(
            heading(
                "Versión 1.3.0 · Presets personalizados",
                14f,
                0xFF9FB3C8.toInt()
            )
        )

        status = heading(
            "Comprobando USB…",
            15f,
            0xFF65D6AD.toInt()
        )

        content.addView(status)
        updateUsbStatus()

        startButton = Button(this).apply {
            text = "INICIAR MONITOREO"

            setOnClickListener {
                if (engineStarted) {
                    stopEngine()
                } else if (
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startEngine()
                } else {
                    requestPermissions(
                        arrayOf(Manifest.permission.RECORD_AUDIO),
                        100
                    )
                }
            }
        }

        content.addView(startButton)

        content.addView(heading("MEDIDOR DE SALIDA", 16f, 0xFF65D6AD.toInt()))
        outputMeterLabel = heading("OUT: -∞ dBFS", 14f)
        content.addView(outputMeterLabel)
        outputMeterBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        content.addView(outputMeterBar)
        outputClipIndicator = heading("CLIP: OK", 15f, 0xFF65D6AD.toInt())
        content.addView(outputClipIndicator)

        addChannel(content, "CH1 · ENTRADA 1", 75, 1)
        addChannel(content, "CH2 · ENTRADA 2", 65, 2)

        content.addView(
            heading(
                "Los medidores muestran picos de entrada CH1/CH2 y salida general. " +
                    "CLIP indica picos cercanos al límite digital; baja la ganancia si aparece.",
                13f,
                0xFF9FB3C8.toInt()
            )
        )

        content.addView(
            heading(
                "EQ experimental: LOW, MID y HIGH de -12 dB a +12 dB. " +
                    "Las frecuencias de corte son fijas en esta versión.",
                13f,
                0xFF65D6AD.toInt()
            )
        )

        content.addView(
            heading(
                "Los faders controlan los canales izquierdo y derecho " +
                    "del flujo estéreo detectado. La asignación física " +
                    "de entradas debe verificarse.",
                13f,
                0xFFFFD18A.toInt()
            )
        )

        content.addView(
            heading(
                "SOLO silencia el otro canal en la salida procesada. " +
                    "MAIN y PHONES pueden compartir esa señal; SOLO no está limitado a audífonos.",
                13f,
                0xFFFFD18A.toInt()
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun updateMeters() {
        if (!engineStarted) return
        val values = try {
            nativeGetMeters()
        } catch (_: Exception) {
            return
        }
        if (values.size < 6) return

        for (channel in 0..1) {
            val peak = values[channel].coerceIn(0f, 1f)
            val db = peakToDb(peak)
            val clipping = values[3 + channel] > 0.5f
            inputMeterLabels[channel]?.apply {
                text = if (clipping) "ENTRADA: CLIP!  ${formatDb(db)} dBFS"
                       else "ENTRADA: ${formatDb(db)} dBFS"
                setTextColor(if (clipping) 0xFFFF5555.toInt() else 0xFFFFFFFF.toInt())
            }
            inputMeterBars[channel]?.progress = dbToProgress(db)
        }

        val outputPeak = values[2].coerceIn(0f, 1f)
        val outputDb = peakToDb(outputPeak)
        val outputClipping = values[5] > 0.5f
        if (outputClipping) {
            outputClipHoldUntilMs = SystemClock.elapsedRealtime() + 1000L
        }
        val clipIsHeld = SystemClock.elapsedRealtime() < outputClipHoldUntilMs
        outputClipIndicator.text = if (clipIsHeld) "⚠ CLIP DETECTADO" else "CLIP: OK"
        outputClipIndicator.setTextColor(
            if (clipIsHeld) 0xFFFF3333.toInt() else 0xFF65D6AD.toInt()
        )
        outputMeterLabel.text = if (outputClipping) {
            "SALIDA: CLIP!  ${formatDb(outputDb)} dBFS"
        } else {
            "SALIDA: ${formatDb(outputDb)} dBFS"
        }
        outputMeterLabel.setTextColor(
            if (outputClipping) 0xFFFF5555.toInt() else 0xFFFFFFFF.toInt()
        )
        outputMeterBar.progress = dbToProgress(outputDb)
    }

    private fun peakToDb(peak: Float): Float {
        return if (peak <= 0.000001f) -60f
        else (20f * kotlin.math.log10(peak)).coerceIn(-60f, 0f)
    }

    private fun dbToProgress(db: Float): Int =
        (((db + 60f) / 60f) * 100f).toInt().coerceIn(0, 100)

    private fun formatDb(db: Float): String =
        if (db <= -59.9f) "-∞" else String.format(java.util.Locale.US, "%.1f", db)

    private fun updateUsbStatus() {
        val usb = getSystemService(USB_SERVICE) as UsbManager
        val devices = usb.deviceList.values

        status.text = if (devices.isEmpty()) {
            "USB: no se detecta dispositivo. Conecta la UMC22 mediante OTG."
        } else {
            "USB: ${devices.size} dispositivo(s) detectado(s)\n" +
                devices.joinToString("\n") {
                    "${it.productName ?: "USB"} · VID ${it.vendorId} · PID ${it.productId}"
                }
        }
    }

    private fun startEngine() {
        if (engineStarted) return

        val started = nativeStart()
        engineStarted = started

        status.text = if (started) {
            "Motor iniciado. Prueba a volumen bajo."
        } else {
            "No se pudo abrir audio. Revisa conexión y permisos."
        }

        startButton.text =
            if (started) "DETENER MONITOREO" else "REINTENTAR"

        if (started) {
            nativeSetGains(gain1, gain2)
            nativeSetMutes(mute1, mute2)
            nativeSetSolos(solo1, solo2)

            for (channel in 0..1) {
                nativeSetEq(
                    channel,
                    eqLow[channel],
                    eqMid[channel],
                    eqHigh[channel]
                )
                sendCompressorSettings(channel)
                sendReverbSettings(channel)
                sendDelaySettings(channel)
            }
            meterHandler.removeCallbacks(meterUpdate)
            meterHandler.post(meterUpdate)
        }
    }

    private fun stopEngine() {
        meterHandler.removeCallbacks(meterUpdate)
        if (engineStarted) {
            nativeStop()
            engineStarted = false
        }

        if (::status.isInitialized) {
            status.text = "Motor detenido"
        }

        if (::startButton.isInitialized) {
            startButton.text = "INICIAR MONITOREO"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 100) {
            if (
                grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                startEngine()
            } else {
                status.text = "Permiso de micrófono denegado."
            }
        }
    }

    private fun addChannel(
        root: LinearLayout,
        name: String,
        initial: Int,
        channel: Int
    ) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
            setBackgroundColor(0xFF1B2A36.toInt())
        }

        panel.addView(TextView(this).apply {
            text = name
            textSize = 19f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 8, 0, 10)
        })

        val meterIndex = channel - 1
        val inputMeterLabel = TextView(this).apply {
            text = "ENTRADA: -∞ dBFS"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        inputMeterLabels[meterIndex] = inputMeterLabel
        panel.addView(inputMeterLabel)
        val inputMeterBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        inputMeterBars[meterIndex] = inputMeterBar
        panel.addView(inputMeterBar)

        val level = TextView(this).apply {
            text = "NIVEL: $initial%"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }

        panel.addView(level)

        val fader = SeekBar(this).apply {
            max = 100
            progress = initial
        }

        fader.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    bar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    level.text = "NIVEL: $progress%"

                    if (channel == 1) {
                        gain1 = progress / 100f
                    } else {
                        gain2 = progress / 100f
                    }

                    if (engineStarted) {
                        nativeSetGains(gain1, gain2)
                    }
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            }
        )

        gainFaders[meterIndex] = fader
        panel.addView(fader)

        val mute = Button(this).apply {
            text = "MUTE: OFF"

            setOnClickListener {
                if (channel == 1) {
                    mute1 = !mute1
                    text = if (mute1) "MUTE: ON" else "MUTE: OFF"
                } else {
                    mute2 = !mute2
                    text = if (mute2) "MUTE: ON" else "MUTE: OFF"
                }

                if (engineStarted) {
                    nativeSetMutes(mute1, mute2)
                }
            }
        }

        panel.addView(
            mute,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val solo = Button(this).apply {
            text = "SOLO: OFF"
            setOnClickListener {
                if (channel == 1) {
                    solo1 = !solo1
                    text = if (solo1) "SOLO: ON" else "SOLO: OFF"
                } else {
                    solo2 = !solo2
                    text = if (solo2) "SOLO: ON" else "SOLO: OFF"
                }
                if (engineStarted) {
                    nativeSetSolos(solo1, solo2)
                }
            }
        }
        panel.addView(
            solo,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val presetButton = Button(this).apply {
            text = "PRESETS DE SONIDO"
            setOnClickListener { showPresets(channel) }
        }
        panel.addView(presetButton)

        addEqControl(panel, "LOW", channel, 0)
        addEqControl(panel, "MID", channel, 1)
        addEqControl(panel, "HIGH", channel, 2)
        addCompressorControls(panel, channel)
        addReverbControls(panel, channel)
        addDelayControls(panel, channel)

        root.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 18
            }
        )
    }

    private fun addEqControl(
        panel: LinearLayout,
        band: String,
        channel: Int,
        type: Int
    ) {
        val channelIndex = channel - 1

        val value = when (type) {
            0 -> eqLow[channelIndex]
            1 -> eqMid[channelIndex]
            else -> eqHigh[channelIndex]
        }

        val label = TextView(this).apply {
            text = "$band: ${value.toInt()} dB"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 0)
        }

        panel.addView(label)
        eqLabels[channelIndex][type] = label

        val slider = SeekBar(this).apply {
            max = 24
            progress = (value + 12f).toInt()
        }

        eqSliders[channelIndex][type] = slider

        slider.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    bar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val db = (progress - 12).toFloat()

                    when (type) {
                        0 -> eqLow[channelIndex] = db
                        1 -> eqMid[channelIndex] = db
                        2 -> eqHigh[channelIndex] = db
                    }

                    label.text = "$band: ${db.toInt()} dB"

                    if (engineStarted) {
                        nativeSetEq(
                            channelIndex,
                            eqLow[channelIndex],
                            eqMid[channelIndex],
                            eqHigh[channelIndex]
                        )
                    }
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            }
        )

        panel.addView(slider)
    }


    private fun addCompressorControls(panel: LinearLayout, channel: Int) {
        val index = channel - 1
        panel.addView(TextView(this).apply {
            text = "COMPRESOR · CH$channel"
            textSize = 17f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 14, 0, 4)
        })

        val toggle = Button(this).apply {
            text = if (compressorEnabled[index]) "COMPRESOR: ON" else "COMPRESOR: OFF"
            setOnClickListener {
                compressorEnabled[index] = !compressorEnabled[index]
                text = if (compressorEnabled[index]) "COMPRESOR: ON" else "COMPRESOR: OFF"
                sendCompressorSettings(index)
            }
        }
        compressorButtons[index] = toggle
        panel.addView(toggle)

        addCompressorSlider(panel, channel, 0, "THRESHOLD", -60f, 0f, compressorThreshold[index], " dB")
        addCompressorSlider(panel, channel, 1, "RATIO", 1f, 20f, compressorRatio[index], ":1")
        addCompressorSlider(panel, channel, 2, "ATTACK", 1f, 100f, compressorAttack[index], " ms")
        addCompressorSlider(panel, channel, 3, "RELEASE", 10f, 500f, compressorRelease[index], " ms")
        addCompressorSlider(panel, channel, 4, "MAKEUP GAIN", 0f, 24f, compressorMakeup[index], " dB")
    }

    private fun addCompressorSlider(
        panel: LinearLayout,
        channel: Int,
        type: Int,
        title: String,
        minimum: Float,
        maximum: Float,
        initial: Float,
        suffix: String
    ) {
        val index = channel - 1
        val label = TextView(this).apply {
            text = "$title: ${formatCompressorValue(initial, type)}$suffix"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 5, 0, 0)
        }
        panel.addView(label)
        compressorLabels[index][type] = label

        val steps = when (type) {
            0 -> 60
            1 -> 19
            2 -> 99
            3 -> 490
            else -> 240
        }
        val slider = SeekBar(this).apply {
            max = steps
            progress = (((initial - minimum) / (maximum - minimum)) * steps).toInt().coerceIn(0, steps)
        }
        compressorSliders[index][type] = slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = minimum + (maximum - minimum) * progress / steps.toFloat()
                when (type) {
                    0 -> compressorThreshold[index] = value
                    1 -> compressorRatio[index] = value
                    2 -> compressorAttack[index] = value
                    3 -> compressorRelease[index] = value
                    4 -> compressorMakeup[index] = value
                }
                label.text = "$title: ${formatCompressorValue(value, type)}$suffix"
                if (engineStarted) sendCompressorSettings(index)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(slider)
    }

    private fun formatCompressorValue(value: Float, type: Int): String {
        return if (type == 1) String.format(java.util.Locale.US, "%.1f", value)
        else value.toInt().toString()
    }

    private fun sendCompressorSettings(index: Int) {
        if (!engineStarted) return
        nativeSetCompressor(
            index,
            compressorEnabled[index],
            compressorThreshold[index],
            compressorRatio[index],
            compressorAttack[index],
            compressorRelease[index],
            compressorMakeup[index]
        )
    }

    private fun addReverbControls(panel: LinearLayout, channel: Int) {
        val index = channel - 1
        panel.addView(TextView(this).apply {
            text = "REVERB · CH$channel"
            textSize = 17f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 14, 0, 4)
        })

        val toggle = Button(this).apply {
            text = if (reverbEnabled[index]) "REVERB: ON" else "REVERB: OFF"
            setOnClickListener {
                reverbEnabled[index] = !reverbEnabled[index]
                text = if (reverbEnabled[index]) "REVERB: ON" else "REVERB: OFF"
                sendReverbSettings(index)
            }
        }
        reverbButtons[index] = toggle
        panel.addView(toggle)

        addReverbSlider(panel, channel, 0, "MIX", 0f, 100f, reverbMix[index] * 100f, "%")
        addReverbSlider(panel, channel, 1, "DECAY", 20f, 92f, reverbDecay[index] * 100f, "%")
    }

    private fun addReverbSlider(
        panel: LinearLayout,
        channel: Int,
        type: Int,
        title: String,
        minimum: Float,
        maximum: Float,
        initial: Float,
        suffix: String
    ) {
        val index = channel - 1
        val label = TextView(this).apply {
            text = "$title: ${initial.toInt()}$suffix"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 5, 0, 0)
        }
        panel.addView(label)
        reverbLabels[index][type] = label

        val slider = SeekBar(this).apply {
            max = (maximum - minimum).toInt()
            progress = (initial - minimum).toInt().coerceIn(0, max)
        }
        reverbSliders[index][type] = slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = minimum + progress
                if (type == 0) reverbMix[index] = value / 100f
                else reverbDecay[index] = value / 100f
                label.text = "$title: ${value.toInt()}$suffix"
                if (engineStarted) sendReverbSettings(index)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(slider)
    }

    private fun sendReverbSettings(index: Int) {
        if (!engineStarted) return
        nativeSetReverb(
            index,
            reverbEnabled[index],
            reverbMix[index],
            reverbDecay[index]
        )
    }

    private fun addDelayControls(panel: LinearLayout, channel: Int) {
        val index = channel - 1
        panel.addView(TextView(this).apply {
            text = "DELAY · CH$channel"
            textSize = 17f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 14, 0, 4)
        })

        val toggle = Button(this).apply {
            text = if (delayEnabled[index]) "DELAY: ON" else "DELAY: OFF"
            setOnClickListener {
                delayEnabled[index] = !delayEnabled[index]
                text = if (delayEnabled[index]) "DELAY: ON" else "DELAY: OFF"
                sendDelaySettings(index)
            }
        }
        delayButtons[index] = toggle
        panel.addView(toggle)

        addDelaySlider(panel, channel, 0, "TIME", 50f, 800f, delayTime[index], " ms")
        addDelaySlider(panel, channel, 1, "FEEDBACK", 0f, 85f, delayFeedback[index], "%")
        addDelaySlider(panel, channel, 2, "MIX", 0f, 100f, delayMix[index], "%")
    }

    private fun addDelaySlider(
        panel: LinearLayout,
        channel: Int,
        type: Int,
        title: String,
        minimum: Float,
        maximum: Float,
        initial: Float,
        suffix: String
    ) {
        val index = channel - 1
        val label = TextView(this).apply {
            text = "$title: ${initial.toInt()}$suffix"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 5, 0, 0)
        }
        panel.addView(label)
        delayLabels[index][type] = label

        val slider = SeekBar(this).apply {
            max = (maximum - minimum).toInt()
            progress = (initial - minimum).toInt().coerceIn(0, max)
        }
        delaySliders[index][type] = slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = minimum + progress
                when (type) {
                    0 -> delayTime[index] = value
                    1 -> delayFeedback[index] = value
                    else -> delayMix[index] = value
                }
                label.text = "$title: ${value.toInt()}$suffix"
                if (engineStarted) sendDelaySettings(index)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(slider)
    }

    private fun sendDelaySettings(index: Int) {
        if (!engineStarted) return
        nativeSetDelay(
            index,
            delayEnabled[index],
            delayTime[index],
            delayFeedback[index] / 100f,
            delayMix[index] / 100f
        )
    }

    private fun showPresets(channel: Int) {
        val options = arrayOf(
            "Voz",
            "Guitarra acústica",
            "Guitarra eléctrica",
            "Bajo",
            "Personalizado (mantener ajustes)",
            "Guardar ajustes actuales…",
            "Cargar preset guardado…",
            "Eliminar preset guardado…"
        )

        AlertDialog.Builder(this)
            .setTitle("Preset para CH$channel")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> applyEqPreset(channel, floatArrayOf(-2f, 2f, 2f))
                    1 -> applyEqPreset(channel, floatArrayOf(-1f, 1f, 2f))
                    2 -> applyEqPreset(channel, floatArrayOf(1f, 2f, 0f))
                    3 -> applyEqPreset(channel, floatArrayOf(4f, 1f, -2f))
                    4 -> Unit
                    5 -> promptSaveCustomPreset(channel)
                    6 -> chooseCustomPreset(channel, delete = false)
                    7 -> chooseCustomPreset(channel, delete = true)
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun customPresets(channel: Int): JSONObject {
        val key = "custom_presets_ch$channel"
        val raw = getSharedPreferences("umc22_presets", MODE_PRIVATE).getString(key, "{}")
        return try { JSONObject(raw ?: "{}") } catch (_: Exception) { JSONObject() }
    }

    private fun saveCustomPresets(channel: Int, presets: JSONObject) {
        getSharedPreferences("umc22_presets", MODE_PRIVATE)
            .edit()
            .putString("custom_presets_ch$channel", presets.toString())
            .apply()
    }

    private fun promptSaveCustomPreset(channel: Int) {
        val nameInput = EditText(this).apply {
            hint = "Nombre del preset"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Guardar preset · CH$channel")
            .setMessage("Se guardarán los ajustes actuales de EQ, compresor, reverb y delay.")
            .setView(nameInput)
            .setPositiveButton("GUARDAR") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isBlank()) {
                    android.widget.Toast.makeText(this, "Escribe un nombre para el preset.", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    val presets = customPresets(channel)
                    presets.put(name, captureChannelSettings(channel))
                    saveCustomPresets(channel, presets)
                    android.widget.Toast.makeText(this, "Preset \"$name\" guardado en CH$channel.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun captureChannelSettings(channel: Int): JSONObject {
        val i = channel - 1
        return JSONObject().apply {
            put("gain", if (i == 0) gain1 else gain2)
            put("eqLow", eqLow[i]); put("eqMid", eqMid[i]); put("eqHigh", eqHigh[i])
            put("compressorEnabled", compressorEnabled[i])
            put("compressorThreshold", compressorThreshold[i])
            put("compressorRatio", compressorRatio[i])
            put("compressorAttack", compressorAttack[i])
            put("compressorRelease", compressorRelease[i])
            put("compressorMakeup", compressorMakeup[i])
            put("reverbEnabled", reverbEnabled[i])
            put("reverbMix", reverbMix[i]); put("reverbDecay", reverbDecay[i])
            put("delayEnabled", delayEnabled[i])
            put("delayTime", delayTime[i]); put("delayFeedback", delayFeedback[i]); put("delayMix", delayMix[i])
        }
    }

    private fun chooseCustomPreset(channel: Int, delete: Boolean) {
        val presets = customPresets(channel)
        val names = mutableListOf<String>()
        val iterator = presets.keys()
        while (iterator.hasNext()) names.add(iterator.next())
        if (names.isEmpty()) {
            android.widget.Toast.makeText(this, "No hay presets guardados en CH$channel.", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(if (delete) "Eliminar preset · CH$channel" else "Cargar preset · CH$channel")
            .setItems(names.toTypedArray()) { _, which ->
                val name = names[which]
                if (delete) {
                    AlertDialog.Builder(this)
                        .setMessage("¿Eliminar \"$name\"?")
                        .setPositiveButton("ELIMINAR") { _, _ ->
                            presets.remove(name)
                            saveCustomPresets(channel, presets)
                            android.widget.Toast.makeText(this, "Preset eliminado.", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("CANCELAR", null)
                        .show()
                } else {
                    val data = presets.optJSONObject(name)
                    if (data != null) {
                        applyCustomPreset(channel, data)
                        android.widget.Toast.makeText(this, "Preset \"$name\" cargado en CH$channel.", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun applyCustomPreset(channel: Int, data: JSONObject) {
        val i = channel - 1
        if (i == 0) gain1 = data.optDouble("gain", gain1.toDouble()).toFloat()
        else gain2 = data.optDouble("gain", gain2.toDouble()).toFloat()
        gainFaders[i]?.progress = ((if (i == 0) gain1 else gain2) * 100f).toInt().coerceIn(0, 100)
        eqLow[i] = data.optDouble("eqLow", 0.0).toFloat()
        eqMid[i] = data.optDouble("eqMid", 0.0).toFloat()
        eqHigh[i] = data.optDouble("eqHigh", 0.0).toFloat()
        compressorEnabled[i] = data.optBoolean("compressorEnabled", false)
        compressorThreshold[i] = data.optDouble("compressorThreshold", -18.0).toFloat()
        compressorRatio[i] = data.optDouble("compressorRatio", 3.0).toFloat()
        compressorAttack[i] = data.optDouble("compressorAttack", 10.0).toFloat()
        compressorRelease[i] = data.optDouble("compressorRelease", 100.0).toFloat()
        compressorMakeup[i] = data.optDouble("compressorMakeup", 0.0).toFloat()
        reverbEnabled[i] = data.optBoolean("reverbEnabled", false)
        reverbMix[i] = data.optDouble("reverbMix", 0.25).toFloat()
        reverbDecay[i] = data.optDouble("reverbDecay", 0.65).toFloat()
        delayEnabled[i] = data.optBoolean("delayEnabled", false)
        delayTime[i] = data.optDouble("delayTime", 300.0).toFloat()
        delayFeedback[i] = data.optDouble("delayFeedback", 35.0).toFloat()
        delayMix[i] = data.optDouble("delayMix", 25.0).toFloat()

        // Refresh visible controls without triggering intermediate audio updates.
        eqSliders[i][0]?.progress = (eqLow[i] + 12f).toInt().coerceIn(0, 24)
        eqSliders[i][1]?.progress = (eqMid[i] + 12f).toInt().coerceIn(0, 24)
        eqSliders[i][2]?.progress = (eqHigh[i] + 12f).toInt().coerceIn(0, 24)
        eqLabels[i][0]?.text = "LOW: ${eqLow[i].toInt()} dB"
        eqLabels[i][1]?.text = "MID: ${eqMid[i].toInt()} dB"
        eqLabels[i][2]?.text = "HIGH: ${eqHigh[i].toInt()} dB"

        compressorSliders[i][0]?.progress = ((compressorThreshold[i] + 60f).toInt()).coerceIn(0, 60)
        compressorSliders[i][1]?.progress = ((compressorRatio[i] - 1f).toInt()).coerceIn(0, 19)
        compressorSliders[i][2]?.progress = (compressorAttack[i] - 1f).toInt().coerceIn(0, 99)
        compressorSliders[i][3]?.progress = (compressorRelease[i] - 10f).toInt().coerceIn(0, 490)
        compressorSliders[i][4]?.progress = compressorMakeup[i].toInt().coerceIn(0, 24)
        compressorButtons[i]?.text = if (compressorEnabled[i]) "COMPRESOR: ON" else "COMPRESOR: OFF"

        reverbSliders[i][0]?.progress = (reverbMix[i] * 100f).toInt().coerceIn(0, 100)
        reverbSliders[i][1]?.progress = ((reverbDecay[i] * 100f) - 20f).toInt().coerceIn(0, 72)
        reverbButtons[i]?.text = if (reverbEnabled[i]) "REVERB: ON" else "REVERB: OFF"

        delaySliders[i][0]?.progress = (delayTime[i] - 50f).toInt().coerceIn(0, 750)
        delaySliders[i][1]?.progress = delayFeedback[i].toInt().coerceIn(0, 85)
        delaySliders[i][2]?.progress = delayMix[i].toInt().coerceIn(0, 100)
        delayButtons[i]?.text = if (delayEnabled[i]) "DELAY: ON" else "DELAY: OFF"

        if (engineStarted) {
            nativeSetGains(gain1, gain2)
            nativeSetEq(i, eqLow[i], eqMid[i], eqHigh[i])
            sendCompressorSettings(i)
            sendReverbSettings(i)
            sendDelaySettings(i)
        }
    }

    private fun applyEqPreset(channel: Int, values: FloatArray) {
        val index = channel - 1
        eqLow[index] = values[0]
        eqMid[index] = values[1]
        eqHigh[index] = values[2]

        for (band in 0..2) {
            eqSliders[index][band]?.progress = (values[band] + 12f).toInt()
            val name = when (band) {
                0 -> "LOW"
                1 -> "MID"
                else -> "HIGH"
            }
            eqLabels[index][band]?.text = "$name: ${values[band].toInt()} dB"
        }

        if (engineStarted) {
            nativeSetEq(index, eqLow[index], eqMid[index], eqHigh[index])
        }
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }
}
