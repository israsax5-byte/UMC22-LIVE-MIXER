package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.*
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var usbInfo: TextView
    private lateinit var startButton: Button
    private lateinit var gainBar: SeekBar
    @Volatile private var running = false
    @Volatile private var gain = 0.7f
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private val requestCode = 410

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(0xFF101820.toInt()) }
        fun label(s: String, size: Float = 16f, color: Int = 0xFFFFFFFF.toInt()) = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,8,0,8) }
        root.addView(label("UMC22 LIVE MIXER", 26f))
        root.addView(label("Motor de audio · prueba de voz directa", 14f, 0xFF9FB3C8.toInt()))
        usbInfo = label("")
        root.addView(usbInfo)
        status = label("Estado: detenido", 17f, 0xFF65D6AD.toInt())
        root.addView(status)
        root.addView(label("Nivel de salida", 16f))
        gainBar = SeekBar(this).apply { max=100; progress=70 }
        gainBar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { gain = p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(gainBar)
        startButton = Button(this).apply { text="INICIAR AUDIO"; setOnClickListener { if (running) stopAudio() else ensurePermissionAndStart() } }
        root.addView(startButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(label("Prueba inicial: audio directo, sin EQ ni efectos. Usa volumen bajo. No conectes altavoces todavía.", 14f, 0xFFFFD18A.toInt()))
        root.addView(label("Si no escuchas la voz, detén la prueba y revisaremos la ruta USB. La detección USB por sí sola no garantiza audio.", 13f, 0xFFB8C7D9.toInt()))
        setContentView(ScrollView(this).apply { addView(root) })
        refreshDevices()
    }

    private fun refreshDevices(): List<AudioDeviceInfo> {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val devices = am.getDevices(AudioManager.GET_DEVICES_ALL).toList()
        val usb = devices.filter { it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
        usbInfo.text = if (usb.isEmpty()) "Audio USB: Android no muestra una interfaz USB activa." else "Interfaces de audio USB: " + usb.joinToString { it.productName.toString() }
        return usb
    }

    private fun ensurePermissionAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCode)
        } else startAudio()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAudio()
        else status.text = "Permiso de micrófono denegado."
    }

    private fun startAudio() {
        if (running) return
        val usbDevices = refreshDevices()
        status.text = "Preparando audio USB…"
        startButton.isEnabled = false
        worker = thread(name="UMC22-Audio") {
            try {
                val rates = intArrayOf(48000, 44100)
                var rec: AudioRecord? = null
                var track: AudioTrack? = null
                var chosenRate = 0
                var inputChannels = 0
                for (rate in rates) {
                    val outMin = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                    if (outMin <= 0) continue
                    val formatOut = AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                    for ((mask, channels) in listOf(AudioFormat.CHANNEL_IN_STEREO to 2, AudioFormat.CHANNEL_IN_MONO to 1)) {
                        val inMin = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
                        if (inMin <= 0) continue
                        var candidateRec: AudioRecord? = null
                        var candidateTrack: AudioTrack? = null
                        try {
                            val formatIn = AudioFormat.Builder().setSampleRate(rate).setChannelMask(mask).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                            candidateRec = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC).setAudioFormat(formatIn).setBufferSizeInBytes(max(inMin * 2, 4096)).build()
                            candidateTrack = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).setAudioFormat(formatOut).setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(max(outMin * 2, 4096)).build()
                            if (candidateRec.state == AudioRecord.STATE_INITIALIZED && candidateTrack.state == AudioTrack.STATE_INITIALIZED) {
                                rec = candidateRec; track = candidateTrack; chosenRate = rate; inputChannels = channels; break
                            }
                        } catch (_: Exception) { /* probar otra configuración */ }
                        if (candidateRec !== rec) candidateRec?.release()
                        if (candidateTrack !== track) candidateTrack?.release()
                    }
                    if (rec != null && track != null) break
                }
                if (rec == null || track == null) throw IllegalStateException("Android no pudo abrir captura y reproducción PCM. Revisa que la UMC22 esté conectada.")
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                val inputUsb = usbDevices.firstOrNull { it.isSource }
                val outputUsb = usbDevices.firstOrNull { it.isSink }
                if (inputUsb != null) rec.setPreferredDevice(inputUsb)
                if (outputUsb != null) track.setPreferredDevice(outputUsb)
                recorder = rec; player = track
                rec.startRecording(); track.play(); running = true
                runOnUiThread { status.text = "Audio activo · ${chosenRate} Hz · captura ${if (inputChannels == 1) "mono" else "estéreo"} · USB entrada ${if (inputUsb != null) "seleccionada" else "no confirmada"} · USB salida ${if (outputUsb != null) "seleccionada" else "no confirmada"}"; startButton.text="DETENER AUDIO"; startButton.isEnabled=true }
                val inputBuffer = ShortArray(1024)
                val outputBuffer = ShortArray(2048)
                while (running) {
                    val n = rec.read(inputBuffer, 0, inputBuffer.size, AudioRecord.READ_BLOCKING)
                    if (n > 0) {
                        val g = gain
                        val outputSamples: Int
                        if (inputChannels == 1) {
                            for (i in 0 until n) {
                                val sample = (inputBuffer[i].toInt() * g).toInt().coerceIn(-32768, 32767).toShort()
                                outputBuffer[i * 2] = sample; outputBuffer[i * 2 + 1] = sample
                            }
                            outputSamples = n * 2
                        } else {
                            for (i in 0 until n) outputBuffer[i] = (inputBuffer[i].toInt() * g).toInt().coerceIn(-32768, 32767).toShort()
                            outputSamples = n
                        }
                        var offset = 0
                        while (offset < outputSamples && running) {
                            val wrote = track.write(outputBuffer, offset, outputSamples - offset, AudioTrack.WRITE_BLOCKING)
                            if (wrote < 0) throw IllegalStateException("Error de salida de audio: $wrote")
                            if (wrote == 0) break
                            offset += wrote
                        }
                    } else if (n < 0) throw IllegalStateException("Error de entrada de audio: $n")
                }
            } catch (e: Exception) {
                running = false
                runOnUiThread { status.text = "No se pudo iniciar: ${e.message ?: "error de audio"}"; startButton.text="REINTENTAR"; startButton.isEnabled=true }
            } finally {
                try { recorder?.stop() } catch (_: Exception) {}
                try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
                recorder?.release(); player?.release(); recorder=null; player=null
                runOnUiThread { if (!running) { startButton.text="INICIAR AUDIO"; startButton.isEnabled=true; if (status.text.startsWith("Audio activo")) status.text="Estado: detenido" } }
            }
        }
    }

    private fun stopAudio() { running=false; status.text="Deteniendo audio…"; startButton.isEnabled=false }
    override fun onDestroy() { stopAudio(); super.onDestroy() }
}
