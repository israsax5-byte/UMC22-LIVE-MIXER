
package com.umc22.livemixer

import android.app.Activity
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    private val white = 0xFFFFFFFF.toInt()
    private val green = 0xFF65D6AD.toInt()
    private val dark = 0xFF101820.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(dark)
        }

        fun heading(value: String, size: Float): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(white)
                setPadding(0, 12, 0, 12)
            }
        }

        content.addView(heading("UMC22 LIVE MIXER", 26f))
        content.addView(heading("Versión 0.4.0 PRO · Panel de canales", 14f))

        status = heading("Comprobando USB...", 15f)
        content.addView(status)
        checkUsb()

        addChannel(content, "CH1 · MICRÓFONO XLR", 75)
        addChannel(content, "CH2 · GUITARRA / BAJO", 65)

        content.addView(
            heading(
                "IMPORTANTE: estos faders y botones son controles visuales. " +
                "Todavía falta conectarlos al motor de audio real.",
                13f
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun checkUsb() {
        val usb = getSystemService(USB_SERVICE) as UsbManager
        val devices = usb.deviceList.values

        status.text = if (devices.isEmpty()) {
            "USB: no se detecta la interfaz"
        } else {
            "USB: ${devices.size} dispositivo(s) detectado(s)\n" +
                devices.joinToString("\n") {
                    "${it.productName ?: "USB"} · VID ${it.vendorId} · PID ${it.productId}"
                }
        }
        status.setTextColor(green)
    }

    private fun addChannel(
        root: LinearLayout,
        channelName: String,
        initial: Int
    ) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
            setBackgroundColor(0xFF1B2A36.toInt())
        }

        val title = TextView(this).apply {
            text = channelName
            textSize = 20f
            setTextColor(green)
            setPadding(0, 8, 0, 12)
        }
        panel.addView(title)

        val level = TextView(this).apply {
            text = "VOLUMEN: $initial%"
            textSize = 17f
            setTextColor(white)
        }
        panel.addView(level)

        val fader = SeekBar(this).apply {
            max = 100
            progress = initial
        }

        fader.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    bar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    level.text = "VOLUMEN: $progress%"
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            }
        )

        panel.addView(fader)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        var muted = false
        var solo = false

        val muteButton = Button(this).apply {
            text = "MUTE"
            setOnClickListener {
                muted = !muted
                text = if (muted) "MUTE: ON" else "MUTE"
            }
        }

        val soloButton = Button(this).apply {
            text = "SOLO"
            setOnClickListener {
                solo = !solo
                text = if (solo) "SOLO: ON" else "SOLO"
            }
        }

        buttons.addView(
            muteButton,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        buttons.addView(
            soloButton,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        panel.addView(buttons)

        root.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 20
            }
        )
    }
}
