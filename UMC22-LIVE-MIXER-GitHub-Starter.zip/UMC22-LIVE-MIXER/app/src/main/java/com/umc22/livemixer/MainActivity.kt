package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.graphics.Color
import android.view.ViewGroup
import android.view.Gravity
import android.util.TypedValue

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var audioManager: AudioManager

    @Volatile private var running = false
    @Volatile private var volume = 0.65f
    @Volatile private var bassGain = 1.0f
    @Volatile private var midGain = 1.0f
    @Volatile private var trebleGain = 1.0f
    private var audioThread: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null

    private var lowState = 0.0
    private var lowMidState = 0.0
    private var lowHighState = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        buildUi()
        refreshDevices()
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        fun label(value: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply {
                text = value
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                setTextColor(color)
                setPadding(0, dp(7), 0, dp(7))
            }

        root.addView(label("UMC22 LIVE MIXER", 26f))
        root.addView(label("Motor de audio USB · versión 0.3.0", 14f, Color.LTGRAY))
        status = label("Estado: detenido", 17f, Color.rgb(101, 214, 173))
        root.addView(status)
        details = label("", 13f, Color.LTGRAY)
        root.addView(details)

        startButton = Button(this).apply {
            text = "INICIAR AUDIO"
            setOnClickListener { startAudio() }
        }
        stopButton = Button(this).apply {
            text = "DETENER AUDIO"
            isEnabled = false
            setOnClickListener { stopAudio() }
        }
        root.addView(startButton)
        root.addView(stopButton)

        addSlider(root, "Volumen de monitor", 65) { volume = it / 100f }
        addSlider(root, "Graves", 50) { bassGain = gainFromSlider(it) }
        addSlider(root, "Medios", 50) { midGain = gainFromSlider(it) }
        addSlider(root, "Agudos", 50) { trebleGain = gainFromSlider(it) }

        root.addView(label(
            "Prueba inicial: usa audífonos, deja el volumen bajo y mantén +48V apagado para tu micrófono dinámico. " +
            "Este motor usa AudioRecord/AudioTrack de Android; la latencia depende del dispositivo y puede variar.",
            12f, Color.rgb(255, 209, 138)
        ))
        setContentView(root)
    }

    private fun addSlider(root: LinearLayout, name: String, initial: Int, changed: (Int) -> Unit) {
        val title = TextView(this).apply {
            text = "$name: $initial%"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, dp(8), 0, 0)
        }
        val bar = SeekBar(this).apply {
            max = 100
            progress = initial
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    title.text = "$name: $progress%"
                    changed(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(bar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun gainFromSlider(value: Int): Float = 0.25f + (value / 50f)

    private fun refreshDevices() {
        val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val inputText = inputs.joinToString { "${it.productName} (${deviceType(it.type)})" }.ifBlank { "entrada predeterminada" }
        val outputText = outputs.joinToString { "${it.productName} (${deviceType(it.type)})" }.ifBlank { "salida predeterminada" }
        details.text = "Entradas: $inputText\nSalidas: $outputText"
    }

    private fun deviceType(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "micrófono interno"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "altavoz"
        else -> "audio"
    }

    private fun startAudio() {
        if (running) return
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            status.text = "Concede el permiso de micrófono y vuelve a pulsar INICIAR."
            return
        }

        val sampleRate = 48000
        val channelIn = AudioFormat.CHANNEL_IN_MONO
        val channelOut = AudioFormat.CHANNEL_OUT_STEREO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minIn = AudioRecord.getMinBufferSize(sampleRate, channelIn, encoding)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, channelOut, encoding)
        if (minIn <= 0 || minOut <= 0) {
            status.text = "Este dispositivo no admite el formato de audio solicitado."
            return
        }
        val bufferBytes = maxOf(minIn, minOut / 2, 4096) * 2

        try {
            val input = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate, channelIn, encoding, bufferBytes
            )
            if (input.state != AudioRecord.STATE_INITIALIZED) {
                input.release()
                status.text = "No se pudo abrir la entrada de audio."
                return
            }

            val output = AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(encoding)
                        .setChannelMask(channelOut)
                        .build()
                )
                .setBufferSizeInBytes(bufferBytes * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()

            if (output.state != AudioTrack.STATE_INITIALIZED) {
                input.release()
                output.release()
                status.text = "No se pudo abrir la salida de audio."
                return
            }

            val usbInput = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
            val usbOutput = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
            if (usbInput != null) input.setPreferredDevice(usbInput)
            if (usbOutput != null) output.setPreferredDevice(usbOutput)

            recorder = input
            player = output
            lowState = 0.0
            lowMidState = 0.0
            lowHighState = 0.0
            running = true
            input.startRecording()
            output.play()
            startButton.isEnabled = false
            stopButton.isEnabled = true
            status.text = "Audio activo · 48 kHz · intentando usar USB cuando está disponible"
            refreshDevices()

            audioThread = Thread {
                val inputBuffer = ShortArray(512)
                val outputBuffer = ShortArray(1024)
                while (running) {
                    val count = try { input.read(inputBuffer, 0, inputBuffer.size) } catch (_: Exception) { -1 }
                    if (count <= 0) {
                        if (count < 0) break
                        continue
                    }
                    var outIndex = 0
                    for (i in 0 until count) {
                        val x = inputBuffer[i].toDouble() / 32768.0
                        lowState += 0.055 * (x - lowState)
                        val low = lowState
                        lowMidState += 0.22 * (x - lowMidState)
                        val mid = lowMidState - low
                        lowHighState += 0.72 * (x - lowHighState)
                        val high = x - lowHighState
                        val processed = (low * bassGain + mid * midGain + high * trebleGain) * volume
                        val clipped = processed.coerceIn(-1.0, 1.0)
                        val sample = (clipped * 32767.0).toInt().toShort()
                        outputBuffer[outIndex++] = sample
                        outputBuffer[outIndex++] = sample
                    }
                    var written = 0
                    val total = outIndex
                    while (written < total && running) {
                        val n = try { output.write(outputBuffer, written, total - written, AudioTrack.WRITE_BLOCKING) } catch (_: Exception) { -1 }
                        if (n <= 0) break
                        written += n
                    }
                }
                runOnUiThread {
                    if (running) stopAudio()
                }
            }.also { it.priority = Thread.MAX_PRIORITY; it.start() }
        } catch (e: Exception) {
            running = false
            status.text = "Error al iniciar audio: ${e.message ?: "desconocido"}"
            releaseAudio()
        }
    }

    private fun stopAudio() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause() } catch (_: Exception) {}
        releaseAudio()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        status.text = "Estado: detenido"
    }

    private fun releaseAudio() {
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.flush(); player?.release() } catch (_: Exception) {}
        recorder = null
        player = null
        audioThread = null
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            status.text = "Permiso concedido. Conecta la UMC22 y pulsa INICIAR AUDIO."
        } else if (requestCode == 100) {
            status.text = "El permiso de micrófono es necesario para procesar audio."
        }
    }

    override fun onDestroy() {
        stopAudio()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
