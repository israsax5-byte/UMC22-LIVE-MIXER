package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startButton: Button

    private var engineStarted = false
    private var gain1 = 0.75f
    private var gain2 = 0.65f
    private var mute1 = false
    private var mute2 = false

    companion object {
        init {
            System.loadLibrary("umc22_audio")
        }
    }

    private external fun nativeStart(): Boolean
    private external fun nativeStop()
    private external fun nativeSetGains(g1: Float, g2: Float)
    private external fun nativeSetMutes(m1: Boolean, m2: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }

        fun heading(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 10, 0, 10)
            }
        }

        content.addView(heading("UMC22 LIVE MIXER", 25f))
        content.addView(heading("Versión 0.4.0 · Motor experimental", 14f, 0xFF9FB3C8.toInt()))

        status = heading("Comprobando USB…", 15f, 0xFF65D6AD.toInt())
        content.addView(status)
        updateUsbStatus()

        startButton = Button(this).apply {
            text = "INICIAR MONITOREO"
            setOnClickListener {
                if (engineStarted) {
                    stopEngine()
                } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                    startEngine()
                } else {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
                }
            }
        }
        content.addView(startButton)

        addChannel(content, "CH1 · ENTRADA 1", 75, 1)
        addChannel(content, "CH2 · ENTRADA 2", 65, 2)

        content.addView(
            heading(
                "PRUEBA EXPERIMENTAL: los faders controlan los canales izquierdo y derecho " +
                    "del flujo estéreo detectado. La asignación física de entradas debe verificarse.",
                13f,
                0xFFFFD18A.toInt()
            )
        )
        content.addView(
            heading(
                "La UMC22 puede compartir la misma señal entre MAIN y PHONES. " +
                    "Esta versión no ofrece mezclas físicas independientes.",
                13f,
                0xFFFFD18A.toInt()
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun updateUsbStatus() {
        val usb = getSystemService(USB_SERVICE) as UsbManager
        val devices = usb.deviceList.values
        status.text = if (devices.isEmpty()) {
            "USB: no se detecta dispositivo USB. Conecta la UMC22 mediante OTG."
        } else {
            "USB: ${devices.size} dispositivo(s) detectado(s)\n" +
                devices.joinToString("\n") {
                    "${it.productName ?: "USB"} · VID ${it.vendorId} · PID ${it.productId}"
                }
        }
    }

    private fun startEngine() {
        if (engineStarted) return
        val started = nativeStart()
        engineStarted = started
        status.text = if (started) {
            "Motor iniciado. Prueba a volumen bajo."
        } else {
            "No se pudo abrir audio USB. Revisa conexión, permisos y compatibilidad."
        }
        startButton.text = if (started) "DETENER MONITOREO" else "REINTENTAR"
        if (started) nativeSetGains(gain1, gain2)
        if (started) nativeSetMutes(mute1, mute2)
    }

    private fun stopEngine() {
        if (engineStarted) {
            nativeStop()
            engineStarted = false
        }
        if (::status.isInitialized) status.text = "Motor detenido"
        if (::startButton.isInitialized) startButton.text = "INICIAR MONITOREO"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startEngine()
            } else {
                status.text = "Permiso de micrófono denegado."
            }
        }
    }

    private fun addChannel(root: LinearLayout, name: String, initial: Int, channel: Int) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
            setBackgroundColor(0xFF1B2A36.toInt())
        }

        panel.addView(TextView(this).apply {
            text = name
            textSize = 19f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 8, 0, 10)
        })

        val level = TextView(this).apply {
            text = "NIVEL: $initial%"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        panel.addView(level)

        val fader = SeekBar(this).apply {
            max = 100
            progress = initial
        }
        fader.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                level.text = "NIVEL: $progress%"
                if (channel == 1) gain1 = progress / 100f else gain2 = progress / 100f
                if (engineStarted) nativeSetGains(gain1, gain2)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(fader)

        val mute = Button(this).apply {
            text = "MUTE: OFF"
            setOnClickListener {
                if (channel == 1) {
                    mute1 = !mute1
                    text = if (mute1) "MUTE: ON" else "MUTE: OFF"
                } else {
                    mute2 = !mute2
                    text = if (mute2) "MUTE: ON" else "MUTE: OFF"
                }
                if (engineStarted) nativeSetMutes(mute1, mute2)
            }
        }
        panel.addView(mute, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        root.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 18 }
        )
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }
}
