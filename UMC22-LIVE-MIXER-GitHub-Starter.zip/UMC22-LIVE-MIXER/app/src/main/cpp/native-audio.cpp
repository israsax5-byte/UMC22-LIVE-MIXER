
#include <jni.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <algorithm>
#include <vector>
#include <mutex>

class UMC22Engine : public oboe::AudioStreamCallback {
public:
    std::shared_ptr<oboe::AudioStream> input;
    std::shared_ptr<oboe::AudioStream> output;

    std::atomic<float> gain1{0.75f};
    std::atomic<float> gain2{0.65f};
    std::atomic<bool> mute1{false};
    std::atomic<bool> mute2{false};

    std::vector<float> buffer;
    std::atomic<int> writeFrame{0};
    std::atomic<int> readFrame{0};

    static constexpr int capacity = 48000;

    UMC22Engine() : buffer(capacity * 2, 0.0f) {}

    void setGains(float g1, float g2) {
        gain1.store(std::clamp(g1, 0.0f, 1.0f));
        gain2.store(std::clamp(g2, 0.0f, 1.0f));
    }

    void setMutes(bool m1, bool m2) {
        mute1.store(m1);
        mute2.store(m2);
    }

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* stream,
        void* audioData,
        int32_t frames
    ) override {
        if (stream == input.get()) {
            auto* in = static_cast<float*>(audioData);
            int channels = stream->getChannelCount();

            for (int i = 0; i < frames; ++i) {
                float ch1 = in[i * channels];
                float ch2 = channels > 1 ? in[i * channels + 1] : 0.0f;

                int w = writeFrame.load(std::memory_order_relaxed);
                int next = (w + 1) % capacity;
                int r = readFrame.load(std::memory_order_acquire);

                if (next != r) {
                    buffer[w * 2] = ch1;
                    buffer[w * 2 + 1] = ch2;
                    writeFrame.store(next, std::memory_order_release);
                }
            }
        } else {
            auto* out = static_cast<float*>(audioData);

            float g1 = mute1.load() ? 0.0f : gain1.load();
            float g2 = mute2.load() ? 0.0f : gain2.load();

            for (int i = 0; i < frames; ++i) {
                int r = readFrame.load(std::memory_order_relaxed);
                int w = writeFrame.load(std::memory_order_acquire);

                float ch1 = 0.0f;
                float ch2 = 0.0f;

                if (r != w) {
                    ch1 = buffer[r * 2];
                    ch2 = buffer[r * 2 + 1];
                    readFrame.store((r + 1) % capacity,
                                    std::memory_order_release);
                }

                out[i * 2] = ch1 * g1;
                out[i * 2 + 1] = ch2 * g2;
            }
        }

        return oboe::DataCallbackResult::Continue;
    }

    bool start() {
        oboe::AudioStreamBuilder inBuilder;
        inBuilder.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setSampleRate(48000)
            ->setCallback(this);

        if (inBuilder.openStream(input) != oboe::Result::OK) {
            return false;
        }

        oboe::AudioStreamBuilder outBuilder;
        outBuilder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setSampleRate(48000)
            ->setCallback(this);

        if (outBuilder.openStream(output) != oboe::Result::OK) {
            input->close();
            input.reset();
            return false;
        }

        if (output->requestStart() != oboe::Result::OK) {
            output->close();
            input->close();
            output.reset();
            input.reset();
            return false;
        }

        if (input->requestStart() != oboe::Result::OK) {
            output->requestStop();
            output->close();
            input->close();
            output.reset();
            input.reset();
            return false;
        }

        return true;
    }

    void stop() {
        if (input) {
            input->requestStop();
            input->close();
            input.reset();
        }
        if (output) {
            output->requestStop();
            output->close();
            output.reset();
        }
    }
};

static UMC22Engine engine;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(
    JNIEnv*, jobject
) {
    return engine.start() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(
    JNIEnv*, jobject
) {
    engine.stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
    JNIEnv*, jobject, jfloat g1, jfloat g2
) {
    engine.setGains(g1, g2);
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
    JNIEnv*, jobject, jboolean m1, jboolean m2
) {
    engine.setMutes(m1, m2);
}
