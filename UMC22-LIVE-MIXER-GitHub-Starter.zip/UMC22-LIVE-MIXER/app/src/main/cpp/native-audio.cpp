#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

namespace {
constexpr float kPi = 3.14159265358979323846f;

inline float flushDenormal(float x) {
    return (std::fabs(x) < 1.0e-30f) ? 0.0f : x;
}

inline float dbToLinear(float db) {
    return std::pow(10.0f, db / 20.0f);
}

inline float softLimiter(float x) {
    // Suavizado suave cerca de +-0.95 para evitar recortes agresivos
    constexpr float threshold = 0.92f;
    if (std::fabs(x) <= threshold) return x;
    const float sign = (x >= 0.0f) ? 1.0f : -1.0f;
    const float excess = std::fabs(x) - threshold;
    return sign * (threshold + (1.0f - threshold) * std::tanh(excess / (1.0f - threshold)));
}
} // namespace

class UMC22Engine {
private:
    static constexpr uint32_t kCapacity = 16384;
    static constexpr uint32_t kMask = kCapacity - 1;

    class InputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit InputCallback(UMC22Engine* engine) : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* audioData,
            int32_t numFrames) override {
            engine_->capture(stream, audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

        void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
            engine_->handleStreamDisconnect(error);
        }

    private:
        UMC22Engine* engine_;
    };

    class OutputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit OutputCallback(UMC22Engine* engine) : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* audioData,
            int32_t numFrames) override {
            engine_->render(stream, audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

        void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
            engine_->handleStreamDisconnect(error);
        }

    private:
        UMC22Engine* engine_;
    };

    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;

    std::unique_ptr<InputCallback> inputCallback_;
    std::unique_ptr<OutputCallback> outputCallback_;

    std::vector<float> ring_;

    std::atomic<uint32_t> writeFrame_{0};
    std::atomic<uint32_t> readFrame_{0};

    std::atomic<float> gain_[2] = {0.75f, 0.65f};
    float smoothedGain_[2] = {0.75f, 0.65f};

    std::atomic<bool> mute_[2] = {false, false};
    std::atomic<bool> solo_[2] = {false, false};

    std::atomic<float> inputPeak_[2] = {0.0f, 0.0f};
    std::atomic<float> outputPeak_{0.0f};
    std::atomic<bool> inputClip_[2] = {false, false};
    std::atomic<bool> outputClip_{false};
    std::atomic<float> compressorGrDb_[2] = {0.0f, 0.0f};
    std::atomic<bool> disconnected_{false};

    static void updatePeak(std::atomic<float>& target, float sample) {
        const float peak = std::fabs(sample);
        float previous = target.load(std::memory_order_relaxed);
        while (peak > previous &&
               !target.compare_exchange_weak(
                   previous, peak,
                   std::memory_order_relaxed,
                   std::memory_order_relaxed)) {
        }
    }

    static void updateMaxGr(std::atomic<float>& target, float grDb) {
        const float clamped = std::clamp(grDb, 0.0f, 24.0f);
        float previous = target.load(std::memory_order_relaxed);
        while (clamped > previous &&
               !target.compare_exchange_weak(
                   previous, clamped,
                   std::memory_order_relaxed,
                   std::memory_order_relaxed)) {
        }
    }

    // EQ
    std::atomic<float> eqLow_[2] = {0.0f, 0.0f};
    std::atomic<float> eqMid_[2] = {0.0f, 0.0f};
    std::atomic<float> eqHigh_[2] = {0.0f, 0.0f};

    float cachedLowDb_[2] = {0.0f, 0.0f};
    float cachedMidDb_[2] = {0.0f, 0.0f};
    float cachedHighDb_[2] = {0.0f, 0.0f};
    float cachedLowGain_[2] = {1.0f, 1.0f};
    float cachedMidGain_[2] = {1.0f, 1.0f};
    float cachedHighGain_[2] = {1.0f, 1.0f};
    float lowAlpha_ = 0.0f;
    float highAlpha_ = 0.0f;
    int32_t coeffSampleRate_ = 0;

    // Compresor
    std::atomic<bool> compressorEnabled_[2] = {false, false};
    std::atomic<float> compressorThreshold_[2] = {-18.0f, -18.0f};
    std::atomic<float> compressorRatio_[2] = {3.0f, 3.0f};
    std::atomic<float> compressorAttackMs_[2] = {10.0f, 10.0f};
    std::atomic<float> compressorReleaseMs_[2] = {100.0f, 100.0f};
    std::atomic<float> compressorMakeupDb_[2] = {0.0f, 0.0f};

    float cachedAttackMs_[2] = {-1.0f, -1.0f};
    float cachedReleaseMs_[2] = {-1.0f, -1.0f};
    float cachedMakeupDb_[2] = {-1.0f, -1.0f};
    float cachedAttackCoeff_[2] = {0.0f, 0.0f};
    float cachedReleaseCoeff_[2] = {0.0f, 0.0f};
    float cachedMakeupLinear_[2] = {1.0f, 1.0f};

    // Reverb
    std::atomic<bool> reverbEnabled_[2] = {false, false};
    std::atomic<float> reverbMix_[2] = {0.25f, 0.25f};
    std::atomic<float> reverbDecay_[2] = {0.65f, 0.65f};
    std::vector<float> reverbBuffers_[2][4];
    std::size_t reverbPositions_[2][4] = {};
    float reverbDampingState_[2][4] = {};

    // Delay
    std::atomic<bool> delayEnabled_[2] = {false, false};
    std::atomic<float> delayTimeMs_[2] = {300.0f, 300.0f};
    std::atomic<float> delayFeedback_[2] = {0.35f, 0.35f};
    std::atomic<float> delayMix_[2] = {0.25f, 0.25f};
    std::vector<float> delayBuffers_[2];
    std::size_t delayPositions_[2] = {};
    float smoothedDelaySamples_[2] = {14400.0f, 14400.0f};

    float lowState_[2] = {0.0f, 0.0f};
    float midState_[2] = {0.0f, 0.0f};
    float compressorEnvelope_[2] = {0.0f, 0.0f};

    std::mutex mutex_;
    std::atomic<int32_t> sampleRate_{48000};
    std::atomic<bool> running_{false};
    std::atomic<bool> cleanupInProgress_{false};

    static float readSample(const void* data, int32_t index, oboe::AudioFormat format) {
        if (format == oboe::AudioFormat::Float) {
            return static_cast<const float*>(data)[index];
        }
        if (format == oboe::AudioFormat::I16) {
            return static_cast<const int16_t*>(data)[index] / 32768.0f;
        }
        return 0.0f;
    }

    static void writeSample(void* data, int32_t index, oboe::AudioFormat format, float value) {
        const float clamped = std::clamp(value, -1.0f, 1.0f);
        if (format == oboe::AudioFormat::Float) {
            static_cast<float*>(data)[index] = clamped;
        } else if (format == oboe::AudioFormat::I16) {
            static_cast<int16_t*>(data)[index] =
                static_cast<int16_t>(clamped * 32767.0f);
        }
    }

    void handleStreamDisconnect(oboe::Result) {
        running_.store(false, std::memory_order_release);
        disconnected_.store(true, std::memory_order_release);

        bool expected = false;
        if (cleanupInProgress_.compare_exchange_strong(
                expected, true,
                std::memory_order_acq_rel,
                std::memory_order_relaxed)) {
            std::thread([this]() {
                stopInternal();
                cleanupInProgress_.store(false, std::memory_order_release);
            }).detach();
        }
    }

    void refreshBlockCoefficients(int32_t sr) {
        if (sr <= 0) sr = 48000;
        if (coeffSampleRate_ != sr) {
            constexpr float lowCutoff = 250.0f;
            constexpr float highCutoff = 2500.0f;
            lowAlpha_ = std::exp(-2.0f * kPi * lowCutoff / static_cast<float>(sr));
            highAlpha_ = std::exp(-2.0f * kPi * highCutoff / static_cast<float>(sr));
            coeffSampleRate_ = sr;
            cachedAttackMs_[0] = cachedAttackMs_[1] = -1.0f;
            cachedReleaseMs_[0] = cachedReleaseMs_[1] = -1.0f;
        }

        for (int ch = 0; ch < 2; ++ch) {
            const float lowDb = eqLow_[ch].load(std::memory_order_relaxed);
            if (lowDb != cachedLowDb_[ch]) {
                cachedLowDb_[ch] = lowDb;
                cachedLowGain_[ch] = dbToLinear(lowDb);
            }
            const float midDb = eqMid_[ch].load(std::memory_order_relaxed);
            if (midDb != cachedMidDb_[ch]) {
                cachedMidDb_[ch] = midDb;
                cachedMidGain_[ch] = dbToLinear(midDb);
            }
            const float highDb = eqHigh_[ch].load(std::memory_order_relaxed);
            if (highDb != cachedHighDb_[ch]) {
                cachedHighDb_[ch] = highDb;
                cachedHighGain_[ch] = dbToLinear(highDb);
            }

            const float atk = compressorAttackMs_[ch].load(std::memory_order_relaxed);
            if (atk != cachedAttackMs_[ch]) {
                cachedAttackMs_[ch] = atk;
                cachedAttackCoeff_[ch] = std::exp(
                    -1.0f / (static_cast<float>(sr) * std::max(atk, 0.5f) * 0.001f));
            }

            const float rel = compressorReleaseMs_[ch].load(std::memory_order_relaxed);
            if (rel != cachedReleaseMs_[ch]) {
                cachedReleaseMs_[ch] = rel;
                cachedReleaseCoeff_[ch] = std::exp(
                    -1.0f / (static_cast<float>(sr) * std::max(rel, 5.0f) * 0.001f));
            }

            const float makeup = compressorMakeupDb_[ch].load(std::memory_order_relaxed);
            if (makeup != cachedMakeupDb_[ch]) {
                cachedMakeupDb_[ch] = makeup;
                cachedMakeupLinear_[ch] = dbToLinear(makeup);
            }
        }
    }

    void capture(oboe::AudioStream* stream, void* audioData, int32_t numFrames) {
        if (!running_.load(std::memory_order_acquire) || !stream || !audioData || numFrames <= 0) {
            return;
        }

        const int32_t channels = stream->getChannelCount();
        const auto format = stream->getFormat();
        if (channels < 1) return;

        uint32_t write = writeFrame_.load(std::memory_order_relaxed);
        const uint32_t read = readFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < numFrames; ++frame) {
            if ((write - read) >= kCapacity) {
                continue;
            }

            const int32_t base = frame * channels;
            const float left = readSample(audioData, base, format);
            const float right = (channels > 1)
                ? readSample(audioData, base + 1, format)
                : left;

            updatePeak(inputPeak_[0], left);
            updatePeak(inputPeak_[1], right);
            if (std::fabs(left) >= 0.999f) {
                inputClip_[0].store(true, std::memory_order_relaxed);
            }
            if (std::fabs(right) >= 0.999f) {
                inputClip_[1].store(true, std::memory_order_relaxed);
            }

            const uint32_t slot = write & kMask;
            ring_[slot * 2] = left;
            ring_[slot * 2 + 1] = right;
            ++write;
        }

        writeFrame_.store(write, std::memory_order_release);
    }

    float processEQ(float input, int channel) {
        lowState_[channel] = flushDenormal(
            (1.0f - lowAlpha_) * input + lowAlpha_ * lowState_[channel]);
        midState_[channel] = flushDenormal(
            (1.0f - highAlpha_) * input + highAlpha_ * midState_[channel]);

        const float low = lowState_[channel];
        const float mid = midState_[channel] - low;
        const float high = input - midState_[channel];

        return low * cachedLowGain_[channel] +
               mid * cachedMidGain_[channel] +
               high * cachedHighGain_[channel];
    }

    float processCompressor(float input, int channel) {
        if (!compressorEnabled_[channel].load(std::memory_order_relaxed)) {
            return input;
        }

        const float thresholdDb = compressorThreshold_[channel].load(std::memory_order_relaxed);
        const float ratio = std::max(1.0f, compressorRatio_[channel].load(std::memory_order_relaxed));
        const float magnitude = std::fabs(input);

        const float coeff = (magnitude > compressorEnvelope_[channel])
            ? cachedAttackCoeff_[channel]
            : cachedReleaseCoeff_[channel];

        compressorEnvelope_[channel] = flushDenormal(
            coeff * compressorEnvelope_[channel] + (1.0f - coeff) * magnitude);

        const float envelopeDb = 20.0f * std::log10(std::max(compressorEnvelope_[channel], 1.0e-7f));
        float grDb = 0.0f;
        float gainDb = cachedMakeupDb_[channel];
        if (envelopeDb > thresholdDb) {
            const float targetDb = thresholdDb + (envelopeDb - thresholdDb) / ratio;
            grDb = std::max(0.0f, envelopeDb - targetDb);
            gainDb -= grDb;
        }
        updateMaxGr(compressorGrDb_[channel], grDb);

        return input * dbToLinear(gainDb);
    }

    void initializeBuffers(int32_t sr) {
        constexpr float delayMs[4] = {29.7f, 37.1f, 41.1f, 43.7f};
        for (int channel = 0; channel < 2; ++channel) {
            lowState_[channel] = 0.0f;
            midState_[channel] = 0.0f;
            compressorEnvelope_[channel] = 0.0f;
            smoothedGain_[channel] = gain_[channel].load(std::memory_order_relaxed);
            smoothedDelaySamples_[channel] = static_cast<float>(sr) * 0.3f;

            for (int line = 0; line < 4; ++line) {
                const std::size_t length = std::max<std::size_t>(
                    1, static_cast<std::size_t>(sr * delayMs[line] / 1000.0f));
                reverbBuffers_[channel][line].assign(length, 0.0f);
                reverbPositions_[channel][line] = 0;
                reverbDampingState_[channel][line] = 0.0f;
            }
        }

        const std::size_t delayCapacity = std::max<std::size_t>(
            1, static_cast<std::size_t>(sr * 1.2f));
        for (int channel = 0; channel < 2; ++channel) {
            delayBuffers_[channel].assign(delayCapacity, 0.0f);
            delayPositions_[channel] = 0;
        }
    }

    float processDelay(float input, int channel, int32_t sr) {
        auto& buffer = delayBuffers_[channel];
        if (buffer.empty()) return input;

        std::size_t& position = delayPositions_[channel];
        if (!delayEnabled_[channel].load(std::memory_order_relaxed)) {
            buffer[position] = 0.0f;
            position = (position + 1) % buffer.size();
            return input;
        }

        const float timeMs = delayTimeMs_[channel].load(std::memory_order_relaxed);
        const float feedback = delayFeedback_[channel].load(std::memory_order_relaxed);
        const float mix = delayMix_[channel].load(std::memory_order_relaxed);

        const float targetSamples = std::clamp(
            static_cast<float>(sr) * timeMs / 1000.0f,
            1.0f,
            static_cast<float>(buffer.size() - 1));
        smoothedDelaySamples_[channel] = flushDenormal(
            smoothedDelaySamples_[channel] * 0.995f + targetSamples * 0.005f);

        const std::size_t delaySamples = std::clamp<std::size_t>(
            static_cast<std::size_t>(smoothedDelaySamples_[channel]),
            1, buffer.size());
        const std::size_t readPosition =
            (position + buffer.size() - (delaySamples % buffer.size())) % buffer.size();
        const float delayed = flushDenormal(buffer[readPosition]);

        buffer[position] = flushDenormal(softLimiter(input + delayed * feedback));
        position = (position + 1) % buffer.size();
        return input * (1.0f - mix) + delayed * mix;
    }

    float processReverb(float input, int channel) {
        if (!reverbEnabled_[channel].load(std::memory_order_relaxed)) {
            return input;
        }

        const float mix = reverbMix_[channel].load(std::memory_order_relaxed);
        const float decay = reverbDecay_[channel].load(std::memory_order_relaxed);
        float wet = 0.0f;

        for (int line = 0; line < 4; ++line) {
            auto& buffer = reverbBuffers_[channel][line];
            if (buffer.empty()) continue;

            std::size_t& position = reverbPositions_[channel][line];
            const float delayed = flushDenormal(buffer[position]);
            const float filtered = flushDenormal(
                delayed * 0.72f + reverbDampingState_[channel][line] * 0.28f);
            reverbDampingState_[channel][line] = filtered;
            buffer[position] = flushDenormal(input + filtered * decay);
            position = (position + 1) % buffer.size();
            wet += delayed;
        }

        wet *= 0.25f;
        return input * (1.0f - mix) + wet * mix;
    }

    void render(oboe::AudioStream* stream, void* audioData, int32_t numFrames) {
        if (!running_.load(std::memory_order_acquire) || !stream || !audioData || numFrames <= 0) {
            return;
        }

        const int32_t channels = stream->getChannelCount();
        const auto format = stream->getFormat();
        if (channels < 1) return;

        const int32_t sr = sampleRate_.load(std::memory_order_relaxed);
        refreshBlockCoefficients(sr);

        const float targetG0 = gain_[0].load(std::memory_order_relaxed);
        const float targetG1 = gain_[1].load(std::memory_order_relaxed);
        const bool m0 = mute_[0].load(std::memory_order_relaxed);
        const bool m1 = mute_[1].load(std::memory_order_relaxed);
        const bool s0 = solo_[0].load(std::memory_order_relaxed);
        const bool s1 = solo_[1].load(std::memory_order_relaxed);
        const bool soloActive = s0 || s1;

        uint32_t read = readFrame_.load(std::memory_order_relaxed);
        const uint32_t write = writeFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < numFrames; ++frame) {
            smoothedGain_[0] = flushDenormal(smoothedGain_[0] * 0.98f + targetG0 * 0.02f);
            smoothedGain_[1] = flushDenormal(smoothedGain_[1] * 0.98f + targetG1 * 0.02f);

            float left = 0.0f;
            float right = 0.0f;

            if (read != write) {
                const uint32_t slot = read & kMask;
                left = ring_[slot * 2];
                right = ring_[slot * 2 + 1];
                ++read;
            }

            if (m0 || (soloActive && !s0)) left = 0.0f;
            if (m1 || (soloActive && !s1)) right = 0.0f;

            left *= smoothedGain_[0];
            right *= smoothedGain_[1];

            left = processEQ(left, 0);
            right = processEQ(right, 1);

            left = processCompressor(left, 0);
            right = processCompressor(right, 1);

            left = processDelay(left, 0, sr);
            right = processDelay(right, 1, sr);

            left = processReverb(left, 0);
            right = processReverb(right, 1);

            left = softLimiter(left);
            right = softLimiter(right);

            const float outputFramePeak = std::max(std::fabs(left), std::fabs(right));
            updatePeak(outputPeak_, outputFramePeak);
            if (outputFramePeak >= 0.999f) {
                outputClip_.store(true, std::memory_order_relaxed);
            }

            const int32_t base = frame * channels;
            writeSample(audioData, base, format, left);
            if (channels > 1) {
                writeSample(audioData, base + 1, format, right);
            }
        }

        readFrame_.store(read, std::memory_order_release);
    }

    void stopInternal() {
        std::lock_guard<std::mutex> lock(mutex_);

        running_.store(false, std::memory_order_release);

        if (inputStream_) {
            inputStream_->requestStop();
            inputStream_->close();
            inputStream_.reset();
        }

        if (outputStream_) {
            outputStream_->requestStop();
            outputStream_->close();
            outputStream_.reset();
        }

        inputCallback_.reset();
        outputCallback_.reset();

        writeFrame_.store(0, std::memory_order_relaxed);
        readFrame_.store(0, std::memory_order_relaxed);
    }

public:
    UMC22Engine() : ring_(kCapacity * 2, 0.0f) {}

    bool start() {
        std::lock_guard<std::mutex> lock(mutex_);

        if (running_.load(std::memory_order_acquire) || inputStream_ || outputStream_) {
            return true;
        }

        disconnected_.store(false, std::memory_order_relaxed);
        inputCallback_ = std::make_unique<InputCallback>(this);
        outputCallback_ = std::make_unique<OutputCallback>(this);

        oboe::AudioStreamBuilder inputBuilder;
        inputBuilder.setDirection(oboe::Direction::Input);
        inputBuilder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        inputBuilder.setSharingMode(oboe::SharingMode::Shared);
        inputBuilder.setFormat(oboe::AudioFormat::Float);
        inputBuilder.setChannelCount(2);
        inputBuilder.setSampleRate(48000);
        inputBuilder.setFormatConversionAllowed(true);
        inputBuilder.setDataCallback(inputCallback_.get());

        oboe::Result result = inputBuilder.openStream(inputStream_);
        if (result != oboe::Result::OK || !inputStream_) {
            inputStream_.reset();
            inputCallback_.reset();
            outputCallback_.reset();
            return false;
        }

        const int32_t sr = inputStream_->getSampleRate() > 0 ? inputStream_->getSampleRate() : 48000;
        sampleRate_.store(sr, std::memory_order_release);
        initializeBuffers(sr);

        oboe::AudioStreamBuilder outputBuilder;
        outputBuilder.setDirection(oboe::Direction::Output);
        outputBuilder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        outputBuilder.setSharingMode(oboe::SharingMode::Shared);
        outputBuilder.setFormat(oboe::AudioFormat::Float);
        outputBuilder.setChannelCount(2);
        outputBuilder.setSampleRate(sr);
        outputBuilder.setFormatConversionAllowed(true);
        outputBuilder.setDataCallback(outputCallback_.get());

        result = outputBuilder.openStream(outputStream_);
        if (result != oboe::Result::OK || !outputStream_) {
            inputStream_->close();
            inputStream_.reset();
            outputStream_.reset();
            inputCallback_.reset();
            outputCallback_.reset();
            return false;
        }

        writeFrame_.store(0, std::memory_order_relaxed);
        readFrame_.store(0, std::memory_order_relaxed);
        running_.store(true, std::memory_order_release);

        result = outputStream_->requestStart();
        if (result != oboe::Result::OK) {
            running_.store(false, std::memory_order_release);
            outputStream_->close();
            inputStream_->close();
            outputStream_.reset();
            inputStream_.reset();
            inputCallback_.reset();
            outputCallback_.reset();
            return false;
        }

        result = inputStream_->requestStart();
        if (result != oboe::Result::OK) {
            running_.store(false, std::memory_order_release);
            outputStream_->requestStop();
            inputStream_->requestStop();
            outputStream_->close();
            inputStream_->close();
            outputStream_.reset();
            inputStream_.reset();
            inputCallback_.reset();
            outputCallback_.reset();
            return false;
        }

        return true;
    }

    void stop() {
        disconnected_.store(false, std::memory_order_relaxed);
        stopInternal();
    }

    bool isRunning() const {
        return running_.load(std::memory_order_acquire);
    }

    bool consumeDisconnectedFlag() {
        return disconnected_.exchange(false, std::memory_order_acq_rel);
    }

    void readAndResetMeters(float* values, int count) {
        if (count >= 6) {
            values[0] = inputPeak_[0].exchange(0.0f, std::memory_order_relaxed);
            values[1] = inputPeak_[1].exchange(0.0f, std::memory_order_relaxed);
            values[2] = outputPeak_.exchange(0.0f, std::memory_order_relaxed);
            values[3] = inputClip_[0].exchange(false, std::memory_order_relaxed) ? 1.0f : 0.0f;
            values[4] = inputClip_[1].exchange(false, std::memory_order_relaxed) ? 1.0f : 0.0f;
            values[5] = outputClip_.exchange(false, std::memory_order_relaxed) ? 1.0f : 0.0f;
        }
        if (count >= 8) {
            values[6] = compressorGrDb_[0].exchange(0.0f, std::memory_order_relaxed);
            values[7] = compressorGrDb_[1].exchange(0.0f, std::memory_order_relaxed);
        }
    }

    void setGains(float left, float right) {
        gain_[0].store(std::clamp(left, 0.0f, 1.0f), std::memory_order_relaxed);
        gain_[1].store(std::clamp(right, 0.0f, 1.0f), std::memory_order_relaxed);
    }

    void setMutes(bool left, bool right) {
        mute_[0].store(left, std::memory_order_relaxed);
        mute_[1].store(right, std::memory_order_relaxed);
    }

    void setSolos(bool left, bool right) {
        solo_[0].store(left, std::memory_order_relaxed);
        solo_[1].store(right, std::memory_order_relaxed);
    }

    void setEQ(int channel, float low, float mid, float high) {
        if (channel < 0 || channel > 1) return;
        eqLow_[channel].store(std::clamp(low, -12.0f, 12.0f), std::memory_order_relaxed);
        eqMid_[channel].store(std::clamp(mid, -12.0f, 12.0f), std::memory_order_relaxed);
        eqHigh_[channel].store(std::clamp(high, -12.0f, 12.0f), std::memory_order_relaxed);
    }

    void setDelay(int channel, bool enabled, float timeMs, float feedback, float mix) {
        if (channel < 0 || channel > 1) return;
        delayEnabled_[channel].store(enabled, std::memory_order_relaxed);
        delayTimeMs_[channel].store(std::clamp(timeMs, 50.0f, 800.0f), std::memory_order_relaxed);
        delayFeedback_[channel].store(std::clamp(feedback, 0.0f, 0.85f), std::memory_order_relaxed);
        delayMix_[channel].store(std::clamp(mix, 0.0f, 1.0f), std::memory_order_relaxed);
    }

    void setReverb(int channel, bool enabled, float mix, float decay) {
        if (channel < 0 || channel > 1) return;
        reverbEnabled_[channel].store(enabled, std::memory_order_relaxed);
        reverbMix_[channel].store(std::clamp(mix, 0.0f, 1.0f), std::memory_order_relaxed);
        reverbDecay_[channel].store(std::clamp(decay, 0.20f, 0.92f), std::memory_order_relaxed);
    }

    void setCompressor(
        int channel,
        bool enabled,
        float threshold,
        float ratio,
        float attackMs,
        float releaseMs,
        float makeupDb) {
        if (channel < 0 || channel > 1) return;
        compressorEnabled_[channel].store(enabled, std::memory_order_relaxed);
        compressorThreshold_[channel].store(std::clamp(threshold, -60.0f, 0.0f), std::memory_order_relaxed);
        compressorRatio_[channel].store(std::clamp(ratio, 1.0f, 20.0f), std::memory_order_relaxed);
        compressorAttackMs_[channel].store(std::clamp(attackMs, 1.0f, 100.0f), std::memory_order_relaxed);
        compressorReleaseMs_[channel].store(std::clamp(releaseMs, 10.0f, 500.0f), std::memory_order_relaxed);
        compressorMakeupDb_[channel].store(std::clamp(makeupDb, 0.0f, 24.0f), std::memory_order_relaxed);
    }
};

static std::unique_ptr<UMC22Engine> gEngine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(JNIEnv*, jobject) {
    if (!gEngine) {
        gEngine = std::make_unique<UMC22Engine>();
    }
    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(JNIEnv*, jobject) {
    if (gEngine) {
        gEngine->stop();
    }
}

JNIEXPORT jfloatArray JNICALL
Java_com_umc22_livemixer_MainActivity_nativeGetMeters(JNIEnv* env, jobject) {
    jfloat values[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    if (gEngine) {
        gEngine->readAndResetMeters(values, 8);
    }
    jfloatArray result = env->NewFloatArray(8);
    if (result != nullptr) {
        env->SetFloatArrayRegion(result, 0, 8, values);
    }
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeConsumeDisconnected(JNIEnv*, jobject) {
    return (gEngine && gEngine->consumeDisconnectedFlag()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
        JNIEnv*, jobject, jfloat left, jfloat right) {
    if (gEngine) {
        gEngine->setGains(left, right);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
        JNIEnv*, jobject, jboolean left, jboolean right) {
    if (gEngine) {
        gEngine->setMutes(left == JNI_TRUE, right == JNI_TRUE);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetSolos(
        JNIEnv*, jobject, jboolean left, jboolean right) {
    if (gEngine) {
        gEngine->setSolos(left == JNI_TRUE, right == JNI_TRUE);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetEq(
        JNIEnv*, jobject, jint channel, jfloat low, jfloat mid, jfloat high) {
    if (gEngine) {
        gEngine->setEQ(channel, low, mid, high);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetCompressor(
        JNIEnv*, jobject, jint channel, jboolean enabled,
        jfloat threshold, jfloat ratio, jfloat attackMs,
        jfloat releaseMs, jfloat makeupDb) {
    if (gEngine) {
        gEngine->setCompressor(
            channel, enabled == JNI_TRUE, threshold, ratio,
            attackMs, releaseMs, makeupDb);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetDelay(
        JNIEnv*, jobject, jint channel, jboolean enabled,
        jfloat timeMs, jfloat feedback, jfloat mix) {
    if (gEngine) {
        gEngine->setDelay(channel, enabled == JNI_TRUE, timeMs, feedback, mix);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetReverb(
        JNIEnv*, jobject, jint channel, jboolean enabled,
        jfloat mix, jfloat decay) {
    if (gEngine) {
        gEngine->setReverb(channel, enabled == JNI_TRUE, mix, decay);
    }
}

} // extern "C"
