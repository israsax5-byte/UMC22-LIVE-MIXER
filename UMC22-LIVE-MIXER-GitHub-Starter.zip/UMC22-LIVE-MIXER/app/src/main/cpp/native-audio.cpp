#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

class UMC22Engine {
private:
    static constexpr uint32_t kCapacity = 16384; // Power of two.
    static constexpr uint32_t kMask = kCapacity - 1;

    class InputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit InputCallback(UMC22Engine* owner) : owner_(owner) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream, void* audioData, int32_t frames) override {
            owner_->capture(stream, audioData, frames);
            return oboe::DataCallbackResult::Continue;
        }
    private:
        UMC22Engine* owner_;
    };

    class OutputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit OutputCallback(UMC22Engine* owner) : owner_(owner) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream, void* audioData, int32_t frames) override {
            owner_->render(stream, audioData, frames);
            return oboe::DataCallbackResult::Continue;
        }
    private:
        UMC22Engine* owner_;
    };

    std::shared_ptr<oboe::AudioStream> input_;
    std::shared_ptr<oboe::AudioStream> output_;
    InputCallback inputCallback_{this};
    OutputCallback outputCallback_{this};

    // Single-producer (input callback), single-consumer (output callback).
    std::vector<float> ring_{kCapacity * 2, 0.0f};
    alignas(64) std::atomic<uint32_t> writeFrame_{0};
    alignas(64) std::atomic<uint32_t> readFrame_{0};

    std::atomic<float> gainLeft_{0.75f};
    std::atomic<float> gainRight_{0.65f};
    std::atomic<bool> muteLeft_{false};
    std::atomic<bool> muteRight_{false};

    std::mutex lifecycleMutex_;

    void capture(oboe::AudioStream* stream, void* audioData, int32_t frames) {
        if (stream->getFormat() != oboe::AudioFormat::Float) return;

        const int channels = stream->getChannelCount();
        if (channels < 1) return;
        const auto* input = static_cast<const float*>(audioData);

        uint32_t write = writeFrame_.load(std::memory_order_relaxed);
        const uint32_t read = readFrame_.load(std::memory_order_acquire);

        for (int32_t i = 0; i < frames; ++i) {
            if (static_cast<uint32_t>(write - read) >= kCapacity) {
                // Ring full: drop this input frame rather than overwrite unread audio.
                continue;
            }

            const float left = input[i * channels];
            const float right = (channels >= 2) ? input[i * channels + 1] : left;

            const uint32_t slot = write & kMask;
            ring_[slot * 2] = left;
            ring_[slot * 2 + 1] = right;
            ++write;
        }

        writeFrame_.store(write, std::memory_order_release);
    }

    void render(oboe::AudioStream* stream, void* audioData, int32_t frames) {
        const int channels = stream->getChannelCount();
        if (stream->getFormat() != oboe::AudioFormat::Float || channels < 1) {
            return;
        }

        auto* output = static_cast<float*>(audioData);
        const float leftGain = muteLeft_.load(std::memory_order_relaxed)
            ? 0.0f : gainLeft_.load(std::memory_order_relaxed);
        const float rightGain = muteRight_.load(std::memory_order_relaxed)
            ? 0.0f : gainRight_.load(std::memory_order_relaxed);

        uint32_t read = readFrame_.load(std::memory_order_relaxed);
        const uint32_t write = writeFrame_.load(std::memory_order_acquire);

        for (int32_t i = 0; i < frames; ++i) {
            float left = 0.0f;
            float right = 0.0f;

            if (read != write) {
                const uint32_t slot = read & kMask;
                left = ring_[slot * 2];
                right = ring_[slot * 2 + 1];
                ++read;
            }

            if (channels >= 2) {
                output[i * channels] = left * leftGain;
                output[i * channels + 1] = right * rightGain;
                for (int c = 2; c < channels; ++c) {
                    output[i * channels + c] = 0.0f;
                }
            } else {
                output[i] = 0.5f * (left * leftGain + right * rightGain);
            }
        }

        readFrame_.store(read, std::memory_order_release);
    }

    void closeStreamsLocked() {
        if (input_) {
            input_->requestStop();
            input_->close();
            input_.reset();
        }
        if (output_) {
            output_->requestStop();
            output_->close();
            output_.reset();
        }
    }

public:
    bool start() {
        std::lock_guard<std::mutex> lock(lifecycleMutex_);
        if (input_ || output_) return false;

        writeFrame_.store(0, std::memory_order_relaxed);
        readFrame_.store(0, std::memory_order_relaxed);

        oboe::AudioStreamBuilder inputBuilder;
        inputBuilder.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setSampleRate(48000)
            ->setCallback(&inputCallback_);

        oboe::Result result = inputBuilder.openStream(input_);
        if (result != oboe::Result::OK || !input_) {
            input_.reset();
            return false;
        }

        if (input_->getFormat() != oboe::AudioFormat::Float ||
            input_->getChannelCount() < 1 ||
            input_->getChannelCount() > 2) {
            closeStreamsLocked();
            return false;
        }

        oboe::AudioStreamBuilder outputBuilder;
        outputBuilder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setSampleRate(input_->getSampleRate())
            ->setCallback(&outputCallback_);

        result = outputBuilder.openStream(output_);
        if (result != oboe::Result::OK || !output_) {
            closeStreamsLocked();
            return false;
        }

        if (output_->getFormat() != oboe::AudioFormat::Float ||
            output_->getChannelCount() < 1 ||
            output_->getSampleRate() != input_->getSampleRate()) {
            closeStreamsLocked();
            return false;
        }

        if (output_->requestStart() != oboe::Result::OK) {
            closeStreamsLocked();
            return false;
        }

        if (input_->requestStart() != oboe::Result::OK) {
            closeStreamsLocked();
            return false;
        }

        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(lifecycleMutex_);
        closeStreamsLocked();
        writeFrame_.store(0, std::memory_order_relaxed);
        readFrame_.store(0, std::memory_order_relaxed);
    }

    void setGains(float left, float right) {
        gainLeft_.store(std::clamp(left, 0.0f, 1.0f), std::memory_order_relaxed);
        gainRight_.store(std::clamp(right, 0.0f, 1.0f), std::memory_order_relaxed);
    }

    void setMutes(bool left, bool right) {
        muteLeft_.store(left, std::memory_order_relaxed);
        muteRight_.store(right, std::memory_order_relaxed);
    }
};

static UMC22Engine gEngine;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(JNIEnv*, jobject) {
    return gEngine.start() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(JNIEnv*, jobject) {
    gEngine.stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
    JNIEnv*, jobject, jfloat left, jfloat right) {
    gEngine.setGains(left, right);
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
    JNIEnv*, jobject, jboolean left, jboolean right) {
    gEngine.setMutes(left == JNI_TRUE, right == JNI_TRUE);
}
