
#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstddef>
#include <memory>
#include <mutex>
#include <vector>

class UMC22Engine {
private:
    static constexpr uint32_t kCapacity = 16384;
    static constexpr uint32_t kMask = kCapacity - 1;

    class InputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit InputCallback(UMC22Engine* engine)
            : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream*,
            void* audioData,
            int32_t numFrames) override {
            engine_->capture(audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

    private:
        UMC22Engine* engine_;
    };

    class OutputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit OutputCallback(UMC22Engine* engine)
            : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* audioData,
            int32_t numFrames) override {
            engine_->render(stream, audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

    private:
        UMC22Engine* engine_;
    };

    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;

    std::unique_ptr<InputCallback> inputCallback_;
    std::unique_ptr<OutputCallback> outputCallback_;

    std::vector<float> ring_;

    std::atomic<uint32_t> writeFrame_{0};
    std::atomic<uint32_t> readFrame_{0};

    std::atomic<float> gain_[2] = {0.75f, 0.65f};
    std::atomic<bool> mute_[2] = {false, false};
    std::atomic<bool> solo_[2] = {false, false};

    // Peak meters are accumulated on the audio callbacks and read/reset by the UI.
    std::atomic<float> inputPeak_[2] = {0.0f, 0.0f};
    std::atomic<float> outputPeak_{0.0f};
    std::atomic<bool> inputClip_[2] = {false, false};
    std::atomic<bool> outputClip_{false};

    static void updatePeak(std::atomic<float>& target, float sample) {
        const float peak = std::fabs(sample);
        float previous = target.load(std::memory_order_relaxed);
        while (peak > previous &&
               !target.compare_exchange_weak(previous, peak,
                   std::memory_order_relaxed, std::memory_order_relaxed)) {}
    }

    std::atomic<float> eqLow_[2] = {0.0f, 0.0f};
    std::atomic<float> eqMid_[2] = {0.0f, 0.0f};
    std::atomic<float> eqHigh_[2] = {0.0f, 0.0f};

    std::atomic<bool> compressorEnabled_[2] = {false, false};
    std::atomic<float> compressorThreshold_[2] = {-18.0f, -18.0f};
    std::atomic<float> compressorRatio_[2] = {3.0f, 3.0f};
    std::atomic<float> compressorAttackMs_[2] = {10.0f, 10.0f};
    std::atomic<float> compressorReleaseMs_[2] = {100.0f, 100.0f};
    std::atomic<float> compressorMakeupDb_[2] = {0.0f, 0.0f};

    std::atomic<bool> reverbEnabled_[2] = {false, false};
    std::atomic<float> reverbMix_[2] = {0.25f, 0.25f};
    std::atomic<float> reverbDecay_[2] = {0.65f, 0.65f};
    std::vector<float> reverbBuffers_[2][4];
    std::size_t reverbPositions_[2][4] = {};
    float reverbDampingState_[2][4] = {};

    std::atomic<bool> delayEnabled_[2] = {false, false};
    std::atomic<float> delayTimeMs_[2] = {300.0f, 300.0f};
    std::atomic<float> delayFeedback_[2] = {0.35f, 0.35f};
    std::atomic<float> delayMix_[2] = {0.25f, 0.25f};
    std::vector<float> delayBuffers_[2];
    std::size_t delayPositions_[2] = {};

    float lowState_[2] = {0.0f, 0.0f};
    float midState_[2] = {0.0f, 0.0f};
    float compressorEnvelope_[2] = {0.0f, 0.0f};

    std::mutex mutex_;
    int32_t sampleRate_ = 48000;

    float readSample(const void* data, int32_t index,
                     oboe::AudioFormat format) {
        if (format == oboe::AudioFormat::Float) {
            return static_cast<const float*>(data)[index];
        }

        if (format == oboe::AudioFormat::I16) {
            return static_cast<const int16_t*>(data)[index] / 32768.0f;
        }

        return 0.0f;
    }

    void writeSample(void* data, int32_t index,
                     oboe::AudioFormat format, float value) {
        value = std::clamp(value, -1.0f, 1.0f);

        if (format == oboe::AudioFormat::Float) {
            static_cast<float*>(data)[index] = value;
        } else if (format == oboe::AudioFormat::I16) {
            static_cast<int16_t*>(data)[index] =
                static_cast<int16_t>(value * 32767.0f);
        }
    }

    void capture(void* audioData, int32_t numFrames) {
        if (!inputStream_) return;

        const int32_t channels = inputStream_->getChannelCount();
        const auto format = inputStream_->getFormat();

        if (channels < 1) return;

        const auto* data = audioData;

        uint32_t write = writeFrame_.load(std::memory_order_relaxed);
        uint32_t read = readFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < numFrames; ++frame) {
            if ((write - read) >= kCapacity) {
                readFrame_.store(read + 1, std::memory_order_release);
                ++read;
            }

            const int32_t base = frame * channels;

            float left = readSample(data, base, format);
            float right = channels > 1
                ? readSample(data, base + 1, format)
                : left;

            updatePeak(inputPeak_[0], left);
            updatePeak(inputPeak_[1], right);
            if (std::fabs(left) >= 0.999f) inputClip_[0].store(true, std::memory_order_relaxed);
            if (std::fabs(right) >= 0.999f) inputClip_[1].store(true, std::memory_order_relaxed);

            const uint32_t slot = write & kMask;

            ring_[slot * 2] = left;
            ring_[slot * 2 + 1] = right;

            ++write;
        }

        writeFrame_.store(write, std::memory_order_release);
    }

    float processEQ(float input, int channel) {
        constexpr float lowCutoff = 250.0f;
        constexpr float highCutoff = 2500.0f;

        const float lowAlpha = std::exp(
            -2.0f * 3.14159265f * lowCutoff / sampleRate_);

        const float highAlpha = std::exp(
            -2.0f * 3.14159265f * highCutoff / sampleRate_);

        lowState_[channel] =
            (1.0f - lowAlpha) * input +
            lowAlpha * lowState_[channel];

        midState_[channel] =
            (1.0f - highAlpha) * input +
            highAlpha * midState_[channel];

        const float low = lowState_[channel];
        const float mid = midState_[channel] - low;
        const float high = input - midState_[channel];

        const float lowGain = std::pow(
            10.0f, eqLow_[channel].load() / 20.0f);

        const float midGain = std::pow(
            10.0f, eqMid_[channel].load() / 20.0f);

        const float highGain = std::pow(
            10.0f, eqHigh_[channel].load() / 20.0f);

        return low * lowGain + mid * midGain + high * highGain;
    }

    float processCompressor(float input, int channel) {
        if (!compressorEnabled_[channel].load(std::memory_order_relaxed)) {
            return input;
        }

        const float thresholdDb = compressorThreshold_[channel].load(std::memory_order_relaxed);
        const float ratio = compressorRatio_[channel].load(std::memory_order_relaxed);
        const float attackMs = compressorAttackMs_[channel].load(std::memory_order_relaxed);
        const float releaseMs = compressorReleaseMs_[channel].load(std::memory_order_relaxed);
        const float makeupDb = compressorMakeupDb_[channel].load(std::memory_order_relaxed);

        const float attackCoefficient = std::exp(-1.0f / (sampleRate_ * attackMs * 0.001f));
        const float releaseCoefficient = std::exp(-1.0f / (sampleRate_ * releaseMs * 0.001f));
        const float magnitude = std::fabs(input);

        if (magnitude > compressorEnvelope_[channel]) {
            compressorEnvelope_[channel] = attackCoefficient * compressorEnvelope_[channel]
                + (1.0f - attackCoefficient) * magnitude;
        } else {
            compressorEnvelope_[channel] = releaseCoefficient * compressorEnvelope_[channel]
                + (1.0f - releaseCoefficient) * magnitude;
        }

        const float envelopeDb = 20.0f * std::log10(std::max(compressorEnvelope_[channel], 1.0e-8f));
        float outputDb = envelopeDb;
        if (envelopeDb > thresholdDb) {
            outputDb = thresholdDb + (envelopeDb - thresholdDb) / std::max(ratio, 1.0f);
        }

        const float gainDb = outputDb - envelopeDb + makeupDb;
        return input * std::pow(10.0f, gainDb / 20.0f);
    }

    void initializeReverb() {
        // Cuatro líneas de retardo cortas y desiguales forman una reverberación
        // tipo room sencilla. Se reservan aquí, nunca dentro del callback.
        constexpr float delayMs[4] = {29.7f, 37.1f, 41.1f, 43.7f};
        for (int channel = 0; channel < 2; ++channel) {
            for (int line = 0; line < 4; ++line) {
                const size_t length = std::max<std::size_t>(
                    1, static_cast<std::size_t>(sampleRate_ * delayMs[line] / 1000.0f));
                reverbBuffers_[channel][line].assign(length, 0.0f);
                reverbPositions_[channel][line] = 0;
                reverbDampingState_[channel][line] = 0.0f;
            }
        }
        // Hasta 1.2 s de retardo por canal; la memoria se reserva fuera del callback.
        const std::size_t delayCapacity = std::max<std::size_t>(
            1, static_cast<std::size_t>(sampleRate_ * 1.2f));
        for (int channel = 0; channel < 2; ++channel) {
            delayBuffers_[channel].assign(delayCapacity, 0.0f);
            delayPositions_[channel] = 0;
        }
    }

    float processDelay(float input, int channel) {
        auto& buffer = delayBuffers_[channel];
        if (buffer.empty()) return input;

        std::size_t& position = delayPositions_[channel];
        const bool enabled = delayEnabled_[channel].load(std::memory_order_relaxed);
        if (!enabled) {
            // Vacía la línea mientras está apagada para no reproducir ecos antiguos.
            buffer[position] = 0.0f;
            position = (position + 1) % buffer.size();
            return input;
        }

        const float timeMs = delayTimeMs_[channel].load(std::memory_order_relaxed);
        const float feedback = delayFeedback_[channel].load(std::memory_order_relaxed);
        const float mix = delayMix_[channel].load(std::memory_order_relaxed);
        const std::size_t delaySamples = std::clamp<std::size_t>(
            static_cast<std::size_t>(sampleRate_ * timeMs / 1000.0f),
            1, buffer.size());
        const std::size_t readPosition =
            (position + buffer.size() - delaySamples % buffer.size()) % buffer.size();
        const float delayed = buffer[readPosition];
        buffer[position] = input + delayed * feedback;
        position = (position + 1) % buffer.size();
        return input * (1.0f - mix) + delayed * mix;
    }

    float processReverb(float input, int channel) {
        if (!reverbEnabled_[channel].load(std::memory_order_relaxed)) {
            return input;
        }

        const float mix = reverbMix_[channel].load(std::memory_order_relaxed);
        const float decay = reverbDecay_[channel].load(std::memory_order_relaxed);
        float wet = 0.0f;

        for (int line = 0; line < 4; ++line) {
            auto& buffer = reverbBuffers_[channel][line];
            if (buffer.empty()) continue;

            std::size_t& position = reverbPositions_[channel][line];
            const float delayed = buffer[position];
            // Atenuación suave de agudos para evitar una cola demasiado brillante.
            const float filtered = delayed * 0.72f + reverbDampingState_[channel][line] * 0.28f;
            reverbDampingState_[channel][line] = filtered;
            buffer[position] = input + filtered * decay;
            position = (position + 1) % buffer.size();
            wet += delayed;
        }

        wet *= 0.25f;
        return input * (1.0f - mix) + wet * mix;
    }

    void render(oboe::AudioStream* stream,
                void* audioData, int32_t numFrames) {
        const int32_t channels = stream->getChannelCount();
        const auto format = stream->getFormat();

        if (channels < 1) return;

        auto* output = audioData;

        uint32_t read = readFrame_.load(std::memory_order_relaxed);
        const uint32_t write =
            writeFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < numFrames; ++frame) {
            float left = 0.0f;
            float right = 0.0f;

            if (read != write) {
                const uint32_t slot = read & kMask;
                left = ring_[slot * 2];
                right = ring_[slot * 2 + 1];
                ++read;
            }

            const bool soloActive = solo_[0].load(std::memory_order_relaxed) ||
                                    solo_[1].load(std::memory_order_relaxed);
            if (mute_[0].load(std::memory_order_relaxed) ||
                (soloActive && !solo_[0].load(std::memory_order_relaxed))) {
                left = 0.0f;
            }
            if (mute_[1].load(std::memory_order_relaxed) ||
                (soloActive && !solo_[1].load(std::memory_order_relaxed))) {
                right = 0.0f;
            }

            left *= gain_[0].load();
            right *= gain_[1].load();

            left = processEQ(left, 0);
            right = processEQ(right, 1);

            left = processCompressor(left, 0);
            right = processCompressor(right, 1);
            left = processDelay(left, 0);
            right = processDelay(right, 1);
            left = processReverb(left, 0);
            right = processReverb(right, 1);

            const float outputFramePeak = std::max(std::fabs(left), std::fabs(right));
            updatePeak(outputPeak_, outputFramePeak);
            if (outputFramePeak >= 0.999f) outputClip_.store(true, std::memory_order_relaxed);

            const int32_t base = frame * channels;

            writeSample(output, base, format, left);

            if (channels > 1) {
                writeSample(output, base + 1, format, right);
            }
        }

        readFrame_.store(read, std::memory_order_release);
    }


public:
    UMC22Engine()
        : ring_(kCapacity * 2, 0.0f) {}

    bool start() {
        std::lock_guard<std::mutex> lock(mutex_);

        if (inputStream_ || outputStream_) {
            return true;
        }

        inputCallback_ = std::make_unique<InputCallback>(this);
        outputCallback_ = std::make_unique<OutputCallback>(this);

        oboe::AudioStreamBuilder inputBuilder;

        inputBuilder.setDirection(oboe::Direction::Input);
        inputBuilder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        inputBuilder.setSharingMode(oboe::SharingMode::Shared);
        inputBuilder.setFormat(oboe::AudioFormat::Float);
        inputBuilder.setChannelCount(2);
        inputBuilder.setSampleRate(48000);
        inputBuilder.setFormatConversionAllowed(true);
        inputBuilder.setDataCallback(inputCallback_.get());

        oboe::Result result = inputBuilder.openStream(inputStream_);

        if (result != oboe::Result::OK || !inputStream_) {
            inputStream_.reset();
            return false;
        }

        sampleRate_ = inputStream_->getSampleRate();
        initializeReverb();

        oboe::AudioStreamBuilder outputBuilder;

        outputBuilder.setDirection(oboe::Direction::Output);
        outputBuilder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        outputBuilder.setSharingMode(oboe::SharingMode::Shared);
        outputBuilder.setFormat(oboe::AudioFormat::Float);
        outputBuilder.setChannelCount(2);
        outputBuilder.setSampleRate(sampleRate_);
        outputBuilder.setFormatConversionAllowed(true);
        outputBuilder.setDataCallback(outputCallback_.get());

        result = outputBuilder.openStream(outputStream_);

        if (result != oboe::Result::OK || !outputStream_) {
            inputStream_->close();
            inputStream_.reset();
            outputStream_.reset();
            return false;
        }

        writeFrame_.store(0);
        readFrame_.store(0);

        result = outputStream_->requestStart();

        if (result != oboe::Result::OK) {
            outputStream_->close();
            inputStream_->close();
            outputStream_.reset();
            inputStream_.reset();
            return false;
        }

        result = inputStream_->requestStart();

        if (result != oboe::Result::OK) {
            inputStream_->requestStop();
            outputStream_->requestStop();
            inputStream_->close();
            outputStream_->close();
            inputStream_.reset();
            outputStream_.reset();
            return false;
        }

        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mutex_);

        if (inputStream_) {
            inputStream_->requestStop();
            inputStream_->close();
            inputStream_.reset();
        }

        if (outputStream_) {
            outputStream_->requestStop();
            outputStream_->close();
            outputStream_.reset();
        }

        inputCallback_.reset();
        outputCallback_.reset();

        writeFrame_.store(0);
        readFrame_.store(0);
    }

    void readAndResetMeters(float* values) {
        values[0] = inputPeak_[0].exchange(0.0f, std::memory_order_relaxed);
        values[1] = inputPeak_[1].exchange(0.0f, std::memory_order_relaxed);
        values[2] = outputPeak_.exchange(0.0f, std::memory_order_relaxed);
        values[3] = inputClip_[0].exchange(false, std::memory_order_relaxed) ? 1.0f : 0.0f;
        values[4] = inputClip_[1].exchange(false, std::memory_order_relaxed) ? 1.0f : 0.0f;
        values[5] = outputClip_.exchange(false, std::memory_order_relaxed) ? 1.0f : 0.0f;
    }

    void setGains(float left, float right) {
        gain_[0].store(std::clamp(left, 0.0f, 1.0f));
        gain_[1].store(std::clamp(right, 0.0f, 1.0f));
    }

    void setMutes(bool left, bool right) {
        mute_[0].store(left);
        mute_[1].store(right);
    }

    void setSolos(bool left, bool right) {
        solo_[0].store(left, std::memory_order_relaxed);
        solo_[1].store(right, std::memory_order_relaxed);
    }

    void setEQ(int channel, float low, float mid, float high) {
        if (channel < 0 || channel > 1) return;

        eqLow_[channel].store(std::clamp(low, -12.0f, 12.0f));
        eqMid_[channel].store(std::clamp(mid, -12.0f, 12.0f));
        eqHigh_[channel].store(std::clamp(high, -12.0f, 12.0f));
    }

    void setDelay(int channel, bool enabled, float timeMs, float feedback, float mix) {
        if (channel < 0 || channel > 1) return;
        delayEnabled_[channel].store(enabled, std::memory_order_relaxed);
        delayTimeMs_[channel].store(std::clamp(timeMs, 50.0f, 800.0f), std::memory_order_relaxed);
        delayFeedback_[channel].store(std::clamp(feedback, 0.0f, 0.85f), std::memory_order_relaxed);
        delayMix_[channel].store(std::clamp(mix, 0.0f, 1.0f), std::memory_order_relaxed);
    }

    void setReverb(int channel, bool enabled, float mix, float decay) {
        if (channel < 0 || channel > 1) return;
        reverbEnabled_[channel].store(enabled, std::memory_order_relaxed);
        reverbMix_[channel].store(std::clamp(mix, 0.0f, 1.0f), std::memory_order_relaxed);
        reverbDecay_[channel].store(std::clamp(decay, 0.20f, 0.92f), std::memory_order_relaxed);
    }

    void setCompressor(int channel, bool enabled, float threshold, float ratio,
                       float attackMs, float releaseMs, float makeupDb) {
        if (channel < 0 || channel > 1) return;

        compressorEnabled_[channel].store(enabled, std::memory_order_relaxed);
        compressorThreshold_[channel].store(std::clamp(threshold, -60.0f, 0.0f));
        compressorRatio_[channel].store(std::clamp(ratio, 1.0f, 20.0f));
        compressorAttackMs_[channel].store(std::clamp(attackMs, 1.0f, 100.0f));
        compressorReleaseMs_[channel].store(std::clamp(releaseMs, 10.0f, 500.0f));
        compressorMakeupDb_[channel].store(std::clamp(makeupDb, 0.0f, 24.0f));
    }
};

static std::unique_ptr<UMC22Engine> gEngine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(
        JNIEnv*, jobject) {
    if (!gEngine) {
        gEngine = std::make_unique<UMC22Engine>();
    }

    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(
        JNIEnv*, jobject) {
    if (gEngine) {
        gEngine->stop();
    }
}

JNIEXPORT jfloatArray JNICALL
Java_com_umc22_livemixer_MainActivity_nativeGetMeters(
        JNIEnv* env, jobject) {
    jfloat values[6] = {0, 0, 0, 0, 0, 0};
    if (gEngine) {
        gEngine->readAndResetMeters(values);
    }
    jfloatArray result = env->NewFloatArray(6);
    if (result != nullptr) {
        env->SetFloatArrayRegion(result, 0, 6, values);
    }
    return result;
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
        JNIEnv*, jobject, jfloat left, jfloat right) {
    if (gEngine) {
        gEngine->setGains(left, right);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
        JNIEnv*, jobject, jboolean left, jboolean right) {
    if (gEngine) {
        gEngine->setMutes(
            left == JNI_TRUE,
            right == JNI_TRUE
        );
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetSolos(
        JNIEnv*, jobject, jboolean left, jboolean right) {
    if (gEngine) {
        gEngine->setSolos(left == JNI_TRUE, right == JNI_TRUE);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetEq(
        JNIEnv*, jobject, jint channel,
        jfloat low, jfloat mid, jfloat high) {
    if (gEngine) {
        gEngine->setEQ(channel, low, mid, high);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetCompressor(
        JNIEnv*, jobject, jint channel, jboolean enabled,
        jfloat threshold, jfloat ratio, jfloat attackMs,
        jfloat releaseMs, jfloat makeupDb) {
    if (gEngine) {
        gEngine->setCompressor(
            channel, enabled == JNI_TRUE, threshold, ratio,
            attackMs, releaseMs, makeupDb
        );
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetDelay(
        JNIEnv*, jobject, jint channel, jboolean enabled,
        jfloat timeMs, jfloat feedback, jfloat mix) {
    if (gEngine) {
        gEngine->setDelay(channel, enabled == JNI_TRUE, timeMs, feedback, mix);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetReverb(
        JNIEnv*, jobject, jint channel, jboolean enabled,
        jfloat mix, jfloat decay) {
    if (gEngine) {
        gEngine->setReverb(channel, enabled == JNI_TRUE, mix, decay);
    }
}

}