plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.umc22.livemixer"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.umc22.livemixer"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0"
    }
}
