
# UMC22 LIVE MIXER 0.4.0-test

Proyecto Android experimental para probar captura y reproducción estéreo mediante Oboe.

## Estado y límites

- Esta versión es una prueba de captura/reproducción estéreo con controles de nivel y mute para los dos canales del flujo.
- No implementa EQ, compresor, reverb, delay, SOLO, presets ni mezclas independientes MAIN/PHONES.
- No selecciona explícitamente el dispositivo USB. Android/Oboe pueden enrutar al dispositivo predeterminado disponible.
- La asignación física de entrada izquierda/derecha debe comprobarse en el hardware.
- La UMC22 puede compartir la señal de reproducción entre MAIN y PHONES.
- El motor no tiene compensación de deriva entre relojes de captura y reproducción. Puede producir cortes o silencios durante pruebas prolongadas.
- No se garantiza latencia baja ni compatibilidad con todas las versiones/dispositivos Android.

## Pruebas

Compilar con GitHub Actions. No probar con volumen alto. Empezar con los niveles de salida bajos y detener inmediatamente si hay ruido, acoples o distorsión.
