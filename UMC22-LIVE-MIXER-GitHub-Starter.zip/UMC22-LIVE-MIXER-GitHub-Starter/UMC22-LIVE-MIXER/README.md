
# UMC22 LIVE MIXER 1.0.0

Proyecto Android experimental para probar captura y reproducción estéreo mediante Oboe.

## Estado y límites

- Prueba experimental de captura/reproducción estéreo con controles de nivel, MUTE, SOLO, EQ y presets por canal.
- Añade compresor activable por canal en la salida procesada.
- Añade reverberación tipo room activable por canal, con controles MIX y DECAY.
- No implementa delay ni mezclas independientes MAIN/PHONES.
- No selecciona explícitamente el dispositivo USB. Android/Oboe pueden enrutar al dispositivo predeterminado disponible.
- La asignación física de entrada izquierda/derecha debe comprobarse en el hardware.
- La UMC22 puede compartir la señal de reproducción entre MAIN y PHONES.
- El motor no tiene compensación de deriva entre relojes de captura y reproducción. Puede producir cortes o silencios durante pruebas prolongadas.
- No se garantiza latencia baja ni compatibilidad con todas las versiones/dispositivos Android.

## Pruebas

Compilar con GitHub Actions. No probar con volumen alto. Empezar con los niveles de salida bajos y detener inmediatamente si hay ruido, acoples o distorsión.


## Funciones de la versión 1.0.0
- Dos canales de procesamiento estéreo (L/R del flujo de audio capturado), con fader, MUTE y SOLO.
- EQ LOW, MID y HIGH con presets Voz, Guitarra acústica, Guitarra eléctrica y Bajo.
- Compresor activable de forma independiente por canal procesado.
- Parámetros del compresor: Threshold (-60 a 0 dB), Ratio (1:1 a 20:1), Attack (1 a 100 ms), Release (10 a 500 ms) y Makeup Gain (0 a +24 dB).
- El compresor inicia desactivado para ambos canales.
- No implementa mezclas independientes MAIN/PHONES; SOLO afecta la salida procesada completa.

- Reverb sencilla tipo room por canal, inicialmente desactivada. MIX ajusta la proporción de señal húmeda y DECAY ajusta la realimentación de las líneas de retardo.
- Los parámetros de reverb son experimentales y deben evaluarse escuchando a volumen bajo.


## Versión 1.0.0
- Delay independiente por canal: activación, tiempo (50–800 ms), feedback (0–85 %) y mezcla (0–100 %).
- El efecto comienza apagado en ambos canales.
