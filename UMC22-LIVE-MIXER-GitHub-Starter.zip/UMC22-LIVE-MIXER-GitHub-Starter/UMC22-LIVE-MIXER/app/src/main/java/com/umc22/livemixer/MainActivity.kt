
package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startButton: Button

    private var engineStarted = false

    private var gain1 = 0.75f
    private var gain2 = 0.65f

    private var mute1 = false
    private var mute2 = false

    private var solo1 = false
    private var solo2 = false

    private val eqLow = floatArrayOf(0f, 0f)
    private val eqMid = floatArrayOf(0f, 0f)
    private val eqHigh = floatArrayOf(0f, 0f)

    private val eqSliders = Array(2) { arrayOfNulls<SeekBar>(3) }
    private val eqLabels = Array(2) { arrayOfNulls<TextView>(3) }

    private val compressorEnabled = booleanArrayOf(false, false)
    private val compressorThreshold = floatArrayOf(-18f, -18f)
    private val compressorRatio = floatArrayOf(3f, 3f)
    private val compressorAttack = floatArrayOf(10f, 10f)
    private val compressorRelease = floatArrayOf(100f, 100f)
    private val compressorMakeup = floatArrayOf(0f, 0f)
    private val compressorSliders = Array(2) { arrayOfNulls<SeekBar>(5) }
    private val compressorLabels = Array(2) { arrayOfNulls<TextView>(5) }
    private val compressorButtons = arrayOfNulls<Button>(2)

    private val reverbEnabled = booleanArrayOf(false, false)
    private val reverbMix = floatArrayOf(0.25f, 0.25f)
    private val reverbDecay = floatArrayOf(0.65f, 0.65f)
    private val reverbSliders = Array(2) { arrayOfNulls<SeekBar>(2) }
    private val reverbLabels = Array(2) { arrayOfNulls<TextView>(2) }
    private val reverbButtons = arrayOfNulls<Button>(2)

    private val delayEnabled = booleanArrayOf(false, false)
    private val delayTime = floatArrayOf(300f, 300f)
    private val delayFeedback = floatArrayOf(35f, 35f)
    private val delayMix = floatArrayOf(25f, 25f)
    private val delaySliders = Array(2) { arrayOfNulls<SeekBar>(3) }
    private val delayLabels = Array(2) { arrayOfNulls<TextView>(3) }
    private val delayButtons = arrayOfNulls<Button>(2)

    companion object {
        init {
            System.loadLibrary("umc22_audio")
        }
    }

    private external fun nativeStart(): Boolean
    private external fun nativeStop()
    private external fun nativeSetGains(g1: Float, g2: Float)
    private external fun nativeSetMutes(m1: Boolean, m2: Boolean)
    private external fun nativeSetSolos(s1: Boolean, s2: Boolean)

    private external fun nativeSetEq(
        channel: Int,
        low: Float,
        mid: Float,
        high: Float
    )
    private external fun nativeSetCompressor(
        channel: Int,
        enabled: Boolean,
        threshold: Float,
        ratio: Float,
        attackMs: Float,
        releaseMs: Float,
        makeupDb: Float
    )
    private external fun nativeSetReverb(
        channel: Int,
        enabled: Boolean,
        mix: Float,
        decay: Float
    )
    private external fun nativeSetDelay(
        channel: Int,
        enabled: Boolean,
        timeMs: Float,
        feedback: Float,
        mix: Float
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }

        fun heading(
            value: String,
            size: Float,
            color: Int = 0xFFFFFFFF.toInt()
        ): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 10, 0, 10)
            }
        }

        content.addView(heading("UMC22 LIVE MIXER", 25f))
        content.addView(
            heading(
                "Versión 1.0.0 · Reverb y Delay por canal",
                14f,
                0xFF9FB3C8.toInt()
            )
        )

        status = heading(
            "Comprobando USB…",
            15f,
            0xFF65D6AD.toInt()
        )

        content.addView(status)
        updateUsbStatus()

        startButton = Button(this).apply {
            text = "INICIAR MONITOREO"

            setOnClickListener {
                if (engineStarted) {
                    stopEngine()
                } else if (
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startEngine()
                } else {
                    requestPermissions(
                        arrayOf(Manifest.permission.RECORD_AUDIO),
                        100
                    )
                }
            }
        }

        content.addView(startButton)

        addChannel(content, "CH1 · ENTRADA 1", 75, 1)
        addChannel(content, "CH2 · ENTRADA 2", 65, 2)

        content.addView(
            heading(
                "EQ experimental: LOW, MID y HIGH de -12 dB a +12 dB. " +
                    "Las frecuencias de corte son fijas en esta versión.",
                13f,
                0xFF65D6AD.toInt()
            )
        )

        content.addView(
            heading(
                "Los faders controlan los canales izquierdo y derecho " +
                    "del flujo estéreo detectado. La asignación física " +
                    "de entradas debe verificarse.",
                13f,
                0xFFFFD18A.toInt()
            )
        )

        content.addView(
            heading(
                "SOLO silencia el otro canal en la salida procesada. " +
                    "MAIN y PHONES pueden compartir esa señal; SOLO no está limitado a audífonos.",
                13f,
                0xFFFFD18A.toInt()
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun updateUsbStatus() {
        val usb = getSystemService(USB_SERVICE) as UsbManager
        val devices = usb.deviceList.values

        status.text = if (devices.isEmpty()) {
            "USB: no se detecta dispositivo. Conecta la UMC22 mediante OTG."
        } else {
            "USB: ${devices.size} dispositivo(s) detectado(s)\n" +
                devices.joinToString("\n") {
                    "${it.productName ?: "USB"} · VID ${it.vendorId} · PID ${it.productId}"
                }
        }
    }

    private fun startEngine() {
        if (engineStarted) return

        val started = nativeStart()
        engineStarted = started

        status.text = if (started) {
            "Motor iniciado. Prueba a volumen bajo."
        } else {
            "No se pudo abrir audio. Revisa conexión y permisos."
        }

        startButton.text =
            if (started) "DETENER MONITOREO" else "REINTENTAR"

        if (started) {
            nativeSetGains(gain1, gain2)
            nativeSetMutes(mute1, mute2)
            nativeSetSolos(solo1, solo2)

            for (channel in 0..1) {
                nativeSetEq(
                    channel,
                    eqLow[channel],
                    eqMid[channel],
                    eqHigh[channel]
                )
                sendCompressorSettings(channel)
                sendReverbSettings(channel)
                sendDelaySettings(channel)
            }
        }
    }

    private fun stopEngine() {
        if (engineStarted) {
            nativeStop()
            engineStarted = false
        }

        if (::status.isInitialized) {
            status.text = "Motor detenido"
        }

        if (::startButton.isInitialized) {
            startButton.text = "INICIAR MONITOREO"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 100) {
            if (
                grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                startEngine()
            } else {
                status.text = "Permiso de micrófono denegado."
            }
        }
    }

    private fun addChannel(
        root: LinearLayout,
        name: String,
        initial: Int,
        channel: Int
    ) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
            setBackgroundColor(0xFF1B2A36.toInt())
        }

        panel.addView(TextView(this).apply {
            text = name
            textSize = 19f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 8, 0, 10)
        })

        val level = TextView(this).apply {
            text = "NIVEL: $initial%"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }

        panel.addView(level)

        val fader = SeekBar(this).apply {
            max = 100
            progress = initial
        }

        fader.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    bar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    level.text = "NIVEL: $progress%"

                    if (channel == 1) {
                        gain1 = progress / 100f
                    } else {
                        gain2 = progress / 100f
                    }

                    if (engineStarted) {
                        nativeSetGains(gain1, gain2)
                    }
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            }
        )

        panel.addView(fader)

        val mute = Button(this).apply {
            text = "MUTE: OFF"

            setOnClickListener {
                if (channel == 1) {
                    mute1 = !mute1
                    text = if (mute1) "MUTE: ON" else "MUTE: OFF"
                } else {
                    mute2 = !mute2
                    text = if (mute2) "MUTE: ON" else "MUTE: OFF"
                }

                if (engineStarted) {
                    nativeSetMutes(mute1, mute2)
                }
            }
        }

        panel.addView(
            mute,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val solo = Button(this).apply {
            text = "SOLO: OFF"
            setOnClickListener {
                if (channel == 1) {
                    solo1 = !solo1
                    text = if (solo1) "SOLO: ON" else "SOLO: OFF"
                } else {
                    solo2 = !solo2
                    text = if (solo2) "SOLO: ON" else "SOLO: OFF"
                }
                if (engineStarted) {
                    nativeSetSolos(solo1, solo2)
                }
            }
        }
        panel.addView(
            solo,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val presetButton = Button(this).apply {
            text = "PRESETS DE SONIDO"
            setOnClickListener { showPresets(channel) }
        }
        panel.addView(presetButton)

        addEqControl(panel, "LOW", channel, 0)
        addEqControl(panel, "MID", channel, 1)
        addEqControl(panel, "HIGH", channel, 2)
        addCompressorControls(panel, channel)
        addReverbControls(panel, channel)
        addDelayControls(panel, channel)

        root.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 18
            }
        )
    }

    private fun addEqControl(
        panel: LinearLayout,
        band: String,
        channel: Int,
        type: Int
    ) {
        val channelIndex = channel - 1

        val value = when (type) {
            0 -> eqLow[channelIndex]
            1 -> eqMid[channelIndex]
            else -> eqHigh[channelIndex]
        }

        val label = TextView(this).apply {
            text = "$band: ${value.toInt()} dB"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 0)
        }

        panel.addView(label)
        eqLabels[channelIndex][type] = label

        val slider = SeekBar(this).apply {
            max = 24
            progress = (value + 12f).toInt()
        }

        eqSliders[channelIndex][type] = slider

        slider.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    bar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val db = (progress - 12).toFloat()

                    when (type) {
                        0 -> eqLow[channelIndex] = db
                        1 -> eqMid[channelIndex] = db
                        2 -> eqHigh[channelIndex] = db
                    }

                    label.text = "$band: ${db.toInt()} dB"

                    if (engineStarted) {
                        nativeSetEq(
                            channelIndex,
                            eqLow[channelIndex],
                            eqMid[channelIndex],
                            eqHigh[channelIndex]
                        )
                    }
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            }
        )

        panel.addView(slider)
    }


    private fun addCompressorControls(panel: LinearLayout, channel: Int) {
        val index = channel - 1
        panel.addView(TextView(this).apply {
            text = "COMPRESOR · CH$channel"
            textSize = 17f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 14, 0, 4)
        })

        val toggle = Button(this).apply {
            text = if (compressorEnabled[index]) "COMPRESOR: ON" else "COMPRESOR: OFF"
            setOnClickListener {
                compressorEnabled[index] = !compressorEnabled[index]
                text = if (compressorEnabled[index]) "COMPRESOR: ON" else "COMPRESOR: OFF"
                sendCompressorSettings(index)
            }
        }
        compressorButtons[index] = toggle
        panel.addView(toggle)

        addCompressorSlider(panel, channel, 0, "THRESHOLD", -60f, 0f, compressorThreshold[index], " dB")
        addCompressorSlider(panel, channel, 1, "RATIO", 1f, 20f, compressorRatio[index], ":1")
        addCompressorSlider(panel, channel, 2, "ATTACK", 1f, 100f, compressorAttack[index], " ms")
        addCompressorSlider(panel, channel, 3, "RELEASE", 10f, 500f, compressorRelease[index], " ms")
        addCompressorSlider(panel, channel, 4, "MAKEUP GAIN", 0f, 24f, compressorMakeup[index], " dB")
    }

    private fun addCompressorSlider(
        panel: LinearLayout,
        channel: Int,
        type: Int,
        title: String,
        minimum: Float,
        maximum: Float,
        initial: Float,
        suffix: String
    ) {
        val index = channel - 1
        val label = TextView(this).apply {
            text = "$title: ${formatCompressorValue(initial, type)}$suffix"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 5, 0, 0)
        }
        panel.addView(label)
        compressorLabels[index][type] = label

        val steps = when (type) {
            0 -> 60
            1 -> 19
            2 -> 99
            3 -> 490
            else -> 240
        }
        val slider = SeekBar(this).apply {
            max = steps
            progress = (((initial - minimum) / (maximum - minimum)) * steps).toInt().coerceIn(0, steps)
        }
        compressorSliders[index][type] = slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = minimum + (maximum - minimum) * progress / steps.toFloat()
                when (type) {
                    0 -> compressorThreshold[index] = value
                    1 -> compressorRatio[index] = value
                    2 -> compressorAttack[index] = value
                    3 -> compressorRelease[index] = value
                    4 -> compressorMakeup[index] = value
                }
                label.text = "$title: ${formatCompressorValue(value, type)}$suffix"
                if (engineStarted) sendCompressorSettings(index)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(slider)
    }

    private fun formatCompressorValue(value: Float, type: Int): String {
        return if (type == 1) String.format(java.util.Locale.US, "%.1f", value)
        else value.toInt().toString()
    }

    private fun sendCompressorSettings(index: Int) {
        if (!engineStarted) return
        nativeSetCompressor(
            index,
            compressorEnabled[index],
            compressorThreshold[index],
            compressorRatio[index],
            compressorAttack[index],
            compressorRelease[index],
            compressorMakeup[index]
        )
    }

    private fun addReverbControls(panel: LinearLayout, channel: Int) {
        val index = channel - 1
        panel.addView(TextView(this).apply {
            text = "REVERB · CH$channel"
            textSize = 17f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 14, 0, 4)
        })

        val toggle = Button(this).apply {
            text = if (reverbEnabled[index]) "REVERB: ON" else "REVERB: OFF"
            setOnClickListener {
                reverbEnabled[index] = !reverbEnabled[index]
                text = if (reverbEnabled[index]) "REVERB: ON" else "REVERB: OFF"
                sendReverbSettings(index)
            }
        }
        reverbButtons[index] = toggle
        panel.addView(toggle)

        addReverbSlider(panel, channel, 0, "MIX", 0f, 100f, reverbMix[index] * 100f, "%")
        addReverbSlider(panel, channel, 1, "DECAY", 20f, 92f, reverbDecay[index] * 100f, "%")
    }

    private fun addReverbSlider(
        panel: LinearLayout,
        channel: Int,
        type: Int,
        title: String,
        minimum: Float,
        maximum: Float,
        initial: Float,
        suffix: String
    ) {
        val index = channel - 1
        val label = TextView(this).apply {
            text = "$title: ${initial.toInt()}$suffix"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 5, 0, 0)
        }
        panel.addView(label)
        reverbLabels[index][type] = label

        val slider = SeekBar(this).apply {
            max = (maximum - minimum).toInt()
            progress = (initial - minimum).toInt().coerceIn(0, max)
        }
        reverbSliders[index][type] = slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = minimum + progress
                if (type == 0) reverbMix[index] = value / 100f
                else reverbDecay[index] = value / 100f
                label.text = "$title: ${value.toInt()}$suffix"
                if (engineStarted) sendReverbSettings(index)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(slider)
    }

    private fun sendReverbSettings(index: Int) {
        if (!engineStarted) return
        nativeSetReverb(
            index,
            reverbEnabled[index],
            reverbMix[index],
            reverbDecay[index]
        )
    }

    private fun addDelayControls(panel: LinearLayout, channel: Int) {
        val index = channel - 1
        panel.addView(TextView(this).apply {
            text = "DELAY · CH$channel"
            textSize = 17f
            setTextColor(0xFF65D6AD.toInt())
            setPadding(0, 14, 0, 4)
        })

        val toggle = Button(this).apply {
            text = if (delayEnabled[index]) "DELAY: ON" else "DELAY: OFF"
            setOnClickListener {
                delayEnabled[index] = !delayEnabled[index]
                text = if (delayEnabled[index]) "DELAY: ON" else "DELAY: OFF"
                sendDelaySettings(index)
            }
        }
        delayButtons[index] = toggle
        panel.addView(toggle)

        addDelaySlider(panel, channel, 0, "TIME", 50f, 800f, delayTime[index], " ms")
        addDelaySlider(panel, channel, 1, "FEEDBACK", 0f, 85f, delayFeedback[index], "%")
        addDelaySlider(panel, channel, 2, "MIX", 0f, 100f, delayMix[index], "%")
    }

    private fun addDelaySlider(
        panel: LinearLayout,
        channel: Int,
        type: Int,
        title: String,
        minimum: Float,
        maximum: Float,
        initial: Float,
        suffix: String
    ) {
        val index = channel - 1
        val label = TextView(this).apply {
            text = "$title: ${initial.toInt()}$suffix"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 5, 0, 0)
        }
        panel.addView(label)
        delayLabels[index][type] = label

        val slider = SeekBar(this).apply {
            max = (maximum - minimum).toInt()
            progress = (initial - minimum).toInt().coerceIn(0, max)
        }
        delaySliders[index][type] = slider
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = minimum + progress
                when (type) {
                    0 -> delayTime[index] = value
                    1 -> delayFeedback[index] = value
                    else -> delayMix[index] = value
                }
                label.text = "$title: ${value.toInt()}$suffix"
                if (engineStarted) sendDelaySettings(index)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        panel.addView(slider)
    }

    private fun sendDelaySettings(index: Int) {
        if (!engineStarted) return
        nativeSetDelay(
            index,
            delayEnabled[index],
            delayTime[index],
            delayFeedback[index] / 100f,
            delayMix[index] / 100f
        )
    }

    private fun showPresets(channel: Int) {
        val presets = arrayOf(
            "Voz",
            "Guitarra acústica",
            "Guitarra eléctrica",
            "Bajo",
            "Personalizado (mantener ajustes)"
        )

        AlertDialog.Builder(this)
            .setTitle("Preset para CH$channel")
            .setItems(presets) { _, which ->
                val values = when (which) {
                    0 -> floatArrayOf(-2f, 2f, 2f)   // Voz
                    1 -> floatArrayOf(-1f, 1f, 2f)   // Acústica
                    2 -> floatArrayOf(1f, 2f, 0f)    // Eléctrica
                    3 -> floatArrayOf(4f, 1f, -2f)   // Bajo
                    else -> null
                }
                if (values != null) applyEqPreset(channel, values)
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun applyEqPreset(channel: Int, values: FloatArray) {
        val index = channel - 1
        eqLow[index] = values[0]
        eqMid[index] = values[1]
        eqHigh[index] = values[2]

        for (band in 0..2) {
            eqSliders[index][band]?.progress = (values[band] + 12f).toInt()
            val name = when (band) {
                0 -> "LOW"
                1 -> "MID"
                else -> "HIGH"
            }
            eqLabels[index][band]?.text = "$name: ${values[band].toInt()} dB"
        }

        if (engineStarted) {
            nativeSetEq(index, eqLow[index], eqMid[index], eqHigh[index])
        }
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }
}
