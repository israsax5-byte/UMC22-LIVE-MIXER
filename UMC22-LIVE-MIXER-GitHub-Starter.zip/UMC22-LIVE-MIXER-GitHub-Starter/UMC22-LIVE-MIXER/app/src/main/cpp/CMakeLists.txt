cmake_minimum_required(VERSION 3.22.1)
project(UMC22LiveMixer LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(oboe REQUIRED CONFIG)

add_library(umc22_audio SHARED native-audio.cpp)

target_link_libraries(
    umc22_audio
    PRIVATE
    oboe::oboe
    android
    log
)
