      #include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

class UMC22Engine {
private:
    static constexpr uint32_t kCapacity = 16384;
    static constexpr uint32_t kMask = kCapacity - 1;

    class InputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit InputCallback(UMC22Engine* engine)
            : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream*,
            void* audioData,
            int32_t numFrames) override {
            engine_->capture(audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

    private:
        UMC22Engine* engine_;
    };

    class OutputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit OutputCallback(UMC22Engine* engine)
            : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* audioData,
            int32_t numFrames) override {
            engine_->render(stream, audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

    private:
        UMC22Engine* engine_;
    };

    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;

    std::unique_ptr<InputCallback> inputCallback_;
    std::unique_ptr<OutputCallback> outputCallback_;

    std::vector<float> ring_;

    std::atomic<uint32_t> writeFrame_{0};
    std::atomic<uint32_t> readFrame_{0};

    std::atomic<float> gain_[2] = {0.75f, 0.65f};
    std::atomic<bool> mute_[2] = {false, false};

    std::atomic<float> eqLow_[2] = {0.0f, 0.0f};
    std::atomic<float> eqMid_[2] = {0.0f, 0.0f};
    std::atomic<float> eqHigh_[2] = {0.0f, 0.0f};

    float lowState_[2] = {0.0f, 0.0f};
    float midState_[2] = {0.0f, 0.0f};

    std::mutex mutex_;
    int32_t sampleRate_ = 48000;
#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

class UMC22Engine {
private:
    static constexpr uint32_t kCapacity = 16384;
    static constexpr uint32_t kMask = kCapacity - 1;

    class InputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit InputCallback(UMC22Engine* engine)
            : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream*,
            void* audioData,
            int32_t numFrames) override {
            engine_->capture(audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

    private:
        UMC22Engine* engine_;
    };

    class OutputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit OutputCallback(UMC22Engine* engine)
            : engine_(engine) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* audioData,
            int32_t numFrames) override {
            engine_->render(stream, audioData, numFrames);
            return oboe::DataCallbackResult::Continue;
        }

    private:
        UMC22Engine* engine_;
    };

    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;

    std::unique_ptr<InputCallback> inputCallback_;
    std::unique_ptr<OutputCallback> outputCallback_;

    std::vector<float> ring_;

    std::atomic<uint32_t> writeFrame_{0};
    std::atomic<uint32_t> readFrame_{0};

    std::atomic<float> gain_[2] = {0.75f, 0.65f};
    std::atomic<bool> mute_[2] = {false, false};

    std::atomic<float> eqLow_[2] = {0.0f, 0.0f};
    std::atomic<float> eqMid_[2] = {0.0f, 0.0f};
    std::atomic<float> eqHigh_[2] = {0.0f, 0.0f};

    float lowState_[2] = {0.0f, 0.0f};
    float midState_[2] = {0.0f, 0.0f};

    std::mutex mutex_;
    int32_t sampleRate_ = 48000;

    float readSample(const void* data, int32_t index,
                     oboe::AudioFormat format) {
        if (format == oboe::AudioFormat::Float) {
            return static_cast<const float*>(data)[index];
        }

        if (format == oboe::AudioFormat::I16) {
            return static_cast<const int16_t*>(data)[index] / 32768.0f;
        }

        return 0.0f;
    }

    void writeSample(void* data, int32_t index,
                     oboe::AudioFormat format, float value) {
        value = std::clamp(value, -1.0f, 1.0f);

        if (format == oboe::AudioFormat::Float) {
            static_cast<float*>(data)[index] = value;
        } else if (format == oboe::AudioFormat::I16) {
            static_cast<int16_t*>(data)[index] =
                static_cast<int16_t>(value * 32767.0f);
        }
    }

    void capture(void* audioData, int32_t numFrames) {
        if (!inputStream_) return;

        const int32_t channels = inputStream_->getChannelCount();
        const auto format = inputStream_->getFormat();

        if (channels < 1) return;

        const auto* data = audioData;

        uint32_t write = writeFrame_.load(std::memory_order_relaxed);
        uint32_t read = readFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < numFrames; ++frame) {
            if ((write - read) >= kCapacity) {
                readFrame_.store(read + 1, std::memory_order_release);
                ++read;
            }

            const int32_t base = frame * channels;

            float left = readSample(data, base, format);
            float right = channels > 1
                ? readSample(data, base + 1, format)
                : left;

            const uint32_t slot = write & kMask;

            ring_[slot * 2] = left;
            ring_[slot * 2 + 1] = right;

            ++write;
        }

        writeFrame_.store(write, std::memory_order_release);
    }

    float processEQ(float input, int channel) {
        constexpr float lowCutoff = 250.0f;
        constexpr float highCutoff = 2500.0f;

        const float lowAlpha = std::exp(
            -2.0f * 3.14159265f * lowCutoff / sampleRate_);

        const float highAlpha = std::exp(
            -2.0f * 3.14159265f * highCutoff / sampleRate_);

        lowState_[channel] =
            (1.0f - lowAlpha) * input +
            lowAlpha * lowState_[channel];

        midState_[channel] =
            (1.0f - highAlpha) * input +
            highAlpha * midState_[channel];

        const float low = lowState_[channel];
        const float mid = midState_[channel] - low;
        const float high = input - midState_[channel];

        const float lowGain = std::pow(
            10.0f, eqLow_[channel].load() / 20.0f);

        const float midGain = std::pow(
            10.0f, eqMid_[channel].load() / 20.0f);

        const float highGain = std::pow(
            10.0f, eqHigh_[channel].load() / 20.0f);

        return low * lowGain + mid * midGain + high * highGain;
    }

    void render(oboe::AudioStream* stream,
                void* audioData, int32_t numFrames) {
        const int32_t channels = stream->getChannelCount();
        const auto format = stream->getFormat();

        if (channels < 1) return;

        auto* output = audioData;

        uint32_t read = readFrame_.load(std::memory_order_relaxed);
        const uint32_t write =
            writeFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < numFrames; ++frame) {
            float left = 0.0f;
            float right = 0.0f;

            if (read != write) {
                const uint32_t slot = read & kMask;
                left = ring_[slot * 2];
                right = ring_[slot * 2 + 1];
                ++read;
            }

            if (mute_[0].load()) left = 0.0f;
            if (mute_[1].load()) right = 0.0f;

            left *= gain_[0].load();
            right *= gain_[1].load();

            left = processEQ(left, 0);
            right = processEQ(right, 1);

            const int32_t base = frame * channels;

            writeSample(output, base, format, left);

            if (channels > 1) {
                writeSample(output, base + 1, format, right);
            }
        }

        readFrame_.store(read, std::memory_order_release);
    }


public:
    UMC22Engine()
        : ring_(kCapacity * 2, 0.0f) {}

    bool start() {
        std::lock_guard<std::mutex> lock(mutex_);

        if (inputStream_ || outputStream_) {
            return true;
        }

        inputCallback_ = std::make_unique<InputCallback>(this);
        outputCallback_ = std::make_unique<OutputCallback>(this);

        oboe::AudioStreamBuilder inputBuilder;

        inputBuilder.setDirection(oboe::Direction::Input);
        inputBuilder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        inputBuilder.setSharingMode(oboe::SharingMode::Shared);
        inputBuilder.setFormat(oboe::AudioFormat::Float);
        inputBuilder.setChannelCount(2);
        inputBuilder.setSampleRate(48000);
        inputBuilder.setFormatConversionAllowed(true);
        inputBuilder.setDataCallback(inputCallback_.get());

        oboe::Result result = inputBuilder.openStream(inputStream_);

        if (result != oboe::Result::OK || !inputStream_) {
            inputStream_.reset();
            return false;
        }

        sampleRate_ = inputStream_->getSampleRate();

        oboe::AudioStreamBuilder outputBuilder;

        outputBuilder.setDirection(oboe::Direction::Output);
        outputBuilder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        outputBuilder.setSharingMode(oboe::SharingMode::Shared);
        outputBuilder.setFormat(oboe::AudioFormat::Float);
        outputBuilder.setChannelCount(2);
        outputBuilder.setSampleRate(sampleRate_);
        outputBuilder.setFormatConversionAllowed(true);
        outputBuilder.setDataCallback(outputCallback_.get());

        result = outputBuilder.openStream(outputStream_);

        if (result != oboe::Result::OK || !outputStream_) {
            inputStream_->close();
            inputStream_.reset();
            outputStream_.reset();
            return false;
        }

        writeFrame_.store(0);
        readFrame_.store(0);

        result = outputStream_->requestStart();

        if (result != oboe::Result::OK) {
            outputStream_->close();
            inputStream_->close();
            outputStream_.reset();
            inputStream_.reset();
            return false;
        }

        result = inputStream_->requestStart();

        if (result != oboe::Result::OK) {
            inputStream_->requestStop();
            outputStream_->requestStop();
            inputStream_->close();
            outputStream_->close();
            inputStream_.reset();
            outputStream_.reset();
            return false;
        }

        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mutex_);

        if (inputStream_) {
            inputStream_->requestStop();
            inputStream_->close();
            inputStream_.reset();
        }

        if (outputStream_) {
            outputStream_->requestStop();
            outputStream_->close();
            outputStream_.reset();
        }

        inputCallback_.reset();
        outputCallback_.reset();

        writeFrame_.store(0);
        readFrame_.store(0);
    }

    void setGains(float left, float right) {
        gain_[0].store(std::clamp(left, 0.0f, 1.0f));
        gain_[1].store(std::clamp(right, 0.0f, 1.0f));
    }

    void setMutes(bool left, bool right) {
        mute_[0].store(left);
        mute_[1].store(right);
    }

    void setEQ(int channel, float low, float mid, float high) {
        if (channel < 0 || channel > 1) return;

        eqLow_[channel].store(std::clamp(low, -12.0f, 12.0f));
        eqMid_[channel].store(std::clamp(mid, -12.0f, 12.0f));
        eqHigh_[channel].store(std::clamp(high, -12.0f, 12.0f));
    }
};

static std::unique_ptr<UMC22Engine> gEngine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(
        JNIEnv*, jobject) {
    if (!gEngine) {
        gEngine = std::make_unique<UMC22Engine>();
    }

    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(
        JNIEnv*, jobject) {
    if (gEngine) {
        gEngine->stop();
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
        JNIEnv*, jobject, jfloat left, jfloat right) {
    if (gEngine) {
        gEngine->setGains(left, right);
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
        JNIEnv*, jobject, jboolean left, jboolean right) {
    if (gEngine) {
        gEngine->setMutes(
            left == JNI_TRUE,
            right == JNI_TRUE
        );
    }
}

JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetEq(
        JNIEnv*, jobject, jint channel,
        jfloat low, jfloat mid, jfloat high) {
    if (gEngine) {
        gEngine->setEQ(channel, low, mid, high);
    }
}

}

