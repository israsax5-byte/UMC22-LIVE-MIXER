#include <jni.h>
#include <oboe/Oboe.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

class UMC22Engine {
private:
    static constexpr uint32_t kCapacity = 16384;
    static constexpr uint32_t kMask = kCapacity - 1;

    class InputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit InputCallback(UMC22Engine* owner) : owner_(owner) {}

        oboe::DataCallbackResult onAudioReady(
                oboe::AudioStream* stream, void* audioData, int32_t frames) override {
            if (owner_ != nullptr) owner_->capture(stream, audioData, frames);
            return oboe::DataCallbackResult::Continue;
        }

        void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
            (void) error;
        }

    private:
        UMC22Engine* owner_;
    };

    class OutputCallback final : public oboe::AudioStreamCallback {
    public:
        explicit OutputCallback(UMC22Engine* owner) : owner_(owner) {}

        oboe::DataCallbackResult onAudioReady(
                oboe::AudioStream* stream, void* audioData, int32_t frames) override {
            if (owner_ != nullptr) owner_->render(stream, audioData, frames);
            return oboe::DataCallbackResult::Continue;
        }

        void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
            (void) error;
        }

    private:
        UMC22Engine* owner_;
    };

    std::shared_ptr<oboe::AudioStream> input_;
    std::shared_ptr<oboe::AudioStream> output_;
    InputCallback inputCallback_{this};
    OutputCallback outputCallback_{this};

    // Single producer: input callback. Single consumer: output callback.
    std::vector<float> ring_ = std::vector<float>(kCapacity * 2, 0.0f);
    alignas(64) std::atomic<uint32_t> writeFrame_{0};
    alignas(64) std::atomic<uint32_t> readFrame_{0};

    std::atomic<float> gainLeft_{0.75f};
    std::atomic<float> gainRight_{0.65f};
    std::atomic<bool> muteLeft_{false};
    std::atomic<bool> muteRight_{false};

    std::mutex lifecycleMutex_;

    static float readSample(const void* data, oboe::AudioFormat format, int32_t index) {
        if (format == oboe::AudioFormat::Float) {
            const auto* samples = static_cast<const float*>(data);
            const float value = samples[index];
            return std::isfinite(value) ? value : 0.0f;
        }
        if (format == oboe::AudioFormat::I16) {
            const auto* samples = static_cast<const int16_t*>(data);
            return static_cast<float>(samples[index]) / 32768.0f;
        }
        return 0.0f;
    }

    static void writeSample(void* data, oboe::AudioFormat format,
                            int32_t index, float value) {
        value = std::clamp(value, -1.0f, 1.0f);
        if (format == oboe::AudioFormat::Float) {
            auto* samples = static_cast<float*>(data);
            samples[index] = value;
        } else if (format == oboe::AudioFormat::I16) {
            auto* samples = static_cast<int16_t*>(data);
            const float scaled = value * 32767.0f;
            samples[index] = static_cast<int16_t>(
                std::clamp(scaled, -32768.0f, 32767.0f));
        }
    }

    void capture(oboe::AudioStream* stream, void* audioData, int32_t frames) {
        if (stream == nullptr || audioData == nullptr || frames <= 0) return;

        const oboe::AudioFormat format = stream->getFormat();
        if (format != oboe::AudioFormat::Float &&
            format != oboe::AudioFormat::I16) {
            return;
        }

        const int32_t channels = stream->getChannelCount();
        if (channels < 1) return;

        uint32_t write = writeFrame_.load(std::memory_order_relaxed);
        const uint32_t read = readFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < frames; ++frame) {
            // If full, discard the incoming frame. Do not overwrite unread data.
            if (static_cast<uint32_t>(write - read) >= kCapacity) continue;

            const int32_t base = frame * channels;
            const float left = readSample(audioData, format, base);
            const float right = (channels >= 2)
                ? readSample(audioData, format, base + 1)
                : left;

            const uint32_t slot = write & kMask;
            ring_[slot * 2] = left;
            ring_[slot * 2 + 1] = right;
            ++write;
        }

        writeFrame_.store(write, std::memory_order_release);
    }

    void render(oboe::AudioStream* stream, void* audioData, int32_t frames) {
        if (stream == nullptr || audioData == nullptr || frames <= 0) return;

        const oboe::AudioFormat format = stream->getFormat();
        const int32_t channels = stream->getChannelCount();

        if (channels < 1 ||
            (format != oboe::AudioFormat::Float &&
             format != oboe::AudioFormat::I16)) {
            return;
        }

        const float leftGain = muteLeft_.load(std::memory_order_relaxed)
            ? 0.0f : gainLeft_.load(std::memory_order_relaxed);
        const float rightGain = muteRight_.load(std::memory_order_relaxed)
            ? 0.0f : gainRight_.load(std::memory_order_relaxed);

        uint32_t read = readFrame_.load(std::memory_order_relaxed);
        const uint32_t write = writeFrame_.load(std::memory_order_acquire);

        for (int32_t frame = 0; frame < frames; ++frame) {
            float left = 0.0f;
            float right = 0.0f;

            if (read != write) {
                const uint32_t slot = read & kMask;
                left = ring_[slot * 2];
                right = ring_[slot * 2 + 1];
                ++read;
            }

            const int32_t base = frame * channels;
            writeSample(audioData, format, base, left * leftGain);

            if (channels >= 2) {
                writeSample(audioData, format, base + 1, right * rightGain);
                for (int32_t channel = 2; channel < channels; ++channel) {
                    writeSample(audioData, format, base + channel, 0.0f);
                }
            }
        }

        readFrame_.store(read, std::memory_order_release);
    }

    void closeStreamsLocked() {
        // Close the input first so its callback stops producing ring-buffer data.
        if (input_) {
            input_->requestStop();
            input_->close();
            input_.reset();
        }
        if (output_) {
            output_->requestStop();
            output_->close();
            output_.reset();
        }
    }

public:
    bool start() {
        std::lock_guard<std::mutex> lock(lifecycleMutex_);
        if (input_ || output_) return false;

        writeFrame_.store(0, std::memory_order_relaxed);
        readFrame_.store(0, std::memory_order_relaxed);
        std::fill(ring_.begin(), ring_.end(), 0.0f);

        oboe::AudioStreamBuilder inputBuilder;
        inputBuilder.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setFormatConversionAllowed(true)
            ->setChannelCount(2)
            ->setSampleRate(48000)
            ->setCallback(&inputCallback_);

        oboe::Result result = inputBuilder.openStream(input_);
        if (result != oboe::Result::OK || !input_) {
            input_.reset();
            return false;
        }

        const oboe::AudioFormat inputFormat = input_->getFormat();
        if ((inputFormat != oboe::AudioFormat::Float &&
             inputFormat != oboe::AudioFormat::I16) ||
            input_->getChannelCount() < 1 ||
            input_->getSampleRate() <= 0) {
            closeStreamsLocked();
            return false;
        }

        oboe::AudioStreamBuilder outputBuilder;
        outputBuilder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setFormatConversionAllowed(true)
            ->setChannelCount(2)
            ->setSampleRate(input_->getSampleRate())
            ->setCallback(&outputCallback_);

        result = outputBuilder.openStream(output_);
        if (result != oboe::Result::OK || !output_) {
            closeStreamsLocked();
            return false;
        }

        const oboe::AudioFormat outputFormat = output_->getFormat();
        if ((outputFormat != oboe::AudioFormat::Float &&
             outputFormat != oboe::AudioFormat::I16) ||
            output_->getChannelCount() < 1 ||
            output_->getSampleRate() != input_->getSampleRate()) {
            closeStreamsLocked();
            return false;
        }

        // Start output first, then input, to avoid capturing before playback is ready.
        if (output_->requestStart() != oboe::Result::OK) {
            closeStreamsLocked();
            return false;
        }

        if (input_->requestStart() != oboe::Result::OK) {
            closeStreamsLocked();
            return false;
        }

        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(lifecycleMutex_);
        closeStreamsLocked();
        writeFrame_.store(0, std::memory_order_relaxed);
        readFrame_.store(0, std::memory_order_relaxed);
    }

    void setGains(float left, float right) {
        if (!std::isfinite(left)) left = 0.0f;
        if (!std::isfinite(right)) right = 0.0f;
        gainLeft_.store(std::clamp(left, 0.0f, 1.0f), std::memory_order_relaxed);
        gainRight_.store(std::clamp(right, 0.0f, 1.0f), std::memory_order_relaxed);
    }

    void setMutes(bool left, bool right) {
        muteLeft_.store(left, std::memory_order_relaxed);
        muteRight_.store(right, std::memory_order_relaxed);
    }
};

static UMC22Engine gEngine;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(JNIEnv*, jobject) {
    return gEngine.start() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(JNIEnv*, jobject) {
    gEngine.stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
        JNIEnv*, jobject, jfloat left, jfloat right) {
    gEngine.setGains(left, right);
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
        JNIEnv*, jobject, jboolean left, jboolean right) {
    gEngine.setMutes(left == JNI_TRUE, right == JNI_TRUE);
}
