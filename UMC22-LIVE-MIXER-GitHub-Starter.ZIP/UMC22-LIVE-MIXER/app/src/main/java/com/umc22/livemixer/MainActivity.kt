
package com.umc22.livemixer

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startButton: Button

    private var engineStarted = false
    private var gain1 = 0.75f
    private var gain2 = 0.65f
    private var mute1 = false
    private var mute2 = false

    private val white = 0xFFFFFFFF.toInt()
    private val green = 0xFF65D6AD.toInt()
    private val dark = 0xFF101820.toInt()

    companion object {
        init {
            System.loadLibrary("umc22_audio")
        }
    }

    private external fun nativeStart(): Boolean
    private external fun nativeStop()
    private external fun nativeSetGains(g1: Float, g2: Float)
    private external fun nativeSetMutes(m1: Boolean, m2: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(dark)
        }

        fun heading(value: String, size: Float): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(white)
                setPadding(0, 12, 0, 12)
            }
        }

        content.addView(heading("UMC22 LIVE MIXER", 26f))
        content.addView(heading("Versión 0.4.0 PRO · Prueba", 15f))

        status = heading("Motor detenido", 16f)
        status.setTextColor(green)
        content.addView(status)

        startButton = Button(this).apply {
            text = "INICIAR AUDIO"
            setOnClickListener {
                if (engineStarted) {
                    stopEngine()
                } else if (
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startEngine()
                } else {
                    requestPermissions(
                        arrayOf(Manifest.permission.RECORD_AUDIO),
                        100
                    )
                }
            }
        }
        content.addView(startButton)

        addChannel(content, "CH1 · MICRÓFONO XLR", 75, 1)
        addChannel(content, "CH2 · GUITARRA / BAJO", 65, 2)

        content.addView(
            heading(
                "Prueba experimental. No se garantiza todavía " +
                "la separación física MAIN y PHONES.",
                13f
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun startEngine() {
        if (engineStarted) return

        val success = nativeStart()
        engineStarted = success

        status.text = if (success) {
            "Motor iniciado · Prueba experimental"
        } else {
            "No se pudo iniciar el motor de audio"
        }

        startButton.text = if (success) {
            "DETENER AUDIO"
        } else {
            "REINTENTAR"
        }
    }

    private fun stopEngine() {
        if (engineStarted) {
            nativeStop()
            engineStarted = false
        }

        status.text = "Motor detenido"
        startButton.text = "INICIAR AUDIO"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 100) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                startEngine()
            } else {
                status.text = "Permiso de micrófono denegado"
            }
        }
    }

    private fun addChannel(
        root: LinearLayout,
        name: String,
        initial: Int,
        channel: Int
    ) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
            setBackgroundColor(0xFF1B2A36.toInt())
        }

        val title = TextView(this).apply {
            text = name
            textSize = 20f
            setTextColor(green)
            setPadding(0, 8, 0, 12)
        }
        panel.addView(title)

        val level = TextView(this).apply {
            text = "VOLUMEN: $initial%"
            textSize = 17f
            setTextColor(white)
        }
        panel.addView(level)

        val fader = SeekBar(this).apply {
            max = 100
            progress = initial
        }

        fader.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    bar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    level.text = "VOLUMEN: $progress%"

                    if (channel == 1) {
                        gain1 = progress / 100f
                    } else {
                        gain2 = progress / 100f
                    }

                    if (engineStarted) {
                        nativeSetGains(gain1, gain2)
                    }
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            }
        )
        panel.addView(fader)

        val muteButton = Button(this).apply {
            text = "MUTE: OFF"
            setOnClickListener {
                if (channel == 1) {
                    mute1 = !mute1
                    text = if (mute1) "MUTE: ON" else "MUTE: OFF"
                } else {
                    mute2 = !mute2
                    text = if (mute2) "MUTE: ON" else "MUTE: OFF"
                }

                if (engineStarted) {
                    nativeSetMutes(mute1, mute2)
                }
            }
        }
        panel.addView(
            muteButton,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        root.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 20
            }
        )
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }
}
