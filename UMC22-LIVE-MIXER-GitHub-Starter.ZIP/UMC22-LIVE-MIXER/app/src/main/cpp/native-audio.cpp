
#include <jni.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <algorithm>
#include <memory>
#include <vector>
#include <mutex>

class UMC22Engine {
private:
    class InputCallback : public oboe::AudioStreamCallback {
    public:
        UMC22Engine* engine;
        explicit InputCallback(UMC22Engine* e) : engine(e) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* data,
            int32_t frames
        ) override {
            engine->capture(stream, data, frames);
            return oboe::DataCallbackResult::Continue;
        }
    };

    class OutputCallback : public oboe::AudioStreamCallback {
    public:
        UMC22Engine* engine;
        explicit OutputCallback(UMC22Engine* e) : engine(e) {}

        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream* stream,
            void* data,
            int32_t frames
        ) override {
            engine->play(stream, data, frames);
            return oboe::DataCallbackResult::Continue;
        }
    };

    std::shared_ptr<oboe::AudioStream> input;
    std::shared_ptr<oboe::AudioStream> output;

    InputCallback inputCallback{this};
    OutputCallback outputCallback{this};

    static constexpr int capacity = 32768;
    std::vector<float> buffer{capacity * 2, 0.0f};

    std::atomic<int> writeFrame{0};
    std::atomic<int> readFrame{0};
    std::atomic<float> gain1{0.75f};
    std::atomic<float> gain2{0.65f};
    std::atomic<bool> mute1{false};
    std::atomic<bool> mute2{false};

    std::mutex controlMutex;

    void capture(
        oboe::AudioStream* stream,
        void* data,
        int32_t frames
    ) {
        const int channels = stream->getChannelCount();
        const int32_t count = std::min(channels, 2);

        if (stream->getFormat() != oboe::AudioFormat::Float) return;

        const auto* in = static_cast<const float*>(data);

        for (int i = 0; i < frames; ++i) {
            int w = writeFrame.load(std::memory_order_relaxed);
            int next = (w + 1) % capacity;
            int r = readFrame.load(std::memory_order_acquire);

            if (next == r) continue;

            float left = in[i * channels];
            float right = count > 1 ? in[i * channels + 1] : left;

            buffer[w * 2] = left;
            buffer[w * 2 + 1] = right;

            writeFrame.store(next, std::memory_order_release);
        }
    }

    void play(
        oboe::AudioStream* stream,
        void* data,
        int32_t frames
    ) {
        const int channels = stream->getChannelCount();
        auto* out = static_cast<float*>(data);

        float g1 = mute1.load() ? 0.0f : gain1.load();
        float g2 = mute2.load() ? 0.0f : gain2.load();

        for (int i = 0; i < frames; ++i) {
            int r = readFrame.load(std::memory_order_relaxed);
            int w = writeFrame.load(std::memory_order_acquire);

            float left = 0.0f;
            float right = 0.0f;

            if (r != w) {
                left = buffer[r * 2];
                right = buffer[r * 2 + 1];
                readFrame.store((r + 1) % capacity,
                                std::memory_order_release);
            }

            if (channels >= 2) {
                out[i * channels] = left * g1;
                out[i * channels + 1] = right * g2;
                for (int c = 2; c < channels; ++c)
                    out[i * channels + c] = 0.0f;
            } else {
                out[i] = (left * g1 + right * g2) * 0.5f;
            }
        }
    }

public:
    bool start() {
        std::lock_guard<std::mutex> lock(controlMutex);

        if (input || output) return false;

        oboe::AudioStreamBuilder inBuilder;
        inBuilder.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setSampleRate(48000)
            ->setCallback(&inputCallback);

        if (inBuilder.openStream(input) != oboe::Result::OK) {
            input.reset();
            return false;
        }

        oboe::AudioStreamBuilder outBuilder;
        outBuilder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(2)
            ->setSampleRate(input->getSampleRate())
            ->setCallback(&outputCallback);

        if (outBuilder.openStream(output) != oboe::Result::OK) {
            input->close();
            input.reset();
            output.reset();
            return false;
        }

        if (output->getFormat() != oboe::AudioFormat::Float ||
            output->getChannelCount() < 1 ||
            input->getFormat() != oboe::AudioFormat::Float ||
            input->getChannelCount() < 1) {
            output->close();
            input->close();
            output.reset();
            input.reset();
            return false;
        }

        writeFrame.store(0);
        readFrame.store(0);

        if (output->requestStart() != oboe::Result::OK) {
            output->close();
            input->close();
            output.reset();
            input.reset();
            return false;
        }

        if (input->requestStart() != oboe::Result::OK) {
            output->requestStop();
            output->close();
            input->close();
            output.reset();
            input.reset();
            return false;
        }

        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(controlMutex);

        if (input) {
            input->requestStop();
            input->close();
            input.reset();
        }

        if (output) {
            output->requestStop();
            output->close();
            output.reset();
        }

        writeFrame.store(0);
        readFrame.store(0);
    }

    void setGains(float a, float b) {
        gain1.store(std::clamp(a, 0.0f, 1.0f));
        gain2.store(std::clamp(b, 0.0f, 1.0f));
    }

    void setMutes(bool a, bool b) {
        mute1.store(a);
        mute2.store(b);
    }
};

static UMC22Engine engine;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStart(
    JNIEnv*, jobject
) {
    return engine.start() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeStop(
    JNIEnv*, jobject
) {
    engine.stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetGains(
    JNIEnv*, jobject, jfloat a, jfloat b
) {
    engine.setGains(a, b);
}

extern "C" JNIEXPORT void JNICALL
Java_com_umc22_livemixer_MainActivity_nativeSetMutes(
    JNIEnv*, jobject, jboolean a, jboolean b
) {
    engine.setMutes(a, b);
}
