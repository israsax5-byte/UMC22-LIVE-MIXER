# UMC22 LIVE MIXER — starter build

This is an Android UI/USB-detection starter and GitHub Actions build workflow.

**Important:** the current app is only a UI prototype and USB device-list check. It does NOT yet capture, process, or output live audio. Do not use it for live events. Real UMC22 full-duplex USB audio, DSP, latency, routing, permissions, and device reconnection still need implementation and physical testing.

## Build
GitHub Actions workflow: Actions → Build Android APK → Run workflow. Download the `UMC22-LIVE-MIXER-debug` artifact from the completed run.
